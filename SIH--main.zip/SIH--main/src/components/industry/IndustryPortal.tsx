import React, { useState, useMemo } from 'react';
import {
  CompanyProfile,
  InternshipPosting,
  ApplicationRecord,
  IndustryTab,
  NotificationRecord,
} from '../../types';
import { CompanyProfileForm } from './CompanyProfileForm';
import { NewPostingForm } from './NewPostingForm';
import { ApplicantPipeline } from './ApplicantPipeline';
import { DashboardNotificationBanner } from '../common/DashboardNotificationBanner';
import { NotificationFeed } from '../common/NotificationFeed';
import {
  Building2,
  Plus,
  Users,
  Briefcase,
  MapPin,
  Clock,
  IndianRupee,
  CheckCircle2,
  Sliders,
  ChevronRight,
  TrendingUp,
  Bell,
} from 'lucide-react';

interface IndustryPortalProps {
  companies: CompanyProfile[];
  internships: InternshipPosting[];
  applications: ApplicationRecord[];
  activeCompanyId: string;
  notifications: NotificationRecord[];
  onSelectCompany: (id: string) => void;
  onSaveCompany: (company: CompanyProfile) => Promise<void>;
  onCreateCompany: (company: CompanyProfile) => Promise<void>;
  onPostInternship: (internship: InternshipPosting) => Promise<void>;
  onUpdateInternshipStatus: (
    id: string,
    status: 'active' | 'closed'
  ) => Promise<void>;
  onUpdateApplicationStatus: (
    appId: string,
    status: ApplicationRecord['status']
  ) => Promise<void>;
  onMarkNotificationAsRead: (id: string) => void;
  onMarkAllNotificationsAsRead: () => void;
}

export const IndustryPortal: React.FC<IndustryPortalProps> = ({
  companies,
  internships,
  applications,
  activeCompanyId,
  notifications,
  onSelectCompany,
  onSaveCompany,
  onCreateCompany,
  onPostInternship,
  onUpdateInternshipStatus,
  onUpdateApplicationStatus,
  onMarkNotificationAsRead,
  onMarkAllNotificationsAsRead,
}) => {
  const [activeTab, setActiveTab] = useState<IndustryTab>('postings');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');

  const activeCompany =
    companies.find((c) => c.id === activeCompanyId) || companies[0];

  const currentCompanyPostings = useMemo(() => {
    return internships.filter((i) => i.companyId === activeCompany?.id);
  }, [internships, activeCompany?.id]);

  const currentCompanyApplicantsCount = useMemo(() => {
    return applications.filter((a) => {
      if (a.companyId === activeCompany?.id) return true;
      const intern = internships.find((i) => i.id === a.internshipId);
      return intern?.companyId === activeCompany?.id;
    }).length;
  }, [applications, activeCompany?.id, internships]);

  const companyNotifications = useMemo(() => {
    return notifications.filter(
      (n) =>
        n.recipientType === 'company' &&
        (!n.recipientId || n.recipientId === activeCompany?.id || n.metadata?.companyId === activeCompany?.id)
    );
  }, [notifications, activeCompany?.id]);

  const unreadCompanyNotifsCount = companyNotifications.filter((n) => !n.read).length;

  return (
    <div className="space-y-6" id="industry-portal-root">
      {/* Top Header & Subnavigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
              Industry Portal
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-600 border border-blue-200/60 font-semibold">
              Recruiter Mode
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Managing internship requirements for <span className="font-semibold text-slate-700">{activeCompany?.name}</span>
          </p>
        </div>

        {/* Segmented sub-tab switcher */}
        <nav aria-label="Industry portal tabs" className="flex bg-slate-100 p-1 rounded-md border border-slate-200/80">
          <button
            id="tab-industry-postings"
            type="button"
            onClick={() => setActiveTab('postings')}
            className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
              activeTab === 'postings'
                ? 'bg-white shadow-sm text-blue-600 font-semibold'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Postings ({currentCompanyPostings.length})
          </button>

          <button
            id="tab-industry-new-posting"
            type="button"
            onClick={() => setActiveTab('new-posting')}
            className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
              activeTab === 'new-posting'
                ? 'bg-white shadow-sm text-blue-600 font-semibold'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            + Post Requirement
          </button>

          <button
            id="tab-industry-applicants"
            type="button"
            onClick={() => setActiveTab('applicants')}
            className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
              activeTab === 'applicants'
                ? 'bg-white shadow-sm text-blue-600 font-semibold'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Applicants ({currentCompanyApplicantsCount})
          </button>

          <button
            id="tab-industry-notifications"
            type="button"
            onClick={() => setActiveTab('notifications')}
            className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-white shadow-sm text-blue-600 font-semibold'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            <span>Alerts</span>
            {unreadCompanyNotifsCount > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] font-bold bg-blue-600 text-white rounded-full">
                {unreadCompanyNotifsCount}
              </span>
            )}
          </button>

          <button
            id="tab-industry-profile"
            type="button"
            onClick={() => setActiveTab('company-profile')}
            className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
              activeTab === 'company-profile'
                ? 'bg-white shadow-sm text-blue-600 font-semibold'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            Company Profile
          </button>
        </nav>
      </div>

      {/* Real-time Recruiter Notification Alert Banner */}
      <DashboardNotificationBanner
        role="company"
        notifications={companyNotifications}
        onMarkAsRead={onMarkNotificationAsRead}
        onActionClick={() => setActiveTab('applicants')}
      />

      {/* TAB 1: POSTINGS OVERVIEW */}
      {activeTab === 'postings' && (
        <div className="space-y-6">
          {/* Metrics highlight */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Postings</span>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {currentCompanyPostings.filter((p) => p.status === 'active').length}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">Live on Student Dashboard</p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Candidates</span>
              <p className="text-2xl font-bold text-slate-800 mt-1">
                {currentCompanyApplicantsCount}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">Ranked by Match Score Algorithm</p>
            </div>

            <div className="p-6 bg-gradient-to-br from-blue-50/60 to-white rounded-2xl border border-blue-200 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-blue-900 block">Post New Internship</span>
                <p className="text-xs text-blue-600 mt-0.5">Specify your tech stack skills.</p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('new-posting')}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition shadow-lg shadow-blue-200 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Post Role</span>
              </button>
            </div>
          </div>

          {/* Table View of Industry Portal Postings (Matching Design HTML) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between flex-wrap gap-2">
              <div>
                <h2 className="font-bold text-slate-800">Industry Portal Postings</h2>
                <p className="text-xs text-slate-500">Live roles and algorithmic match thresholds</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setViewMode(viewMode === 'table' ? 'cards' : 'table')}
                  className="text-xs font-semibold text-blue-600 hover:underline px-2.5 py-1 rounded bg-blue-50"
                >
                  Switch to {viewMode === 'table' ? 'Card Grid' : 'Table View'}
                </button>
              </div>
            </div>

            {currentCompanyPostings.length === 0 ? (
              <div className="p-12 text-center text-slate-500 text-xs space-y-3">
                <Briefcase className="w-8 h-8 text-slate-300 mx-auto" />
                <h3 className="text-base font-bold text-slate-800">No internship requirements posted yet</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Create a posting with required technical skills to start receiving matched student applications.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('new-posting')}
                  className="text-xs font-semibold px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-lg shadow-blue-200 cursor-pointer"
                >
                  Post Your First Requirement
                </button>
              </div>
            ) : viewMode === 'table' ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 text-slate-400 text-[10px] uppercase font-bold tracking-wider border-b border-slate-100">
                      <th className="px-6 py-3.5">Organization</th>
                      <th className="px-6 py-3.5">Position</th>
                      <th className="px-6 py-3.5">Requirements</th>
                      <th className="px-6 py-3.5">Applicants & Match</th>
                      <th className="px-6 py-3.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {currentCompanyPostings.map((posting) => {
                      const applicantsForPosting = applications.filter(
                        (a) => a.internshipId === posting.id
                      );
                      const avgMatch = applicantsForPosting.length > 0
                        ? Math.round(applicantsForPosting.reduce((s, a) => s + a.matchScore, 0) / applicantsForPosting.length)
                        : 85;

                      return (
                        <tr key={posting.id} className="hover:bg-slate-50/60 transition-colors">
                          <td className="px-6 py-4 font-semibold text-slate-700 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0"></span>
                            <span>{posting.companyName}</span>
                          </td>
                          <td className="px-6 py-4 text-slate-600">
                            <span className="font-semibold text-slate-800 block">{posting.title}</span>
                            <span className="text-[11px] text-slate-400">{posting.roleType} • {posting.duration}</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-1 flex-wrap max-w-xs">
                              {posting.requiredSkills.slice(0, 3).map((sk) => (
                                <span
                                  key={sk}
                                  className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-medium text-slate-700 border border-slate-200"
                                >
                                  {sk}
                                </span>
                              ))}
                              {posting.requiredSkills.length > 3 && (
                                <span className="px-1.5 py-0.5 bg-slate-100 rounded text-[10px] text-slate-500">
                                  +{posting.requiredSkills.length - 3}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-2">
                              <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-blue-500"
                                  style={{ width: `${avgMatch}%` }}
                                ></div>
                              </div>
                              <span className="font-bold text-slate-700">{avgMatch}%</span>
                              <span className="text-[11px] text-slate-400">({applicantsForPosting.length})</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => setActiveTab('applicants')}
                                className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-md transition-colors text-xs cursor-pointer"
                              >
                                View ({applicantsForPosting.length})
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  onUpdateInternshipStatus(
                                    posting.id,
                                    posting.status === 'active' ? 'closed' : 'active'
                                  )
                                }
                                className="text-xs text-slate-400 hover:text-slate-700 px-2 py-1"
                              >
                                {posting.status === 'active' ? 'Close' : 'Re-open'}
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                {currentCompanyPostings.map((posting) => {
                  const applicantsForPosting = applications.filter(
                    (a) => a.internshipId === posting.id
                  );

                  return (
                    <div
                      key={posting.id}
                      id={`company-posting-${posting.id}`}
                      className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full capitalize border ${
                            posting.status === 'active'
                              ? 'bg-green-50 text-green-700 border-green-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}>
                            {posting.status}
                          </span>

                          <span className="text-xs text-slate-500">
                            {posting.roleType} • {posting.duration}
                          </span>
                        </div>

                        <h3 className="text-base font-bold text-slate-800 line-clamp-1">
                          {posting.title}
                        </h3>

                        <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                          {posting.description}
                        </p>

                        {/* Required skills */}
                        <div className="mt-3 space-y-1">
                          <span className="text-[11px] font-semibold text-slate-500">
                            Required Skills:
                          </span>
                          <div className="flex flex-wrap gap-1.5">
                            {posting.requiredSkills.map((sk) => (
                              <span
                                key={sk}
                                className="text-[11px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200"
                              >
                                {sk}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Bottom row: stipend, applicants count, actions */}
                      <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-bold block">
                            Stipend
                          </span>
                          <span className="text-xs font-bold text-slate-800">
                            {posting.stipend}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setActiveTab('applicants');
                            }}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition"
                          >
                            <Users className="w-3.5 h-3.5" />
                            <span>{applicantsForPosting.length} Applicants</span>
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateInternshipStatus(
                                posting.id,
                                posting.status === 'active' ? 'closed' : 'active'
                              )
                            }
                            className="text-xs font-medium text-slate-400 hover:text-slate-700 px-2 py-1 rounded hover:bg-slate-50 transition"
                          >
                            {posting.status === 'active' ? 'Close' : 'Re-open'}
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: POST NEW INTERNSHIP */}
      {activeTab === 'new-posting' && (
        <NewPostingForm
          companies={companies}
          activeCompanyId={activeCompany?.id || ''}
          onPostInternship={onPostInternship}
          onSuccess={() => setActiveTab('postings')}
        />
      )}

      {/* TAB 3: APPLICANTS PIPELINE */}
      {activeTab === 'applicants' && (
        <ApplicantPipeline
          applications={applications}
          internships={internships}
          activeCompanyId={activeCompany?.id || ''}
          onUpdateStatus={onUpdateApplicationStatus}
        />
      )}

      {/* TAB 4: REAL-TIME NOTIFICATIONS FEED */}
      {activeTab === 'notifications' && (
        <NotificationFeed
          role="company"
          notifications={companyNotifications}
          onMarkAsRead={onMarkNotificationAsRead}
          onMarkAllAsRead={onMarkAllNotificationsAsRead}
          onActionClick={() => setActiveTab('applicants')}
        />
      )}

      {/* TAB 5: COMPANY PROFILE */}
      {activeTab === 'company-profile' && (
        <CompanyProfileForm
          companies={companies}
          activeCompanyId={activeCompany?.id || ''}
          onSelectCompany={onSelectCompany}
          onSaveCompany={onSaveCompany}
          onCreateNewCompany={onCreateCompany}
        />
      )}
    </div>
  );
};
