import React from 'react';
import { InternshipPosting, MatchScoreDetails, StudentProfile } from '../../types';
import { MatchBadge } from '../common/MatchBadge';
import {
  X,
  Building2,
  MapPin,
  Clock,
  IndianRupee,
  Calendar,
  Users,
  CheckCircle2,
  AlertTriangle,
  Send,
  ExternalLink,
} from 'lucide-react';

interface InternshipDetailModalProps {
  internship: InternshipPosting | null;
  matchDetails: MatchScoreDetails | null;
  student: StudentProfile;
  hasApplied: boolean;
  onClose: () => void;
  onApply: (internship: InternshipPosting) => void;
}

export const InternshipDetailModal: React.FC<InternshipDetailModalProps> = ({
  internship,
  matchDetails,
  student,
  hasApplied,
  onClose,
  onApply,
}) => {
  if (!internship || !matchDetails) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        id="internship-detail-modal"
        className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="p-6 border-b border-slate-100 flex items-start justify-between bg-white">
          <div className="space-y-1 pr-6">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700">
                {internship.roleType}
              </span>
              <span className="text-xs text-slate-500">Posted on {new Date(internship.createdAt).toLocaleDateString()}</span>
            </div>
            <h2 className="text-xl font-bold text-slate-800 leading-snug">
              {internship.title}
            </h2>
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Building2 className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="font-semibold text-slate-700">{internship.companyName}</span>
              <span className="text-slate-300">•</span>
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>{internship.companyLocation}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Key Quick Facts Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <IndianRupee className="w-3.5 h-3.5" />
                <span>Stipend</span>
              </div>
              <p className="text-sm font-bold text-slate-800">{internship.stipend}</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Clock className="w-3.5 h-3.5" />
                <span>Duration</span>
              </div>
              <p className="text-sm font-bold text-slate-800">{internship.duration}</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>Deadline</span>
              </div>
              <p className="text-sm font-bold text-slate-800">{internship.deadline}</p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
              <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
                <Users className="w-3.5 h-3.5" />
                <span>Openings</span>
              </div>
              <p className="text-sm font-bold text-slate-800">{internship.openPositions} seats</p>
            </div>
          </div>

          {/* Detailed Match Score Analysis Card */}
          <div className="p-5 rounded-xl border border-slate-200 bg-blue-50/30">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                  Automated Match Analysis for {student.name}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Algorithm compares your verified skill proficiency against company specifications.
                </p>
              </div>
              <MatchBadge details={matchDetails} size="lg" />
            </div>

            <p className="text-xs text-slate-700 bg-white p-3 rounded-lg border border-slate-200 mb-4">
              <span className="font-semibold text-slate-800">Match Diagnostics: </span>
              {matchDetails.recommendation}
            </p>

            {/* Core Skills Match Matrix */}
            <div className="space-y-3">
              <div>
                <p className="text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                  Matched Required Skills ({matchDetails.matchedRequired.length} / {matchDetails.totalRequired})
                </p>
                {matchDetails.matchedRequired.length > 0 ? (
                  <div className="flex flex-wrap gap-1.5">
                    {matchDetails.matchedRequired.map((s) => (
                      <span
                        key={s}
                        className="inline-flex items-center text-xs font-medium px-2.5 py-1 rounded-md bg-green-50 text-green-700 border border-green-200"
                      >
                        ✓ {s}
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">None matched yet</p>
                )}
              </div>

              {matchDetails.missingRequired.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-slate-700 mb-1.5 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-orange-600" />
                    Missing Required Skills ({matchDetails.missingRequired.length})
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {matchDetails.missingRequired.map((s) => (
                      <span
                        key={s}
                        className="inline-flex items-center text-xs font-medium px-2.5 py-1 rounded-md bg-orange-50 text-orange-700 border border-orange-200"
                      >
                        + {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {internship.optionalSkills.length > 0 && (
                <div className="pt-2 border-t border-slate-200/60">
                  <p className="text-xs font-semibold text-slate-600 mb-1.5">
                    Preferred / Bonus Skills:
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {internship.optionalSkills.map((s) => {
                      const isMatched = matchDetails.matchedOptional.includes(s);
                      return (
                        <span
                          key={s}
                          className={`text-xs px-2.5 py-0.5 rounded-md border font-medium ${
                            isMatched
                              ? 'bg-blue-50 text-blue-800 border-blue-200'
                              : 'bg-slate-50 text-slate-500 border-slate-200'
                          }`}
                        >
                          {isMatched ? `★ ${s}` : s}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-800">Role Overview</h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              {internship.description}
            </p>
          </div>

          {/* Responsibilities */}
          {internship.responsibilities && internship.responsibilities.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-bold text-slate-800">Key Responsibilities</h4>
              <ul className="space-y-1.5">
                {internship.responsibilities.map((resp, i) => (
                  <li key={i} className="text-xs sm:text-sm text-slate-600 flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-2 shrink-0" />
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition cursor-pointer"
          >
            Close
          </button>

          {hasApplied ? (
            <div className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-green-700 bg-green-50 border border-green-200 rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
              Application Submitted
            </div>
          ) : (
            <button
              id="apply-internship-now-button"
              type="button"
              onClick={() => onApply(internship)}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-lg shadow-blue-200 transition cursor-pointer"
            >
              <Send className="w-4 h-4" />
              Apply with Match Profile ({matchDetails.score}%)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
