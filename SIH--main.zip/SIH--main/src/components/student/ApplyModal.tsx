import React, { useState } from 'react';
import { InternshipPosting, MatchScoreDetails, StudentProfile, ApplicationRecord } from '../../types';
import { X, Send, Sparkles, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ApplyModalProps {
  internship: InternshipPosting | null;
  matchDetails: MatchScoreDetails | null;
  student: StudentProfile;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (app: ApplicationRecord) => Promise<void>;
}

export const ApplyModal: React.FC<ApplyModalProps> = ({
  internship,
  matchDetails,
  student,
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [coverNote, setCoverNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen || !internship || !matchDetails) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const newApp: ApplicationRecord = {
      id: `app-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      internshipId: internship.id,
      internshipTitle: internship.title,
      companyId: internship.companyId,
      companyName: internship.companyName,
      studentId: student.id,
      studentName: student.name,
      studentEmail: student.email,
      studentCollege: student.college,
      studentDegree: student.degree,
      matchScore: matchDetails.score,
      matchedSkills: matchDetails.matchedRequired,
      missingSkills: matchDetails.missingRequired,
      coverNote: coverNote.trim(),
      status: 'applied',
      appliedAt: new Date().toISOString(),
    };

    try {
      await onSubmit(newApp);
      setIsSuccess(true);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
      setTimeout(() => {
        setIsSuccess(false);
        onClose();
      }, 1800);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div
        id="apply-modal-box"
        className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
      >
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-800">
              Apply for Internship
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              {internship.title} • {internship.companyName}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-lg font-bold text-slate-800">Application Submitted!</h4>
            <p className="text-xs text-slate-600 max-w-xs mx-auto">
              Your profile and match score ({matchDetails.score}%) were recorded and synced to Firestore.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {/* Summary card */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Applicant Profile</p>
                <p className="text-sm font-bold text-slate-800">{student.name}</p>
                <p className="text-xs text-slate-500">{student.college}</p>
              </div>
              <div className="text-right">
                <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
                  {matchDetails.score}% Match
                </span>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  {matchDetails.matchedRequired.length} of {matchDetails.totalRequired} skills
                </p>
              </div>
            </div>

            {/* Note field */}
            <div className="space-y-1.5">
              <label htmlFor="cover-note-field" className="block text-xs font-semibold text-slate-700">
                Brief Note / Pitch to Recruiter (Optional)
              </label>
              <textarea
                id="cover-note-field"
                rows={3}
                placeholder="Mention relevant projects, course achievements, or availability..."
                value={coverNote}
                onChange={(e) => setCoverNote(e.target.value)}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
              />
            </div>

            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>
                Your verified skill list and CGPA ({student.cgpa}) will be shared directly with {internship.companyName}.
              </span>
            </div>

            {/* Action buttons */}
            <div className="pt-2 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-application-submit"
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-lg shadow-blue-200 disabled:opacity-50 transition cursor-pointer"
              >
                {isSubmitting ? (
                  <span>Submitting...</span>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Confirm Application</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
