import React, { useState } from 'react';
import { CompanyProfile } from '../../types';
import { Building2, Globe, Mail, MapPin, Save, CheckCircle2, ShieldCheck } from 'lucide-react';

interface CompanyProfileFormProps {
  companies: CompanyProfile[];
  activeCompanyId: string;
  onSelectCompany: (id: string) => void;
  onSaveCompany: (company: CompanyProfile) => Promise<void>;
  onCreateNewCompany: (company: CompanyProfile) => Promise<void>;
}

export const CompanyProfileForm: React.FC<CompanyProfileFormProps> = ({
  companies,
  activeCompanyId,
  onSelectCompany,
  onSaveCompany,
  onCreateNewCompany,
}) => {
  const current = companies.find((c) => c.id === activeCompanyId) || companies[0];
  const [formData, setFormData] = useState<CompanyProfile>(
    current || {
      id: `company-${Date.now()}`,
      name: '',
      industry: '',
      website: '',
      location: '',
      description: '',
      contactEmail: '',
      verified: true,
      createdAt: new Date().toISOString(),
    }
  );
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Switch form data when active company changes
  React.useEffect(() => {
    if (current && !isCreatingNew) {
      setFormData(current);
    }
  }, [current, isCreatingNew]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      if (isCreatingNew) {
        await onCreateNewCompany(formData);
        setIsCreatingNew(false);
      } else {
        await onSaveCompany(formData);
      }
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  const startNewCompany = () => {
    setIsCreatingNew(true);
    setFormData({
      id: `company-${Date.now()}`,
      name: '',
      industry: 'Enterprise Software',
      website: 'https://',
      location: 'Bangalore, India',
      description: '',
      contactEmail: '',
      verified: true,
      createdAt: new Date().toISOString(),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" id="company-profile-form">
      {/* Top Banner & Company Switcher */}
      <div className="p-6 bg-white border border-slate-200 text-slate-800 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center border border-blue-100 text-blue-600">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-800">
                {isCreatingNew ? 'Register New Industry Partner' : formData.name}
              </h2>
              {formData.verified && !isCreatingNew && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 border border-blue-200/60">
                  <ShieldCheck className="w-3 h-3" />
                  Verified Partner
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {formData.industry || 'Industry Profile'} • {formData.location || 'Location'}
            </p>
          </div>
        </div>

        {/* Company Selector or Create New */}
        <div className="flex items-center gap-2 flex-wrap">
          {!isCreatingNew && companies.length > 1 && (
            <select
              value={activeCompanyId}
              onChange={(e) => onSelectCompany(e.target.value)}
              aria-label="Select active industry company"
              className="px-3 py-2 text-xs font-semibold bg-slate-50 text-slate-700 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            >
              {companies.map((c) => (
                <option key={c.id} value={c.id} className="text-slate-800">
                  {c.name}
                </option>
              ))}
            </select>
          )}

          {!isCreatingNew ? (
            <button
              type="button"
              onClick={startNewCompany}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
            >
              + Register New Company
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                setIsCreatingNew(false);
                if (current) setFormData(current);
              }}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 transition cursor-pointer"
            >
              Cancel
            </button>
          )}

          <button
            id="save-company-btn"
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center gap-2 px-5 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200 transition disabled:opacity-50 cursor-pointer"
          >
            {savedSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Saved!</span>
              </>
            ) : isSaving ? (
              <span>Saving...</span>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{isCreatingNew ? 'Create Profile' : 'Save Changes'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Form Fields */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-blue-600" />
          Company Overview & Contact Details
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Company / Organization Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. NextGen Robotics Ltd"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Industry Domain / Sector *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. FinTech, Artificial Intelligence, Healthcare, EdTech"
              value={formData.industry}
              onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Headquarters / Operating Location *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Bangalore, Karnataka (Hybrid)"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Talent / Contact Email *
            </label>
            <input
              type="email"
              required
              placeholder="careers@company.com"
              value={formData.contactEmail}
              onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Website URL
          </label>
          <input
            type="url"
            placeholder="https://company.com"
            value={formData.website}
            onChange={(e) => setFormData({ ...formData, website: e.target.value })}
            className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Company Description & Engineering Culture
          </label>
          <textarea
            rows={4}
            placeholder="Tell students about your mission, product stack, and what they will learn during an internship..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
          />
        </div>
      </div>
    </form>
  );
};
