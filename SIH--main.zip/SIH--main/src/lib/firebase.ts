import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  Auth,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  getDocs,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  Firestore,
} from 'firebase/firestore';
import {
  RoleView,
  AccountType,
  UserAccount,
  StudentProfile,
  CompanyProfile,
  InternshipPosting,
  ApplicationRecord,
  NotificationRecord,
  InstitutionProfile,
} from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with custom databaseId from config
export const db: Firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId);

// Initialize Firebase Auth
export const auth: Auth = getAuth(app);

// Seed Institutions
export const SEED_INSTITUTIONS: InstitutionProfile[] = [
  {
    id: 'inst-skit-jaipur',
    name: 'Swami Keshvanand Institute of Technology (SKIT Jaipur)',
    code: 'SKIT-RJ',
    type: 'Engineering Institute',
    location: 'Ramnagaria, Jagatpura, Jaipur, Rajasthan',
    contactEmail: 'placements@skit.ac.in',
    website: 'https://www.skit.ac.in',
    accreditation: 'RTU Affiliated | NBA Accredited | NAAC A++',
    departments: [
      'Computer Science & Engineering',
      'Information Technology',
      'Artificial Intelligence & Data Science',
      'Electronics & Communication Engineering',
      'Electrical Engineering',
      'Mechanical Engineering',
    ],
    totalStudentsEnrolled: 2850,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'inst-nit-trichy',
    name: 'National Institute of Technology, Trichy',
    code: 'NITT-TN',
    type: 'Engineering Institute',
    location: 'Tiruchirappalli, Tamil Nadu',
    contactEmail: 'tnp@nitt.edu',
    website: 'https://www.nitt.edu',
    accreditation: 'NIRF Rank #9 (Engineering) | NAAC A++',
    departments: [
      'Computer Science & Engineering',
      'Data Science & AI',
      'Electronics & Communication Engineering',
      'Electrical & Electronics',
      'Mechanical Engineering',
    ],
    totalStudentsEnrolled: 1420,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'inst-iit-delhi',
    name: 'Indian Institute of Technology, Delhi',
    code: 'IITD-DL',
    type: 'University',
    location: 'Hauz Khas, New Delhi',
    contactEmail: 'career.services@iitd.ac.in',
    website: 'https://home.iitd.ac.in',
    accreditation: 'NIRF Rank #2 (Overall) | Institute of Eminence',
    departments: [
      'Computer Science & Engineering',
      'Information Technology',
      'Artificial Intelligence & Robotics',
      'Electrical Engineering',
    ],
    totalStudentsEnrolled: 2150,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'inst-dtu',
    name: 'Delhi Technological University',
    code: 'DTU-DL',
    type: 'Technology College',
    location: 'Shahbad Daulatpur, Delhi',
    contactEmail: 'placements@dtu.ac.in',
    website: 'http://www.dtu.ac.in',
    accreditation: 'NAAC A+ Grade | NIRF Rank #29',
    departments: [
      'Computer Engineering',
      'Software Engineering',
      'Information Technology',
      'Electronics & Communication',
    ],
    totalStudentsEnrolled: 3100,
    createdAt: new Date().toISOString(),
  },
];

// Initial Seed Students for demonstration
export const SEED_STUDENTS: StudentProfile[] = [
  {
    id: 'student-demo-1',
    name: 'Aarav Sharma',
    email: 'aarav.sharma@sih.edu.in',
    college: 'National Institute of Technology, Trichy',
    institutionId: 'inst-nit-trichy',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech in Computer Science & Engineering',
    yearOfStudy: '3rd Year (Class of 2027)',
    cgpa: '8.92 / 10',
    bio: 'Passionate software engineering undergraduate interested in full-stack web platforms and cloud systems. Contributor to open-source SIH initiatives.',
    skills: [
      { name: 'React', level: 'Advanced', verified: true },
      { name: 'TypeScript', level: 'Intermediate', verified: true },
      { name: 'Node.js', level: 'Intermediate', verified: true },
      { name: 'Python', level: 'Advanced', verified: true },
      { name: 'Tailwind CSS', level: 'Advanced', verified: true },
      { name: 'Machine Learning', level: 'Beginner', verified: false },
      { name: 'Git', level: 'Advanced', verified: true },
      { name: 'PostgreSQL', level: 'Intermediate', verified: true },
    ],
    githubUrl: 'https://github.com/aarav-sharma',
    linkedinUrl: 'https://linkedin.com/in/aarav-sharma-tech',
    portfolioUrl: 'https://aarav-portfolio.dev',
    availability: 'Available Immediately (Full-time / Hybrid)',
    preferredType: 'Any',
    verifiedByInstitution: true,
    verifiedAt: '2026-08-25T14:30:00.000Z',
    verifiedBy: 'NITT Academic & Placement Directorate',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-2',
    name: 'Priya Venkat',
    email: 'priya.venkat@sih.edu.in',
    college: 'National Institute of Technology, Trichy',
    institutionId: 'inst-nit-trichy',
    department: 'Data Science & AI',
    degree: 'B.Tech in Data Science & Artificial Intelligence',
    yearOfStudy: '3rd Year (Class of 2027)',
    cgpa: '9.28 / 10',
    bio: 'Researcher focused on NLP architectures, LLM fine-tuning, and retrieval-augmented pipelines. Published 1 IEEE workshop paper.',
    skills: [
      { name: 'Python', level: 'Advanced', verified: false },
      { name: 'Machine Learning', level: 'Advanced', verified: false },
      { name: 'PyTorch', level: 'Intermediate', verified: false },
      { name: 'SQL', level: 'Intermediate', verified: false },
      { name: 'Data Analysis', level: 'Advanced', verified: false },
      { name: 'Docker', level: 'Beginner', verified: false },
    ],
    githubUrl: 'https://github.com/priya-venkat-ai',
    linkedinUrl: 'https://linkedin.com/in/priya-venkat-ds',
    portfolioUrl: 'https://priyavenkat.ai',
    availability: 'Summer 2027 (May - August)',
    preferredType: 'Remote',
    verifiedByInstitution: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-3',
    name: 'Rohan Deshmukh',
    email: 'rohan.deshmukh@sih.edu.in',
    college: 'National Institute of Technology, Trichy',
    institutionId: 'inst-nit-trichy',
    department: 'Electronics & Communication Engineering',
    degree: 'B.Tech in Electronics & Communication',
    yearOfStudy: '4th Year (Class of 2026)',
    cgpa: '8.45 / 10',
    bio: 'Hardware-software co-design enthusiast with hands-on experience in ROS, embedded C++, LiDAR calibration, and STM32 microcontrollers.',
    skills: [
      { name: 'C++', level: 'Advanced', verified: true },
      { name: 'Python', level: 'Intermediate', verified: true },
      { name: 'Robotics', level: 'Advanced', verified: true },
      { name: 'Linux', level: 'Advanced', verified: true },
      { name: 'Computer Vision', level: 'Intermediate', verified: false },
    ],
    githubUrl: 'https://github.com/rohand-robotics',
    linkedinUrl: 'https://linkedin.com/in/rohan-deshmukh-ece',
    availability: 'Available Immediately (Full-time)',
    preferredType: 'In-office',
    verifiedByInstitution: true,
    verifiedAt: '2026-08-28T10:15:00.000Z',
    verifiedBy: 'NITT Academic & Placement Directorate',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-4',
    name: 'Ananya Sen',
    email: 'ananya.sen@sih.edu.in',
    college: 'National Institute of Technology, Trichy',
    institutionId: 'inst-nit-trichy',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech in Computer Science & Engineering',
    yearOfStudy: '2nd Year (Class of 2028)',
    cgpa: '8.82 / 10',
    bio: 'Frontend designer and developer passionate about building accessible, beautiful web interfaces, animations, and responsive micro-apps.',
    skills: [
      { name: 'React', level: 'Intermediate', verified: false },
      { name: 'Tailwind CSS', level: 'Advanced', verified: false },
      { name: 'JavaScript', level: 'Advanced', verified: false },
      { name: 'UI Design', level: 'Intermediate', verified: false },
      { name: 'Git', level: 'Intermediate', verified: false },
    ],
    githubUrl: 'https://github.com/ananya-designs',
    linkedinUrl: 'https://linkedin.com/in/ananya-sen-ui',
    availability: 'Part-time during semester / Full-time breaks',
    preferredType: 'Remote',
    verifiedByInstitution: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-5',
    name: 'Kabir Mehra',
    email: 'kabir.mehra@sih.edu.in',
    college: 'National Institute of Technology, Trichy',
    institutionId: 'inst-nit-trichy',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech in Computer Science & Engineering',
    yearOfStudy: '3rd Year (Class of 2027)',
    cgpa: '8.65 / 10',
    bio: 'Backend systems engineer passionate about resilient microservices, distributed caching, database indexing, and DevOps automation.',
    skills: [
      { name: 'Node.js', level: 'Advanced', verified: true },
      { name: 'PostgreSQL', level: 'Advanced', verified: true },
      { name: 'TypeScript', level: 'Intermediate', verified: true },
      { name: 'Docker', level: 'Intermediate', verified: true },
      { name: 'Git', level: 'Advanced', verified: true },
    ],
    githubUrl: 'https://github.com/kabirmehra-dev',
    linkedinUrl: 'https://linkedin.com/in/kabir-mehra-backend',
    availability: 'Available Immediately (Hybrid)',
    preferredType: 'Hybrid',
    verifiedByInstitution: true,
    verifiedAt: '2026-09-01T09:00:00.000Z',
    verifiedBy: 'NITT Academic & Placement Directorate',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-6',
    name: 'Devendra Verma',
    email: 'devendra.v@iitd.ac.in',
    college: 'Indian Institute of Technology, Delhi',
    institutionId: 'inst-iit-delhi',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech in Computer Science',
    yearOfStudy: '3rd Year (Class of 2027)',
    cgpa: '9.42 / 10',
    bio: 'Cloud architectures, Kubernetes orchestration, and Golang backend infrastructure developer. ACM ICPC regional finalist.',
    skills: [
      { name: 'Python', level: 'Advanced', verified: true },
      { name: 'Docker', level: 'Advanced', verified: true },
      { name: 'PostgreSQL', level: 'Advanced', verified: true },
      { name: 'Git', level: 'Advanced', verified: true },
      { name: 'Node.js', level: 'Intermediate', verified: true },
    ],
    availability: 'Summer 2027',
    preferredType: 'Hybrid',
    verifiedByInstitution: true,
    verifiedAt: '2026-08-30T16:00:00.000Z',
    verifiedBy: 'IIT Delhi Placement & Career Cell',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-demo-7',
    name: 'Ishita Patel',
    email: 'ishita.patel@dtu.ac.in',
    college: 'Delhi Technological University',
    institutionId: 'inst-dtu',
    department: 'Software Engineering',
    degree: 'B.Tech in Software Engineering',
    yearOfStudy: '4th Year (Class of 2026)',
    cgpa: '8.80 / 10',
    bio: 'Full stack engineer with a flair for clean architecture, API gateway development, and automated test-driven development.',
    skills: [
      { name: 'React', level: 'Advanced', verified: false },
      { name: 'TypeScript', level: 'Intermediate', verified: false },
      { name: 'PostgreSQL', level: 'Intermediate', verified: false },
      { name: 'Node.js', level: 'Intermediate', verified: false },
    ],
    availability: 'Available Immediately (Remote/In-office)',
    preferredType: 'Remote',
    verifiedByInstitution: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-skit-1',
    name: 'Rohan Agarwal',
    email: 'rohan.agarwal@skit.ac.in',
    college: 'Swami Keshvanand Institute of Technology (SKIT Jaipur)',
    institutionId: 'inst-skit-jaipur',
    department: 'Computer Science & Engineering',
    degree: 'B.Tech in Computer Science & Engineering',
    yearOfStudy: '3rd Year (Class of 2027)',
    cgpa: '9.15 / 10',
    bio: 'Full-stack developer proficient in React, TypeScript, Node.js, and Cloud architectures. Active SIH hackathon team lead.',
    skills: [
      { name: 'React', level: 'Advanced', verified: true },
      { name: 'Node.js', level: 'Intermediate', verified: true },
      { name: 'TypeScript', level: 'Intermediate', verified: true },
      { name: 'PostgreSQL', level: 'Intermediate', verified: true },
      { name: 'Python', level: 'Intermediate', verified: false },
    ],
    availability: 'Summer 2027',
    preferredType: 'Hybrid',
    verifiedByInstitution: true,
    verifiedAt: '2026-08-28T10:00:00.000Z',
    verifiedBy: 'SKIT Jaipur Career & Placement Cell',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'student-skit-2',
    name: 'Pooja Choudhary',
    email: 'pooja.choudhary@skit.ac.in',
    college: 'Swami Keshvanand Institute of Technology (SKIT Jaipur)',
    institutionId: 'inst-skit-jaipur',
    department: 'Artificial Intelligence & Data Science',
    degree: 'B.Tech in AI & Data Science',
    yearOfStudy: '4th Year (Class of 2026)',
    cgpa: '8.95 / 10',
    bio: 'Machine learning practitioner specializing in NLP and Computer Vision. Seeking industry AI internship for graduation semester.',
    skills: [
      { name: 'Python', level: 'Advanced', verified: true },
      { name: 'Machine Learning', level: 'Advanced', verified: true },
      { name: 'TensorFlow', level: 'Intermediate', verified: true },
      { name: 'Docker', level: 'Intermediate', verified: false },
    ],
    availability: 'Immediate (Remote/Hybrid)',
    preferredType: 'Remote',
    verifiedByInstitution: true,
    verifiedAt: '2026-08-25T11:00:00.000Z',
    verifiedBy: 'SKIT Jaipur Career & Placement Cell',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const SEED_STUDENT: StudentProfile = SEED_STUDENTS[0];

export const SEED_COMPANIES: CompanyProfile[] = [
  {
    id: 'company-finsecure',
    name: 'FinSecure Cloud Technologies',
    industry: 'FinTech & Cloud Security',
    website: 'https://finsecure.cloud',
    location: 'Bangalore, Karnataka (Hybrid)',
    description: 'Enterprise grade financial cloud infrastructure and fraud prevention pipelines serving top tier banks.',
    contactEmail: 'internships@finsecure.cloud',
    verified: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'company-neurocraft',
    name: 'NeuroCraft AI Labs',
    industry: 'Artificial Intelligence & DeepTech',
    website: 'https://neurocraft.ai',
    location: 'Hyderabad, Telangana (Remote-Friendly)',
    description: 'Pioneering multimodal foundation models, retrieval-augmented intelligence, and automated document synthesis.',
    contactEmail: 'talent@neurocraft.ai',
    verified: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'company-zenoedu',
    name: 'ZenoEdu Learning Platforms',
    industry: 'EdTech & Digital Classrooms',
    website: 'https://zenoedu.org',
    location: 'Pune, Maharashtra (Remote)',
    description: 'Interactive STEM education systems powering over 500+ Indian universities and technical institutes.',
    contactEmail: 'careers@zenoedu.org',
    verified: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'company-robonexus',
    name: 'RoboNexus Autonomous Systems',
    industry: 'Robotics & Embedded IoT',
    website: 'https://robonexus.tech',
    location: 'Gurugram, Haryana (In-office)',
    description: 'Autonomous guided vehicles, warehouse drone logistics, and real-time vision-based industrial safety.',
    contactEmail: 'hr@robonexus.tech',
    verified: true,
    createdAt: new Date().toISOString(),
  },
];

export const SEED_INTERNSHIPS: InternshipPosting[] = [
  {
    id: 'intern-fs-1',
    companyId: 'company-finsecure',
    companyName: 'FinSecure Cloud Technologies',
    companyLocation: 'Bangalore / Hybrid',
    title: 'Full Stack Web Platform Intern',
    roleType: 'Hybrid',
    duration: '6 Months',
    stipend: '₹35,000 / month',
    requiredSkills: ['React', 'TypeScript', 'Node.js', 'Tailwind CSS'],
    optionalSkills: ['PostgreSQL', 'Docker'],
    description: 'Join our developer experience team building high-performance financial dashboards, transaction monitors, and micro-frontend modules.',
    responsibilities: [
      'Develop responsive dashboard widgets in React and TypeScript',
      'Integrate RESTful microservices with Node.js',
      'Participate in peer code reviews and sprint retrospectives',
      'Optimize bundle loading speeds and Core Web Vitals',
    ],
    openPositions: 3,
    deadline: 'Oct 30, 2026',
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
    applicantsCount: 5,
  },
  {
    id: 'intern-ai-2',
    companyId: 'company-neurocraft',
    companyName: 'NeuroCraft AI Labs',
    companyLocation: 'Hyderabad / Remote',
    title: 'AI & Applied ML Research Intern',
    roleType: 'Remote',
    duration: '3 - 6 Months',
    stipend: '₹40,000 / month',
    requiredSkills: ['Python', 'Machine Learning', 'NLP'],
    optionalSkills: ['PyTorch', 'Git', 'Docker'],
    description: 'Work alongside lead research scientists to build enterprise document summarization engines, benchmark evaluation suites, and vector search pipelines.',
    responsibilities: [
      'Fine-tune open weights transformer models for structured extraction',
      'Build evaluation test harnesses and error analysis suites',
      'Prototype Python microservices for streaming inference',
      'Collaborate on SIH research papers and benchmark publications',
    ],
    openPositions: 2,
    deadline: 'Nov 15, 2026',
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
    applicantsCount: 8,
  },
  {
    id: 'intern-fe-3',
    companyId: 'company-zenoedu',
    companyName: 'ZenoEdu Learning Platforms',
    companyLocation: 'Remote',
    title: 'Frontend UI/UX Engineering Intern',
    roleType: 'Remote',
    duration: '3 Months',
    stipend: '₹25,000 / month',
    requiredSkills: ['React', 'Tailwind CSS', 'JavaScript'],
    optionalSkills: ['TypeScript', 'UI/UX', 'Figma'],
    description: 'Craft accessible, delightful interactive components for student learning portals, quizzes, and collaborative whiteboard modules.',
    responsibilities: [
      'Implement pixel-perfect responsive components from Figma designs',
      'Ensure WCAG 2.1 AA accessibility standards across dark and light modes',
      'Integrate interactive canvas features and animation sequences',
      'Work closely with educational curriculum designers',
    ],
    openPositions: 4,
    deadline: 'Nov 01, 2026',
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
    applicantsCount: 3,
  },
  {
    id: 'intern-devops-4',
    companyId: 'company-finsecure',
    companyName: 'FinSecure Cloud Technologies',
    companyLocation: 'Bangalore, Karnataka',
    title: 'Cloud Infrastructure & DevOps Intern',
    roleType: 'In-office',
    duration: '6 Months',
    stipend: '₹30,000 / month',
    requiredSkills: ['Docker', 'AWS', 'Linux'],
    optionalSkills: ['Kubernetes', 'Python', 'CI/CD'],
    description: 'Help manage automated deployment pipelines, monitor containerized cluster health, and implement security scanners for multi-tenant deployments.',
    responsibilities: [
      'Automate GitHub Actions workflows for continuous integration',
      'Configure Prometheus and Grafana alerts for latency spikes',
      'Deploy containerized microservices to Kubernetes clusters',
      'Audit access control policies and secrets management',
    ],
    openPositions: 2,
    deadline: 'Oct 20, 2026',
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24 * 5).toISOString(),
    applicantsCount: 2,
  },
  {
    id: 'intern-robotics-5',
    companyId: 'company-robonexus',
    companyName: 'RoboNexus Autonomous Systems',
    companyLocation: 'Gurugram, Haryana',
    title: 'Embedded IoT & Robotics Engineering Intern',
    roleType: 'In-office',
    duration: '6 Months',
    stipend: '₹32,000 / month',
    requiredSkills: ['C++', 'Python', 'Robotics'],
    optionalSkills: ['ROS', 'Linux', 'Computer Vision'],
    description: 'Test, calibrate, and write drivers for industrial sensor arrays, LiDAR mapping nodes, and autonomous navigation rovers.',
    responsibilities: [
      'Develop embedded sensor telemetry logging routines in C++',
      'Calibrate camera-LiDAR fusion algorithms on test track',
      'Assist hardware integration of brushless motor drivers',
      'Document safety protocols for autonomous testing',
    ],
    openPositions: 1,
    deadline: 'Nov 30, 2026',
    status: 'active',
    createdAt: new Date(Date.now() - 3600000 * 24 * 6).toISOString(),
    applicantsCount: 1,
  },
];

export const SEED_APPLICATIONS: ApplicationRecord[] = [
  {
    id: 'app-seed-1',
    internshipId: 'intern-fs-1',
    internshipTitle: 'Full Stack Web Platform Intern',
    companyId: 'company-finsecure',
    companyName: 'FinSecure Cloud Technologies',
    studentId: 'student-demo-1',
    studentName: 'Aarav Sharma',
    studentEmail: 'aarav.sharma@sih.edu.in',
    studentCollege: 'National Institute of Technology, Trichy',
    studentDegree: 'B.Tech in Computer Science',
    matchScore: 92,
    matchedSkills: ['React', 'TypeScript', 'Node.js', 'Tailwind CSS', 'PostgreSQL'],
    missingSkills: ['Docker'],
    coverNote: 'I have built multiple production-grade web applications with React, TypeScript, and Node.js. Excited to contribute to FinSecure!',
    status: 'shortlisted',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 1).toISOString(),
  },
  {
    id: 'app-seed-2',
    internshipId: 'intern-ai-2',
    internshipTitle: 'AI & Machine Learning Research Intern',
    companyId: 'company-neurocraft',
    companyName: 'NeuroCraft AI Labs',
    studentId: 'student-demo-2',
    studentName: 'Priya Venkat',
    studentEmail: 'priya.venkat@sih.edu.in',
    studentCollege: 'National Institute of Technology, Trichy',
    studentDegree: 'B.Tech in Data Science & AI',
    matchScore: 95,
    matchedSkills: ['Python', 'Machine Learning', 'PyTorch', 'Data Analysis'],
    missingSkills: [],
    coverNote: 'Published work in transformer attention analysis and LLM evaluation benchmarks. Strong fit for multimodal foundation research.',
    status: 'accepted',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(),
  },
  {
    id: 'app-seed-3',
    internshipId: 'intern-robotics-5',
    internshipTitle: 'Embedded IoT & Robotics Engineering Intern',
    companyId: 'company-robonexus',
    companyName: 'RoboNexus Autonomous Systems',
    studentId: 'student-demo-3',
    studentName: 'Rohan Deshmukh',
    studentEmail: 'rohan.deshmukh@sih.edu.in',
    studentCollege: 'National Institute of Technology, Trichy',
    studentDegree: 'B.Tech in Electronics & Embedded Systems',
    matchScore: 88,
    matchedSkills: ['C++', 'Python', 'Robotics', 'Linux'],
    missingSkills: ['ROS'],
    coverNote: 'Deep interest in hardware driver programming, brushless motor controllers, and sensor fusion algorithms.',
    status: 'reviewing',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
  },
  {
    id: 'app-seed-4',
    internshipId: 'intern-fe-3',
    internshipTitle: 'Frontend UI/UX Engineering Intern',
    companyId: 'company-zenoedu',
    companyName: 'ZenoEdu Learning Platforms',
    studentId: 'student-demo-4',
    studentName: 'Ananya Sen',
    studentEmail: 'ananya.sen@sih.edu.in',
    studentCollege: 'National Institute of Technology, Trichy',
    studentDegree: 'B.Tech in Computer Science',
    matchScore: 84,
    matchedSkills: ['React', 'Tailwind CSS', 'JavaScript'],
    missingSkills: ['Figma'],
    coverNote: 'Skilled in component library craft, interactive UI animations, and accessible web standards.',
    status: 'shortlisted',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 4).toISOString(),
  },
  {
    id: 'app-seed-5',
    internshipId: 'intern-devops-4',
    internshipTitle: 'Cloud Infrastructure & DevOps Intern',
    companyId: 'company-finsecure',
    companyName: 'FinSecure Cloud Technologies',
    studentId: 'student-demo-5',
    studentName: 'Kabir Mehra',
    studentEmail: 'kabir.mehra@sih.edu.in',
    studentCollege: 'National Institute of Technology, Trichy',
    studentDegree: 'B.Tech in Computer Science',
    matchScore: 82,
    matchedSkills: ['Docker', 'Git', 'PostgreSQL'],
    missingSkills: ['Kubernetes'],
    coverNote: 'Experience managing containerized services, automated CI/CD pipelines, and relational database migrations.',
    status: 'applied',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 5).toISOString(),
  },
  {
    id: 'app-seed-6',
    internshipId: 'intern-devops-4',
    internshipTitle: 'Cloud Infrastructure & DevOps Intern',
    companyId: 'company-finsecure',
    companyName: 'FinSecure Cloud Technologies',
    studentId: 'student-demo-6',
    studentName: 'Devendra Verma',
    studentEmail: 'devendra.v@iitd.ac.in',
    studentCollege: 'Indian Institute of Technology, Delhi',
    studentDegree: 'B.Tech in Computer Science',
    matchScore: 90,
    matchedSkills: ['Docker', 'PostgreSQL', 'Git', 'Python'],
    missingSkills: [],
    coverNote: 'Built distributed systems and container orchestration frameworks. Regional ACM ICPC finalist.',
    status: 'accepted',
    appliedAt: new Date(Date.now() - 3600000 * 24 * 2).toISOString(),
  },
];

export const SEED_NOTIFICATIONS: NotificationRecord[] = [
  {
    id: 'notif-student-1',
    recipientId: 'student-demo-1',
    recipientType: 'student',
    type: 'internship_match',
    title: 'High-Match Opportunity: Full Stack Web Platform Intern',
    message: 'FinSecure Cloud Technologies published a role with 92% compatibility matching your React, TypeScript, and Node.js skills.',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    linkId: 'intern-fs-1',
    metadata: {
      matchScore: 92,
      internshipTitle: 'Full Stack Web Platform Intern',
      companyName: 'FinSecure Cloud Technologies',
      matchedSkills: ['React', 'TypeScript', 'Node.js', 'Tailwind CSS'],
    },
  },
  {
    id: 'notif-student-2',
    recipientId: 'student-demo-1',
    recipientType: 'student',
    type: 'internship_match',
    title: 'Skill Match Alert: Frontend UI/UX Engineering Intern',
    message: 'ZenoEdu Learning Platforms has a remote role matching your React & Tailwind proficiencies (75% match score).',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    linkId: 'intern-fe-3',
    metadata: {
      matchScore: 75,
      internshipTitle: 'Frontend UI/UX Engineering Intern',
      companyName: 'ZenoEdu Learning Platforms',
      matchedSkills: ['React', 'Tailwind CSS'],
    },
  },
  {
    id: 'notif-student-3',
    recipientId: 'student-demo-1',
    recipientType: 'student',
    type: 'application_status',
    title: 'Application Shortlisted!',
    message: 'FinSecure Cloud Technologies shortlisted your profile for the Full Stack Web Platform Intern position.',
    read: true,
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    linkId: 'app-seed-1',
    metadata: {
      internshipTitle: 'Full Stack Web Platform Intern',
      companyName: 'FinSecure Cloud Technologies',
      newStatus: 'shortlisted',
    },
  },
  {
    id: 'notif-company-1',
    recipientId: 'company-finsecure',
    recipientType: 'company',
    type: 'application_received',
    title: 'New Applicant: Aarav Sharma',
    message: 'Aarav Sharma (NIT, 8.92 CGPA) applied for Full Stack Web Platform Intern with an exceptional 92% skill match score.',
    read: false,
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    linkId: 'app-seed-1',
    metadata: {
      matchScore: 92,
      internshipTitle: 'Full Stack Web Platform Intern',
      studentName: 'Aarav Sharma',
      studentCollege: 'National Institute of Technology (NIT)',
    },
  },
];

// Helper functions to interact with Firestore with fallback to LocalStorage
export async function fetchAllInternships(): Promise<InternshipPosting[]> {
  try {
    const colRef = collection(db, 'internships');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id } as InternshipPosting));
    }
  } catch (err) {
    console.warn('Firestore fetch internships fallback to local seed:', err);
  }

  // fallback to localStorage or seed
  const cached = localStorage.getItem('sih_internships');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_INTERNSHIPS;
}

export async function fetchAllCompanies(): Promise<CompanyProfile[]> {
  try {
    const colRef = collection(db, 'companies');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id } as CompanyProfile));
    }
  } catch (err) {
    console.warn('Firestore fetch companies fallback to local seed:', err);
  }

  const cached = localStorage.getItem('sih_companies');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_COMPANIES;
}

export async function fetchAllInstitutions(): Promise<InstitutionProfile[]> {
  try {
    const colRef = collection(db, 'institutions');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id } as InstitutionProfile));
    }
  } catch (err) {
    console.warn('Firestore fetch institutions fallback to local seed:', err);
  }

  const cached = localStorage.getItem('sih_institutions');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_INSTITUTIONS;
}

export async function saveInstitutionProfile(institution: InstitutionProfile): Promise<void> {
  const cached = localStorage.getItem('sih_institutions');
  let list: InstitutionProfile[] = cached ? JSON.parse(cached) : [...SEED_INSTITUTIONS];
  const idx = list.findIndex((inst) => inst.id === institution.id);
  if (idx >= 0) list[idx] = institution;
  else list.push(institution);
  localStorage.setItem('sih_institutions', JSON.stringify(list));

  try {
    const docRef = doc(db, 'institutions', institution.id);
    await setDoc(docRef, institution, { merge: true });
  } catch (err) {
    console.warn('Firestore save institution error:', err);
  }
}

export async function fetchAllStudents(): Promise<StudentProfile[]> {
  try {
    const colRef = collection(db, 'students');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id } as StudentProfile));
    }
  } catch (err) {
    console.warn('Firestore fetch all students fallback:', err);
  }

  const cached = localStorage.getItem('sih_all_students');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_STUDENTS;
}

export async function verifyStudentSkillProfile(
  studentId: string,
  verified: boolean,
  verifiedBy: string = 'Institution Academic & Placement Cell'
): Promise<StudentProfile | null> {
  // Update local cache
  const cachedList = localStorage.getItem('sih_all_students');
  let list: StudentProfile[] = cachedList ? JSON.parse(cachedList) : [...SEED_STUDENTS];
  const idx = list.findIndex((s) => s.id === studentId);
  const now = new Date().toISOString();

  let updatedStudent: StudentProfile | null = null;
  if (idx >= 0) {
    list[idx] = {
      ...list[idx],
      verifiedByInstitution: verified,
      verifiedAt: verified ? now : undefined,
      verifiedBy: verified ? verifiedBy : undefined,
      skills: list[idx].skills.map((skill) => ({
        ...skill,
        verified: verified ? true : skill.verified,
      })),
      updatedAt: now,
    };
    updatedStudent = list[idx];
    localStorage.setItem('sih_all_students', JSON.stringify(list));
    localStorage.setItem(`sih_student_${studentId}`, JSON.stringify(list[idx]));
  }

  // Sync to Firestore
  try {
    const docRef = doc(db, 'students', studentId);
    if (updatedStudent) {
      await updateDoc(docRef, {
        verifiedByInstitution: verified,
        verifiedAt: verified ? now : null,
        verifiedBy: verified ? verifiedBy : null,
        skills: updatedStudent.skills,
        updatedAt: now,
      });
    }
  } catch (err) {
    console.warn('Firestore verifyStudentSkillProfile error:', err);
  }

  return updatedStudent;
}

export async function fetchStudentProfile(id: string): Promise<StudentProfile> {
  try {
    const colRef = collection(db, 'students');
    const snap = await getDocs(colRef);
    const found = snap.docs.find((d) => d.id === id);
    if (found) {
      return { ...found.data(), id: found.id } as StudentProfile;
    }
  } catch (err) {
    console.warn('Firestore fetch student fallback:', err);
  }

  const cached = localStorage.getItem(`sih_student_${id}`);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_STUDENT;
}

export async function saveStudentProfile(profile: StudentProfile): Promise<void> {
  // Save to local cache first for instantaneous UI update
  localStorage.setItem(`sih_student_${profile.id}`, JSON.stringify(profile));

  try {
    const docRef = doc(db, 'students', profile.id);
    await setDoc(docRef, profile, { merge: true });
  } catch (err) {
    console.warn('Firestore save student error:', err);
  }
}

export async function saveCompanyProfile(company: CompanyProfile): Promise<void> {
  const cached = localStorage.getItem('sih_companies');
  let list: CompanyProfile[] = cached ? JSON.parse(cached) : [...SEED_COMPANIES];
  const idx = list.findIndex((c) => c.id === company.id);
  if (idx >= 0) list[idx] = company;
  else list.push(company);
  localStorage.setItem('sih_companies', JSON.stringify(list));

  try {
    const docRef = doc(db, 'companies', company.id);
    await setDoc(docRef, company, { merge: true });
  } catch (err) {
    console.warn('Firestore save company error:', err);
  }
}

export async function saveInternship(internship: InternshipPosting): Promise<void> {
  const cached = localStorage.getItem('sih_internships');
  let list: InternshipPosting[] = cached ? JSON.parse(cached) : [...SEED_INTERNSHIPS];
  const idx = list.findIndex((i) => i.id === internship.id);
  if (idx >= 0) list[idx] = internship;
  else list.unshift(internship);
  localStorage.setItem('sih_internships', JSON.stringify(list));

  try {
    const docRef = doc(db, 'internships', internship.id);
    await setDoc(docRef, internship, { merge: true });
  } catch (err) {
    console.warn('Firestore save internship error:', err);
  }
}

export async function fetchApplications(): Promise<ApplicationRecord[]> {
  try {
    const colRef = collection(db, 'applications');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      return snap.docs.map((doc) => ({ ...doc.data(), id: doc.id } as ApplicationRecord));
    }
  } catch (err) {
    console.warn('Firestore fetch applications fallback:', err);
  }

  const cached = localStorage.getItem('sih_applications');
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }
  return SEED_APPLICATIONS;
}

export async function submitApplication(appRecord: ApplicationRecord): Promise<void> {
  const cached = localStorage.getItem('sih_applications');
  let list: ApplicationRecord[] = cached ? JSON.parse(cached) : [...SEED_APPLICATIONS];
  list.unshift(appRecord);
  localStorage.setItem('sih_applications', JSON.stringify(list));

  try {
    const docRef = doc(db, 'applications', appRecord.id);
    await setDoc(docRef, appRecord);
  } catch (err) {
    console.warn('Firestore submit application error:', err);
  }
}

export async function updateApplicationStatus(
  appId: string,
  status: ApplicationRecord['status']
): Promise<void> {
  const cached = localStorage.getItem('sih_applications');
  if (cached) {
    let list: ApplicationRecord[] = JSON.parse(cached);
    const item = list.find((a) => a.id === appId);
    if (item) {
      item.status = status;
      localStorage.setItem('sih_applications', JSON.stringify(list));
    }
  }

  try {
    const docRef = doc(db, 'applications', appId);
    await updateDoc(docRef, { status });
  } catch (err) {
    console.warn('Firestore update application status error:', err);
  }
}

// ----------------- Notification Services -----------------

export async function fetchNotifications(
  recipientId: string,
  recipientType: 'student' | 'company'
): Promise<NotificationRecord[]> {
  try {
    const colRef = collection(db, 'notifications');
    const snap = await getDocs(colRef);
    if (!snap.empty) {
      const items: NotificationRecord[] = [];
      snap.forEach((d) => {
        const item = { ...d.data(), id: d.id } as NotificationRecord;
        if (item.recipientId === recipientId || item.recipientType === recipientType) {
          items.push(item);
        }
      });
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      if (items.length > 0) {
        localStorage.setItem(`sih_notifications_${recipientId}`, JSON.stringify(items));
        return items;
      }
    }
  } catch (err) {
    console.warn('Firestore fetch notifications fallback:', err);
  }

  const cached = localStorage.getItem(`sih_notifications_${recipientId}`);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // ignore
    }
  }

  const defaults = SEED_NOTIFICATIONS.filter((n) => n.recipientId === recipientId);
  return defaults;
}

export function listenToNotifications(
  callbackOrRecipientId: string | ((notifs: NotificationRecord[]) => void),
  recipientType?: 'student' | 'company',
  callback?: (notifs: NotificationRecord[]) => void
): () => void {
  const actualCallback =
    typeof callbackOrRecipientId === 'function' ? callbackOrRecipientId : callback;
  const actualRecipientId =
    typeof callbackOrRecipientId === 'string' ? callbackOrRecipientId : undefined;

  if (!actualCallback) return () => {};

  try {
    const colRef = collection(db, 'notifications');
    const unsubscribe = onSnapshot(
      colRef,
      (snapshot) => {
        const list: NotificationRecord[] = [];
        snapshot.forEach((d) => {
          const item = { ...d.data(), id: d.id } as NotificationRecord;
          if (!actualRecipientId) {
            list.push(item);
          } else if (
            item.recipientId === actualRecipientId ||
            (recipientType && item.recipientType === recipientType && !item.recipientId)
          ) {
            list.push(item);
          }
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

        if (list.length > 0) {
          if (actualRecipientId) {
            localStorage.setItem(`sih_notifications_${actualRecipientId}`, JSON.stringify(list));
          } else {
            localStorage.setItem('sih_notifications_all', JSON.stringify(list));
          }
          actualCallback(list);
        } else {
          const cacheKey = actualRecipientId ? `sih_notifications_${actualRecipientId}` : 'sih_notifications_all';
          const cached = localStorage.getItem(cacheKey);
          if (cached) {
            actualCallback(JSON.parse(cached));
          } else {
            const defaults = actualRecipientId
              ? SEED_NOTIFICATIONS.filter((n) => n.recipientId === actualRecipientId)
              : SEED_NOTIFICATIONS;
            actualCallback(defaults);
          }
        }
      },
      (err) => {
        console.warn('Firestore onSnapshot notifications error, using local state:', err);
        const cacheKey = actualRecipientId ? `sih_notifications_${actualRecipientId}` : 'sih_notifications_all';
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
          actualCallback(JSON.parse(cached));
        } else {
          const defaults = actualRecipientId
            ? SEED_NOTIFICATIONS.filter((n) => n.recipientId === actualRecipientId)
            : SEED_NOTIFICATIONS;
          actualCallback(defaults);
        }
      }
    );
    return unsubscribe;
  } catch (err) {
    console.warn('Failed to attach realtime notification listener:', err);
    return () => {};
  }
}

export async function saveNotification(notif: NotificationRecord): Promise<void> {
  const key = `sih_notifications_${notif.recipientId}`;
  const cached = localStorage.getItem(key);
  let list: NotificationRecord[] = cached ? JSON.parse(cached) : [];
  list = [notif, ...list.filter((n) => n.id !== notif.id)];
  localStorage.setItem(key, JSON.stringify(list));

  try {
    const docRef = doc(db, 'notifications', notif.id);
    await setDoc(docRef, notif, { merge: true });
  } catch (err) {
    console.warn('Firestore save notification error:', err);
  }
}

export async function markNotificationAsRead(notifId: string, recipientId?: string): Promise<void> {
  if (recipientId) {
    const key = `sih_notifications_${recipientId}`;
    const cached = localStorage.getItem(key);
    if (cached) {
      const list: NotificationRecord[] = JSON.parse(cached);
      const item = list.find((n) => n.id === notifId);
      if (item) {
        item.read = true;
        localStorage.setItem(key, JSON.stringify(list));
      }
    }
  }

  try {
    const docRef = doc(db, 'notifications', notifId);
    await updateDoc(docRef, { read: true });
  } catch (err) {
    console.warn('Firestore markNotificationAsRead error:', err);
  }
}

export async function markAllNotificationsAsRead(
  recipientId?: string,
  notifs?: NotificationRecord[]
): Promise<void> {
  if (recipientId && notifs) {
    const key = `sih_notifications_${recipientId}`;
    const updated = notifs.map((n) => ({ ...n, read: true }));
    localStorage.setItem(key, JSON.stringify(updated));
  }

  try {
    if (notifs) {
      const unread = notifs.filter((n) => !n.read);
      for (const n of unread) {
        const docRef = doc(db, 'notifications', n.id);
        await updateDoc(docRef, { read: true });
      }
    } else {
      const colRef = collection(db, 'notifications');
      const snap = await getDocs(colRef);
      for (const d of snap.docs) {
        if (!d.data().read) {
          await updateDoc(d.ref, { read: true });
        }
      }
    }
  } catch (err) {
    console.warn('Firestore markAllNotificationsAsRead error:', err);
  }
}

/**
 * Seed initial data to Firestore if not already populated
 */
export async function seedInitialFirestoreData(): Promise<void> {
  try {
    // Seed institutions if empty
    const instCol = collection(db, 'institutions');
    const instSnap = await getDocs(instCol);
    if (instSnap.empty) {
      for (const inst of SEED_INSTITUTIONS) {
        await setDoc(doc(db, 'institutions', inst.id), inst);
      }
    }

    // Seed students if empty or only 1 exists
    const studCol = collection(db, 'students');
    const studSnap = await getDocs(studCol);
    if (studSnap.empty || studSnap.docs.length < SEED_STUDENTS.length) {
      for (const student of SEED_STUDENTS) {
        await setDoc(doc(db, 'students', student.id), student, { merge: true });
      }
    }

    const colRef = collection(db, 'internships');
    const snap = await getDocs(colRef);
    if (snap.empty) {
      // Seed companies
      for (const comp of SEED_COMPANIES) {
        await setDoc(doc(db, 'companies', comp.id), comp);
      }

      // Seed internships
      for (const intern of SEED_INTERNSHIPS) {
        await setDoc(doc(db, 'internships', intern.id), intern);
      }

      // Seed applications
      for (const app of SEED_APPLICATIONS) {
        await setDoc(doc(db, 'applications', app.id), app);
      }

      // Seed notifications
      for (const notif of SEED_NOTIFICATIONS) {
        await setDoc(doc(db, 'notifications', notif.id), notif);
      }
      console.log('Successfully seeded initial Firestore database records including institutions and students.');
    }
  } catch (err) {
    console.warn('Firestore initial seeding error (will use local fallback):', err);
  }
}

// -------------------------------------------------------------
// Authentication & User Accounts (Firebase Auth & Firestore)
// -------------------------------------------------------------

const STORAGE_ACTIVE_USER_KEY = 'sih_active_authenticated_user';

export async function saveUserAccount(account: UserAccount): Promise<void> {
  try {
    localStorage.setItem(STORAGE_ACTIVE_USER_KEY, JSON.stringify(account));
    const userDocRef = doc(db, 'users', account.uid);
    await setDoc(userDocRef, account, { merge: true });
  } catch (err) {
    console.warn('Failed to save user account to Firestore (cached locally):', err);
  }
}

export async function fetchUserAccount(uid: string): Promise<UserAccount | null> {
  try {
    const userDocRef = doc(db, 'users', uid);
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      return snap.data() as UserAccount;
    }
  } catch (err) {
    console.warn('Firestore fetchUserAccount error:', err);
  }

  // Fallback to local cache if offline
  const cached = localStorage.getItem(STORAGE_ACTIVE_USER_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as UserAccount;
      if (parsed.uid === uid) return parsed;
    } catch {
      // ignore
    }
  }
  return null;
}

export async function signUpUser(
  email: string,
  username: string,
  password: string,
  accountType: AccountType,
  metadata?: {
    institutionId?: string;
    institutionName?: string;
    companyId?: string;
    companyName?: string;
  }
): Promise<UserAccount> {
  const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
  const fbUser = userCredential.user;

  try {
    await updateProfile(fbUser, { displayName: username });
  } catch (err) {
    console.warn('Error setting displayName on Firebase user:', err);
  }

  let role: RoleView = 'student';
  if (accountType === 'Institution') role = 'institution';
  if (accountType === 'Industry') role = 'industry';

  let instId = metadata?.institutionId;
  let instName = metadata?.institutionName;
  if (accountType === 'Institution') {
    instId = instId || 'inst-skit-jaipur';
    instName = instName || 'Swami Keshvanand Institute of Technology (SKIT Jaipur)';
  }

  let compId = metadata?.companyId;
  let compName = metadata?.companyName;
  if (accountType === 'Industry') {
    compId = compId || 'company-finsecure';
    compName = compName || 'FinSecure Cloud Technologies';
  }

  const userAccount: UserAccount = {
    uid: fbUser.uid,
    email: fbUser.email || email.trim(),
    username: username.trim(),
    accountType,
    role,
    institutionId: instId,
    institutionName: instName,
    companyId: compId,
    companyName: compName,
    createdAt: new Date().toISOString(),
  };

  await saveUserAccount(userAccount);

  // If student account, register basic student profile in Firestore
  if (accountType === 'Student') {
    try {
      const studentDocRef = doc(db, 'students', fbUser.uid);
      const studentSnap = await getDoc(studentDocRef);
      if (!studentSnap.exists()) {
        const studentProfile: StudentProfile = {
          id: fbUser.uid,
          name: username.trim(),
          email: fbUser.email || email.trim(),
          college: instName || 'Swami Keshvanand Institute of Technology (SKIT Jaipur)',
          institutionId: instId || 'inst-skit-jaipur',
          department: 'Computer Science & Engineering',
          degree: 'B.Tech in Computer Science',
          yearOfStudy: '3rd Year (Class of 2027)',
          cgpa: '8.80 / 10',
          bio: 'Passionate engineering student eager to bridge academic learning with high-impact industry internships.',
          skills: [
            { name: 'React', level: 'Intermediate', verified: false },
            { name: 'TypeScript', level: 'Intermediate', verified: false },
            { name: 'Python', level: 'Intermediate', verified: false },
            { name: 'Git', level: 'Intermediate', verified: true },
          ],
          availability: 'Summer 2027',
          preferredType: 'Hybrid',
          verifiedByInstitution: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await setDoc(studentDocRef, studentProfile);
      }
    } catch (err) {
      console.warn('Could not initialize student doc in Firestore:', err);
    }
  }

  return userAccount;
}

export async function signInUser(email: string, password: string): Promise<UserAccount> {
  const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
  const fbUser = userCredential.user;

  let account = await fetchUserAccount(fbUser.uid);
  if (!account) {
    // If not found in Firestore yet, infer account profile
    const name = fbUser.displayName || email.split('@')[0];
    account = {
      uid: fbUser.uid,
      email: fbUser.email || email.trim(),
      username: name,
      accountType: 'Student',
      role: 'student',
      createdAt: new Date().toISOString(),
    };
    await saveUserAccount(account);
  }

  return account;
}

export async function signOutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (err) {
    console.warn('Firebase signOut error:', err);
  }
  localStorage.removeItem(STORAGE_ACTIVE_USER_KEY);
}

export function subscribeToAuthState(
  callback: (user: UserAccount | null) => void
): () => void {
  // Check local cache immediately for fast hydration
  const cached = localStorage.getItem(STORAGE_ACTIVE_USER_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as UserAccount;
      callback(parsed);
    } catch {
      // ignore
    }
  }

  return onAuthStateChanged(auth, async (fbUser) => {
    if (fbUser) {
      const account = await fetchUserAccount(fbUser.uid);
      if (account) {
        localStorage.setItem(STORAGE_ACTIVE_USER_KEY, JSON.stringify(account));
        callback(account);
      } else {
        const fallback: UserAccount = {
          uid: fbUser.uid,
          email: fbUser.email || '',
          username: fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
          accountType: 'Student',
          role: 'student',
          createdAt: new Date().toISOString(),
        };
        callback(fallback);
      }
    } else {
      localStorage.removeItem(STORAGE_ACTIVE_USER_KEY);
      callback(null);
    }
  });
}

/**
 * Demo Login Helper for instant role switching & quick evaluator login
 */
export async function demoLogin(
  accountType: AccountType,
  metadata?: { institutionId?: string; companyId?: string }
): Promise<UserAccount> {
  let userAccount: UserAccount;

  if (accountType === 'Student') {
    const student = SEED_STUDENTS[0];
    userAccount = {
      uid: student.id,
      email: student.email,
      username: student.name,
      accountType: 'Student',
      role: 'student',
      institutionId: student.institutionId || 'inst-nit-trichy',
      institutionName: student.college,
      createdAt: new Date().toISOString(),
    };
  } else if (accountType === 'Institution') {
    const instId = metadata?.institutionId || 'inst-skit-jaipur';
    const inst = SEED_INSTITUTIONS.find((i) => i.id === instId) || SEED_INSTITUTIONS[0];
    userAccount = {
      uid: `demo-inst-${inst.id}`,
      email: inst.contactEmail,
      username: `${inst.code} Placement & Academic Directorate`,
      accountType: 'Institution',
      role: 'institution',
      institutionId: inst.id,
      institutionName: inst.name,
      createdAt: new Date().toISOString(),
    };
  } else {
    const compId = metadata?.companyId || 'company-finsecure';
    const comp = SEED_COMPANIES.find((c) => c.id === compId) || SEED_COMPANIES[0];
    userAccount = {
      uid: `demo-company-${comp.id}`,
      email: comp.contactEmail,
      username: `${comp.name} Talent Acquisition`,
      accountType: 'Industry',
      role: 'industry',
      companyId: comp.id,
      companyName: comp.name,
      createdAt: new Date().toISOString(),
    };
  }

  await saveUserAccount(userAccount);
  return userAccount;
}

