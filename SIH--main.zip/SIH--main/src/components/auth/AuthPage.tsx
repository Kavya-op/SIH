import React, { useState } from 'react';
import {
  AccountType,
  UserAccount,
  InstitutionProfile,
  CompanyProfile,
} from '../../types';
import {
  signUpUser,
  signInUser,
  demoLogin,
} from '../../lib/firebase';
import {
  ShieldCheck,
  GraduationCap,
  Building2,
  School,
  Lock,
  Mail,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

interface AuthPageProps {
  institutions: InstitutionProfile[];
  companies: CompanyProfile[];
  onAuthSuccess: (userAccount: UserAccount) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  institutions,
  companies,
  onAuthSuccess,
}) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  // Form Fields
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [accountType, setAccountType] = useState<AccountType>('Student');

  // Institution / Industry selections
  const [selectedInstitutionId, setSelectedInstitutionId] = useState<string>(
    institutions.find((i) => i.id.includes('skit'))?.id || institutions[0]?.id || 'inst-skit-jaipur'
  );
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>(
    companies[0]?.id || 'company-finsecure'
  );

  // States
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessNotice(null);

    if (!email.trim()) {
      setErrorMessage('Please enter your email address.');
      return;
    }
    if (!password.trim()) {
      setErrorMessage('Please enter your password.');
      return;
    }
    if (authMode === 'signup' && !username.trim()) {
      setErrorMessage('Please enter a username or display name.');
      return;
    }
    if (authMode === 'signup' && password.length < 6) {
      setErrorMessage('Password must be at least 6 characters long.');
      return;
    }

    setIsSubmitting(true);

    try {
      if (authMode === 'signup') {
        const inst = institutions.find((i) => i.id === selectedInstitutionId);
        const comp = companies.find((c) => c.id === selectedCompanyId);

        const account = await signUpUser(
          email.trim(),
          username.trim(),
          password,
          accountType,
          {
            institutionId: accountType === 'Institution' ? (inst?.id || selectedInstitutionId) : undefined,
            institutionName: accountType === 'Institution' ? (inst?.name || 'Swami Keshvanand Institute of Technology (SKIT Jaipur)') : undefined,
            companyId: accountType === 'Industry' ? (comp?.id || selectedCompanyId) : undefined,
            companyName: accountType === 'Industry' ? (comp?.name || 'FinSecure Cloud Technologies') : undefined,
          }
        );

        setSuccessNotice('Account created successfully! Redirecting to your dashboard...');
        setTimeout(() => {
          onAuthSuccess(account);
        }, 500);
      } else {
        const account = await signInUser(email.trim(), password);
        setSuccessNotice('Authentication verified. Welcome back!');
        setTimeout(() => {
          onAuthSuccess(account);
        }, 500);
      }
    } catch (err: any) {
      console.error('Firebase Auth error:', err);
      let msg = 'Authentication failed. Please verify your credentials.';
      if (err.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered. Please switch to Sign In.';
      } else if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
        msg = 'Invalid email or password. If you are a new user, please click "Sign Up" to create an account.';
      } else if (err.code === 'auth/user-not-found') {
        msg = 'No account found with this email. Please switch to "Sign Up" to register.';
      } else if (err.code === 'auth/weak-password') {
        msg = 'Password is too weak. Please use at least 6 characters.';
      } else if (err.code === 'auth/invalid-email') {
        msg = 'The email address is improperly formatted.';
      } else if (err.code === 'auth/operation-not-allowed') {
        msg = 'Email/Password sign-in is not enabled yet in your Firebase Console. Please enable "Email/Password" under Authentication > Sign-in method, or use one of the Quick Role Previews below in the meantime.';
      } else if (err.message) {
        msg = err.message;
      }
      setErrorMessage(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickDemo = async (role: AccountType) => {
    setIsSubmitting(true);
    setErrorMessage(null);
    try {
      const inst = institutions.find((i) => i.id.includes('skit')) || institutions[0];
      const comp = companies[0];

      const account = await demoLogin(role, {
        institutionId: inst?.id,
        companyId: comp?.id,
      });

      setSuccessNotice(`Signed in as ${role}: ${account.username}`);
      setTimeout(() => {
        onAuthSuccess(account);
      }, 400);
    } catch (err) {
      console.warn('Demo login error:', err);
      setErrorMessage('Could not initialize demo session.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[88vh] flex flex-col items-center justify-center px-4 py-8 sm:px-6 lg:px-8">
      {/* Brand & Mission Banner */}
      <div className="w-full max-w-lg text-center mb-6">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Smart India Hackathon SIH26044</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
          AcademiaLink Portal
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600">
          Unified Skill-Powered Collaboration & Internship Matching Platform
        </p>
      </div>

      {/* Main Authentication Card */}
      <div
        id="auth-card"
        className="w-full max-w-lg bg-white rounded-2xl shadow-xl border border-slate-200/80 overflow-hidden"
      >
        {/* Navigation Tabs: Sign In vs Sign Up */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 p-1.5">
          <button
            id="tab-signin"
            type="button"
            onClick={() => {
              setAuthMode('signin');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
              authMode === 'signin'
                ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sign In
          </button>
          <button
            id="tab-signup"
            type="button"
            onClick={() => {
              setAuthMode('signup');
              setErrorMessage(null);
            }}
            className={`flex-1 py-2.5 text-sm font-semibold rounded-lg transition-all cursor-pointer ${
              authMode === 'signup'
                ? 'bg-white text-blue-600 shadow-sm border border-slate-200/60'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Create Account (Sign Up)
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-5">
          {/* Security Banner */}
          <div className="flex items-center justify-between text-xs text-slate-500 bg-slate-50 px-3.5 py-2 rounded-lg border border-slate-200">
            <span className="flex items-center gap-1.5 font-medium text-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Firebase Authentication
            </span>
            <span className="text-slate-400">256-bit Encrypted</span>
          </div>

          {/* Feedback Alerts */}
          {errorMessage && (
            <div
              id="auth-error-alert"
              className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs sm:text-sm text-rose-700 flex items-start gap-2.5 animate-in fade-in"
            >
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Authentication Alert</p>
                <p className="mt-0.5 text-rose-600 leading-relaxed">{errorMessage}</p>
              </div>
            </div>
          )}

          {successNotice && (
            <div
              id="auth-success-alert"
              className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs sm:text-sm text-emerald-700 flex items-start gap-2.5 animate-in fade-in"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">Success</p>
                <p className="mt-0.5 text-emerald-600 leading-relaxed">{successNotice}</p>
              </div>
            </div>
          )}

          {/* Sign Up Specific: Username */}
          {authMode === 'signup' && (
            <div className="space-y-1.5">
              <label
                htmlFor="auth-username"
                className="block text-xs font-bold uppercase tracking-wider text-slate-700"
              >
                Username / Full Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="auth-username"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder={
                    accountType === 'Student'
                      ? 'e.g., Rohan Sharma'
                      : accountType === 'Institution'
                      ? 'e.g., SKIT Placement Directorate'
                      : 'e.g., FinSecure Talent Team'
                  }
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                />
              </div>
            </div>
          )}

          {/* Email Input */}
          <div className="space-y-1.5">
            <label
              htmlFor="auth-email"
              className="block text-xs font-bold uppercase tracking-wider text-slate-700"
            >
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@organization.edu or name@company.com"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
              />
            </div>
          </div>

          {/* Password Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="auth-password"
                className="block text-xs font-bold uppercase tracking-wider text-slate-700"
              >
                Password
              </label>
              {authMode === 'signup' && (
                <span className="text-[11px] text-slate-400">Min. 6 characters</span>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                id="auth-password"
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 cursor-pointer"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Sign-Up Mandatory Dropdown: Account Type */}
          {authMode === 'signup' && (
            <div className="space-y-3 pt-1 border-t border-slate-100">
              <div className="space-y-1.5">
                <label
                  htmlFor="account-type-select"
                  className="block text-xs font-bold uppercase tracking-wider text-slate-700"
                >
                  Select Account Type
                </label>
                <div className="relative">
                  <select
                    id="account-type-select"
                    value={accountType}
                    onChange={(e) => setAccountType(e.target.value as AccountType)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-sm font-medium text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition cursor-pointer"
                  >
                    <option value="Student">Student (Internship Matching & Skill Verification)</option>
                    <option value="Institution">Institution (e.g., SKIT Jaipur - College Admin)</option>
                    <option value="Industry">Industry (Corporate Hiring & Project Partner)</option>
                  </select>
                </div>
                <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-1">
                  <HelpCircle className="w-3 h-3 text-slate-400 shrink-0" />
                  Your dashboard and navigation permissions will be automatically configured for this role.
                </p>
              </div>

              {/* Institution Sub-Selection (with SKIT Jaipur prominent) */}
              {accountType === 'Institution' && (
                <div className="space-y-1.5 p-3.5 bg-blue-50/70 border border-blue-200 rounded-xl">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-blue-900 uppercase tracking-wider">
                    <School className="w-4 h-4 text-blue-600" />
                    <span>Affiliated College / University</span>
                  </div>
                  <select
                    id="institution-select"
                    value={selectedInstitutionId}
                    onChange={(e) => setSelectedInstitutionId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-blue-300 rounded-lg text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
                  >
                    {institutions.map((inst) => (
                      <option key={inst.id} value={inst.id}>
                        {inst.name} ({inst.code})
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-blue-700">
                    Provides access to verify enrolled students and inspect matching analytics.
                  </p>
                </div>
              )}

              {/* Industry Sub-Selection */}
              {accountType === 'Industry' && (
                <div className="space-y-1.5 p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-xl">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900 uppercase tracking-wider">
                    <Building2 className="w-4 h-4 text-indigo-600" />
                    <span>Company / Enterprise Profile</span>
                  </div>
                  <select
                    id="company-select"
                    value={selectedCompanyId}
                    onChange={(e) => setSelectedCompanyId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-indigo-300 rounded-lg text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    {companies.map((comp) => (
                      <option key={comp.id} value={comp.id}>
                        {comp.name} — {comp.industry}
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-indigo-700">
                    Allows posting new internship opportunities and managing student applicants.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Submit Button */}
          <button
            id="auth-submit-button"
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold rounded-xl text-sm sm:text-base shadow-sm hover:shadow transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Processing...</span>
              </>
            ) : authMode === 'signup' ? (
              <>
                <span>Create Secure Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Sign In to Portal</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Logins for Instant Testing & Evaluation */}
        <div className="px-6 sm:px-8 py-5 bg-slate-50 border-t border-slate-200 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
              Quick Role Preview
            </span>
            <span className="text-[11px] text-slate-400">One-click evaluation</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <button
              id="demo-login-student"
              type="button"
              disabled={isSubmitting}
              onClick={() => handleQuickDemo('Student')}
              className="flex items-center sm:flex-col items-center justify-center gap-1.5 p-2.5 bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 rounded-xl text-slate-700 hover:text-blue-700 transition cursor-pointer text-left sm:text-center shadow-2xs"
            >
              <GraduationCap className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="text-xs">
                <p className="font-bold">Student</p>
                <p className="text-[10px] text-slate-500 truncate">Aarav Sharma</p>
              </div>
            </button>

            <button
              id="demo-login-institution"
              type="button"
              disabled={isSubmitting}
              onClick={() => handleQuickDemo('Institution')}
              className="flex items-center sm:flex-col items-center justify-center gap-1.5 p-2.5 bg-white hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 rounded-xl text-slate-700 hover:text-emerald-700 transition cursor-pointer text-left sm:text-center shadow-2xs"
            >
              <School className="w-4 h-4 text-emerald-600 shrink-0" />
              <div className="text-xs">
                <p className="font-bold">Institution</p>
                <p className="text-[10px] text-slate-500 truncate">SKIT Jaipur</p>
              </div>
            </button>

            <button
              id="demo-login-industry"
              type="button"
              disabled={isSubmitting}
              onClick={() => handleQuickDemo('Industry')}
              className="flex items-center sm:flex-col items-center justify-center gap-1.5 p-2.5 bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 rounded-xl text-slate-700 hover:text-indigo-700 transition cursor-pointer text-left sm:text-center shadow-2xs"
            >
              <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
              <div className="text-xs">
                <p className="font-bold">Industry</p>
                <p className="text-[10px] text-slate-500 truncate">FinSecure</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Trust & Compliance note */}
      <div className="mt-6 text-center text-xs text-slate-400 flex items-center justify-center gap-2">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
        <span>Role-Based Access Control (RBAC) enforced in Firestore Security Rules</span>
      </div>
    </div>
  );
};
