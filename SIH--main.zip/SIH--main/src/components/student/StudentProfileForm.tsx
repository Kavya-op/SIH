import React, { useState } from 'react';
import { StudentProfile, StudentSkill } from '../../types';
import { SkillTagger } from '../common/SkillTagger';
import {
  User,
  GraduationCap,
  Mail,
  FileText,
  Save,
  CheckCircle2,
  Sparkles,
  Github,
  Linkedin,
  Globe,
  Upload,
} from 'lucide-react';

interface StudentProfileFormProps {
  profile: StudentProfile;
  onSave: (updated: StudentProfile) => Promise<void>;
}

export const StudentProfileForm: React.FC<StudentProfileFormProps> = ({
  profile,
  onSave,
}) => {
  const [formData, setFormData] = useState<StudentProfile>(profile);
  const [isSaving, setIsSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [resumeExtractText, setResumeExtractText] = useState('');
  const [showExtractor, setShowExtractor] = useState(false);

  const handleSkillsChange = (newSkills: StudentSkill[]) => {
    setFormData((prev) => ({
      ...prev,
      skills: newSkills,
    }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      await onSave({
        ...formData,
        updatedAt: new Date().toISOString(),
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 2500);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };

  // Helper to extract skills from pasted resume text
  const handleExtractFromText = () => {
    if (!resumeExtractText.trim()) return;
    const commonVocabulary = [
      'React', 'TypeScript', 'JavaScript', 'Python', 'Node.js', 'Express',
      'HTML', 'CSS', 'Tailwind CSS', 'Next.js', 'Vue', 'Angular',
      'C++', 'C#', 'Java', 'Go', 'Rust', 'PHP',
      'SQL', 'PostgreSQL', 'MySQL', 'MongoDB', 'Redis',
      'Docker', 'Kubernetes', 'AWS', 'GCP', 'Azure', 'Linux', 'Git',
      'Machine Learning', 'Deep Learning', 'NLP', 'Computer Vision', 'PyTorch', 'TensorFlow',
      'Figma', 'UI/UX', 'REST API', 'GraphQL', 'Data Structures', 'Robotics', 'ROS'
    ];

    const found: StudentSkill[] = [...formData.skills];
    const textLower = resumeExtractText.toLowerCase();

    commonVocabulary.forEach((term) => {
      const regex = new RegExp(`\\b${term.toLowerCase()}\\b`, 'i');
      if (regex.test(textLower)) {
        if (!found.some((s) => s.name.toLowerCase() === term.toLowerCase())) {
          found.push({ name: term, level: 'Intermediate', verified: false });
        }
      }
    });

    setFormData((prev) => ({ ...prev, skills: found }));
    setResumeExtractText('');
    setShowExtractor(false);
  };

  return (
    <form onSubmit={handleSave} className="space-y-6" id="student-profile-form">
      {/* Header Info banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white border border-slate-200 text-slate-800 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center border border-blue-100 text-blue-600">
            <User className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-800">{formData.name}</h2>
              <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200/60">
                Active Student
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {formData.degree || 'Undergraduate Candidate'} • {formData.college}
            </p>
          </div>
        </div>

        <button
          id="save-profile-header-btn"
          type="submit"
          disabled={isSaving}
          className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200 transition disabled:opacity-50 cursor-pointer"
        >
          {savedSuccess ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-white" />
              <span>Saved to Firestore!</span>
            </>
          ) : isSaving ? (
            <span>Saving...</span>
          ) : (
            <>
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </>
          )}
        </button>
      </div>

      {/* Two Column Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Academic & Personal Info */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-blue-600" />
              Academic & Identity Profile
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Institutional Email
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                College / University
              </label>
              <input
                type="text"
                required
                value={formData.college}
                onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Degree & Branch
                </label>
                <input
                  type="text"
                  placeholder="e.g. B.Tech Computer Science"
                  value={formData.degree}
                  onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Current Year / Batch
                </label>
                <input
                  type="text"
                  placeholder="e.g. 3rd Year (2027)"
                  value={formData.yearOfStudy}
                  onChange={(e) => setFormData({ ...formData, yearOfStudy: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  CGPA / Percentage
                </label>
                <input
                  type="text"
                  placeholder="e.g. 8.9 / 10"
                  value={formData.cgpa}
                  onChange={(e) => setFormData({ ...formData, cgpa: e.target.value })}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Work Preference
                </label>
                <select
                  value={formData.preferredType}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      preferredType: e.target.value as StudentProfile['preferredType'],
                    })
                  }
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                >
                  <option value="Any">Any Mode (Remote / Hybrid / In-office)</option>
                  <option value="Remote">Remote Only</option>
                  <option value="Hybrid">Hybrid</option>
                  <option value="In-office">In-office Only</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Availability & Timelines
              </label>
              <input
                type="text"
                placeholder="e.g. Available Immediately, 20 hrs/week"
                value={formData.availability}
                onChange={(e) => setFormData({ ...formData, availability: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Bio & Technical Interests
              </label>
              <textarea
                rows={3}
                placeholder="Brief summary of your academic background and project interests..."
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
              />
            </div>
          </div>

          {/* Online Profiles */}
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <h3 className="text-sm font-bold text-slate-800">Portfolio & Code Profiles</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Github className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="url"
                  placeholder="https://github.com/your-username"
                  value={formData.githubUrl || ''}
                  onChange={(e) => setFormData({ ...formData, githubUrl: e.target.value })}
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>
              <div className="flex items-center gap-2">
                <Linkedin className="w-4 h-4 text-slate-400 shrink-0" />
                <input
                  type="url"
                  placeholder="https://linkedin.com/in/your-profile"
                  value={formData.linkedinUrl || ''}
                  onChange={(e) => setFormData({ ...formData, linkedinUrl: e.target.value })}
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Skills Management (The Core Matching Driver) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  Your Skills Matrix
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  The Match Score algorithm uses your skill proficiency levels to rank internship postings.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowExtractor(!showExtractor)}
                className="text-xs font-semibold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg border border-blue-200 transition inline-flex items-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Resume Import</span>
              </button>
            </div>

            {/* Resume Text Extractor Drawer */}
            {showExtractor && (
              <div className="p-4 bg-blue-50/50 rounded-xl border border-blue-100 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between text-xs text-blue-900 font-semibold">
                  <span>Paste Resume or Skills Summary</span>
                  <span className="text-[11px] font-normal text-blue-700">Auto-identifies known tech skills</span>
                </div>
                <textarea
                  rows={3}
                  value={resumeExtractText}
                  onChange={(e) => setResumeExtractText(e.target.value)}
                  placeholder="Paste resume text, project summaries, or LinkedIn bio here (e.g. 'Built React and Python APIs with PostgreSQL and Docker')..."
                  className="w-full p-2.5 text-xs bg-white border border-blue-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowExtractor(false)}
                    className="px-3 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded-md"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleExtractFromText}
                    disabled={!resumeExtractText.trim()}
                    className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-md disabled:opacity-50 transition shadow-sm"
                  >
                    Extract & Add Skills
                  </button>
                </div>
              </div>
            )}

            {/* Interactive Skill Tagger */}
            <SkillTagger
              skills={formData.skills}
              onChange={handleSkillsChange}
              maxSkills={30}
            />
          </div>

          {/* Match Score Preview Help Box */}
          <div className="p-5 bg-blue-50/60 rounded-2xl border border-blue-100 text-xs text-slate-700 space-y-2">
            <h4 className="font-bold text-blue-950 flex items-center gap-1.5">
              <span>💡</span> How Match Scores Work in SIH26044
            </h4>
            <p className="leading-relaxed">
              When companies post required and bonus skills, our algorithm analyzes your active skills, proficiency ratings (Beginner, Intermediate, Advanced), and synonyms.
            </p>
            <ul className="space-y-1 list-disc list-inside text-slate-600 pl-1">
              <li><strong>Required Skills:</strong> Represent 75% of your baseline score</li>
              <li><strong>Bonus Skills:</strong> Provide up to 25% extra points</li>
              <li><strong>Advanced Proficiency:</strong> Provides a 1.1x boost on matched requirements</li>
            </ul>
          </div>
        </div>
      </div>
    </form>
  );
};
