import React from 'react';
import {
  RoleView,
  UserAccount,
  StudentProfile,
  CompanyProfile,
  NotificationRecord,
  InstitutionProfile,
} from '../types';
import { NotificationCenter } from './common/NotificationCenter';
import { GraduationCap, Building2, School, RefreshCw, LogOut, Shield } from 'lucide-react';

interface HeaderProps {
  currentRole: RoleView;
  onSelectRole: (role: RoleView) => void;
  internshipsCount: number;
  companiesCount: number;
  onResetData: () => void;
  isDbSyncing?: boolean;
  student?: StudentProfile;
  activeCompany?: CompanyProfile;
  activeInstitution?: InstitutionProfile;
  authenticatedUser?: UserAccount | null;
  onSignOut?: () => void;
  notifications: NotificationRecord[];
  onMarkNotificationAsRead: (id: string) => void;
  onMarkAllNotificationsAsRead: () => void;
  onSelectNotification?: (notif: NotificationRecord) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onSelectRole,
  internshipsCount,
  companiesCount,
  onResetData,
  isDbSyncing = false,
  student,
  activeCompany,
  activeInstitution,
  authenticatedUser,
  onSignOut,
  notifications,
  onMarkNotificationAsRead,
  onMarkAllNotificationsAsRead,
  onSelectNotification,
}) => {
  let userName = authenticatedUser?.username || 'User';
  let userRoleText = 'Portal';

  if (currentRole === 'student') {
    userName = authenticatedUser?.username || student?.name || 'Aarav Sharma';
    userRoleText = student?.college ? `${student.college.split('(')[1]?.replace(')', '') || 'NIT Trichy'} • ${student.degree.split('in ')[1] || 'B.Tech'}` : (student?.degree || 'Student Portal');
  } else if (currentRole === 'industry') {
    userName = authenticatedUser?.companyName || activeCompany?.name || 'Enterprise Recruiter';
    userRoleText = `${activeCompany?.name || 'Industry Partner'} • Corporate Recruiter`;
  } else if (currentRole === 'institution') {
    userName = authenticatedUser?.institutionName || activeInstitution?.name || 'Academic Administrator';
    userRoleText = activeInstitution?.code ? `${activeInstitution.code} • Dean & Placements` : 'College Administrator';
  }

  const userInitials = userName
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  const userRoleBadge =
    currentRole === 'student'
      ? { text: 'Student Account', color: 'bg-blue-50 text-blue-700 border-blue-200' }
      : currentRole === 'institution'
      ? { text: 'Institution Admin', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' }
      : { text: 'Industry Partner', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' };

  return (
    <header id="main-header" className="h-16 bg-white border-b border-slate-200 shrink-0 sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-8 h-full flex items-center justify-between">
        {/* Logo & Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm">
            <span className="text-white font-bold text-base leading-none">A</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight text-slate-800">
                AcademiaLink
              </span>
              <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                SIH26044
              </span>
            </div>
          </div>
        </div>

        {/* Center & Right Controls */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Dynamic Navigation Menu: users can ONLY see and access the portal meant for their specific role */}
          <div
            id="role-switcher-nav"
            aria-label="Role-specific portal navigation"
            className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200/80"
          >
            {currentRole === 'student' && (
              <div
                id="portal-nav-student"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-md bg-white shadow-sm text-blue-600 border border-slate-200/60"
              >
                <GraduationCap className="w-4 h-4 text-blue-600" />
                <span>Student Portal</span>
                <span className="hidden sm:inline-flex px-1.5 py-0.5 rounded text-[10px] bg-blue-50 text-blue-700 font-bold border border-blue-200 ml-1">
                  Enrolled
                </span>
              </div>
            )}

            {currentRole === 'industry' && (
              <div
                id="portal-nav-industry"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-md bg-white shadow-sm text-indigo-600 border border-slate-200/60"
              >
                <Building2 className="w-4 h-4 text-indigo-600" />
                <span>Industry Portal</span>
                <span className="hidden sm:inline-flex px-1.5 py-0.5 rounded text-[10px] bg-indigo-50 text-indigo-700 font-bold border border-indigo-200 ml-1">
                  Verified Partner
                </span>
              </div>
            )}

            {currentRole === 'institution' && (
              <div
                id="portal-nav-institution"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-semibold rounded-md bg-white shadow-sm text-emerald-600 border border-slate-200/60"
              >
                <School className="w-4 h-4 text-emerald-600" />
                <span>Institution Portal</span>
                <span className="hidden sm:inline-flex px-1.5 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 ml-1">
                  College Admin
                </span>
              </div>
            )}
          </div>

          <div className="h-8 w-px bg-slate-200 hidden sm:block"></div>

          {/* Real-time Notification Bell Popover */}
          <NotificationCenter
            notifications={notifications}
            onMarkAsRead={onMarkNotificationAsRead}
            onMarkAllAsRead={onMarkAllNotificationsAsRead}
            onSelectNotification={onSelectNotification}
          />

          {/* User Profile Info & Avatar */}
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="text-right hidden sm:block max-w-[170px] truncate">
              <p className="text-sm font-semibold text-slate-800 leading-tight truncate">
                {userName}
              </p>
              <p className="text-[11px] text-slate-500 font-medium truncate">
                {userRoleText}
              </p>
            </div>
            <div className="w-9 h-9 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center text-xs sm:text-sm font-bold text-slate-600 select-none">
              {userInitials || 'A'}
            </div>

            {/* Quick sync tools */}
            <div className="flex items-center gap-1.5 pl-1">
              <button
                type="button"
                onClick={onResetData}
                title="Sync & reset sample database records"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isDbSyncing ? 'animate-spin text-blue-600' : ''}`} />
              </button>

              {/* Sign Out Button */}
              {onSignOut && (
                <button
                  id="auth-signout-button"
                  type="button"
                  onClick={onSignOut}
                  title="Sign out of account"
                  className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-rose-600 hover:bg-rose-50 border border-slate-200 hover:border-rose-200 rounded-lg transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden md:inline">Log Out</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

