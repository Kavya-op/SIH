import React, { useState } from 'react';
import { StudentSkill, ProficiencyLevel } from '../../types';
import { Plus, X, Award, Check } from 'lucide-react';

interface SkillTaggerProps {
  skills: StudentSkill[];
  onChange: (updatedSkills: StudentSkill[]) => void;
  maxSkills?: number;
}

const POPULAR_SUGGESTIONS = [
  'React',
  'TypeScript',
  'Python',
  'Node.js',
  'Tailwind CSS',
  'Machine Learning',
  'Docker',
  'PostgreSQL',
  'Git',
  'AWS',
  'C++',
  'Figma',
  'Data Science',
  'REST API',
];

export const SkillTagger: React.FC<SkillTaggerProps> = ({
  skills,
  onChange,
  maxSkills = 25,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<ProficiencyLevel>('Intermediate');

  const handleAdd = (nameToAdd?: string, level: ProficiencyLevel = selectedLevel) => {
    const raw = (nameToAdd || inputVal).trim();
    if (!raw) return;

    // Avoid duplicate names (case-insensitive)
    const exists = skills.some((s) => s.name.toLowerCase() === raw.toLowerCase());
    if (exists) {
      setInputVal('');
      return;
    }

    if (skills.length >= maxSkills) return;

    onChange([...skills, { name: raw, level, verified: false }]);
    setInputVal('');
  };

  const handleRemove = (nameToRemove: string) => {
    onChange(skills.filter((s) => s.name !== nameToRemove));
  };

  const handleLevelChange = (skillName: string, newLevel: ProficiencyLevel) => {
    onChange(
      skills.map((s) => (s.name === skillName ? { ...s, level: newLevel } : s))
    );
  };

  const remainingSuggestions = POPULAR_SUGGESTIONS.filter(
    (sug) => !skills.some((s) => s.name.toLowerCase() === sug.toLowerCase())
  );

  return (
    <div className="space-y-4" id="skill-tagger-container">
      {/* Input row */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <input
            id="skill-input-field"
            type="text"
            placeholder="Type a skill (e.g. PyTorch, Kubernetes, Java...)"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAdd();
              }
            }}
            className="w-full px-3.5 py-2 text-sm bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-800 transition"
          />
        </div>

        {/* Proficiency picker for new skill */}
        <div className="flex items-center gap-1.5">
          <select
            id="skill-proficiency-select"
            value={selectedLevel}
            onChange={(e) => setSelectedLevel(e.target.value as ProficiencyLevel)}
            aria-label="Skill proficiency level"
            className="px-3 py-2 text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
          >
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Advanced">Advanced</option>
          </select>

          <button
            id="add-skill-button"
            type="button"
            onClick={() => handleAdd()}
            disabled={!inputVal.trim()}
            className="inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-md shadow-blue-200 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            Add Skill
          </button>
        </div>
      </div>

      {/* Current Active Skills List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Active Skills ({skills.length})</span>
          <span>Click level badge to toggle proficiency</span>
        </div>

        {skills.length === 0 ? (
          <div className="p-4 text-center rounded-lg border border-dashed border-slate-200 bg-slate-50/60 text-xs text-slate-500">
            No skills added yet. Add your core programming languages, tools, and frameworks below.
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {skills.map((skill) => {
              const levelColor =
                skill.level === 'Advanced'
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                  : skill.level === 'Intermediate'
                  ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'bg-amber-50 text-amber-700 border-amber-200';

              return (
                <div
                  key={skill.name}
                  id={`skill-tag-${skill.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className="inline-flex items-center bg-white border border-slate-200 rounded-lg pl-3 pr-1.5 py-1 text-xs text-slate-800 shadow-2xs gap-2 group transition hover:border-slate-300"
                >
                  <span className="font-medium">{skill.name}</span>

                  {/* Level toggle badge */}
                  <button
                    type="button"
                    title="Click to cycle: Beginner → Intermediate → Advanced"
                    onClick={() => {
                      const nextLevel: ProficiencyLevel =
                        skill.level === 'Beginner'
                          ? 'Intermediate'
                          : skill.level === 'Intermediate'
                          ? 'Advanced'
                          : 'Beginner';
                      handleLevelChange(skill.name, nextLevel);
                    }}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-semibold border transition ${levelColor} hover:opacity-80`}
                  >
                    {skill.level}
                  </button>

                  {/* Delete skill button */}
                  <button
                    type="button"
                    onClick={() => handleRemove(skill.name)}
                    className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                    title={`Remove ${skill.name}`}
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Suggested Quick-Add Skills */}
      {remainingSuggestions.length > 0 && (
        <div className="pt-2 border-t border-slate-100">
          <p className="text-xs text-slate-500 mb-2 font-medium">Quick suggestions for SIH roles:</p>
          <div className="flex flex-wrap gap-1.5">
            {remainingSuggestions.slice(0, 8).map((sug) => (
              <button
                key={sug}
                id={`suggested-skill-${sug.toLowerCase().replace(/\s+/g, '-')}`}
                type="button"
                onClick={() => handleAdd(sug, 'Intermediate')}
                className="inline-flex items-center text-xs px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition font-medium"
              >
                <Plus className="w-3 h-3 mr-1 text-slate-500" />
                {sug}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
