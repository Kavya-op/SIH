import { StudentSkill, MatchScoreDetails } from '../types';

/**
 * Common skill synonyms and canonical mappings
 */
const SKILL_ALIASES: Record<string, string> = {
  'js': 'javascript',
  'javascript': 'javascript',
  'ts': 'typescript',
  'typescript': 'typescript',
  'react': 'react',
  'react.js': 'react',
  'reactjs': 'react',
  'next': 'nextjs',
  'next.js': 'nextjs',
  'nextjs': 'nextjs',
  'node': 'nodejs',
  'node.js': 'nodejs',
  'nodejs': 'nodejs',
  'express': 'expressjs',
  'express.js': 'expressjs',
  'vue': 'vuejs',
  'vue.js': 'vuejs',
  'vuejs': 'vuejs',
  'angular': 'angular',
  'py': 'python',
  'python': 'python',
  'python3': 'python',
  'golang': 'go',
  'go': 'go',
  'cpp': 'c++',
  'cplusplus': 'c++',
  'c#': 'csharp',
  'csharp': 'csharp',
  'postgres': 'postgresql',
  'postgresql': 'postgresql',
  'mongo': 'mongodb',
  'mongodb': 'mongodb',
  'mysql': 'mysql',
  'sql': 'sql',
  'ml': 'machine learning',
  'machine learning': 'machine learning',
  'ai': 'artificial intelligence',
  'artificial intelligence': 'artificial intelligence',
  'dl': 'deep learning',
  'deep learning': 'deep learning',
  'nlp': 'nlp',
  'natural language processing': 'nlp',
  'docker': 'docker',
  'k8s': 'kubernetes',
  'kubernetes': 'kubernetes',
  'aws': 'aws',
  'amazon web services': 'aws',
  'gcp': 'google cloud',
  'google cloud': 'google cloud',
  'azure': 'azure',
  'microsoft azure': 'azure',
  'tailwind': 'tailwind css',
  'tailwindcss': 'tailwind css',
  'html': 'html5',
  'html5': 'html5',
  'css': 'css3',
  'css3': 'css3',
  'git': 'git',
  'github': 'git',
  'figma': 'figma',
  'ui/ux': 'ui/ux',
  'ui design': 'ui/ux',
  'ux design': 'ui/ux',
  'rest': 'rest api',
  'rest api': 'rest api',
  'graphql': 'graphql',
  'ci/cd': 'ci/cd',
};

/**
 * Normalize skill name for fuzzy/exact alias matching
 */
export function normalizeSkill(skill: string): string {
  const clean = skill
    .toLowerCase()
    .trim()
    .replace(/[._\-/\s]+/g, ' ');

  if (SKILL_ALIASES[clean]) {
    return SKILL_ALIASES[clean];
  }

  // Remove spaces completely as secondary check
  const condensed = clean.replace(/\s+/g, '');
  if (SKILL_ALIASES[condensed]) {
    return SKILL_ALIASES[condensed];
  }

  return clean;
}

/**
 * Checks if student has a given required or optional skill
 */
function findMatchingStudentSkill(
  targetSkill: string,
  studentSkills: StudentSkill[]
): StudentSkill | undefined {
  const normalizedTarget = normalizeSkill(targetSkill);

  return studentSkills.find((s) => {
    const normStudent = normalizeSkill(s.name);
    if (normStudent === normalizedTarget) return true;
    if (normStudent.includes(normalizedTarget) || normalizedTarget.includes(normStudent)) {
      // guard against too short substrings like "c" in "react"
      if (normalizedTarget.length >= 3 && normStudent.length >= 3) {
        return true;
      }
    }
    return false;
  });
}

/**
 * Calculate the match score between a student's skills and internship requirements.
 * - Required skills constitute 75% of total score
 * - Optional/preferred skills constitute 25% of total score
 * - Proficiency level boosts/adjusts the score (Advanced: 1.1x, Intermediate: 1.0x, Beginner: 0.85x)
 */
export function calculateMatchScore(
  studentSkills: StudentSkill[],
  requiredSkills: string[],
  optionalSkills: string[] = []
): MatchScoreDetails {
  if (!requiredSkills || requiredSkills.length === 0) {
    return {
      score: 100,
      matchedRequired: [],
      missingRequired: [],
      matchedOptional: [],
      missingOptional: [],
      totalRequired: 0,
      totalOptional: optionalSkills.length,
      matchLevel: 'High',
      scoreColor: 'text-emerald-700 bg-emerald-50 border-emerald-200',
      recommendation: 'Open requirements - great opportunity for all candidates.',
    };
  }

  const matchedRequired: string[] = [];
  const missingRequired: string[] = [];
  let requiredWeightedSum = 0;

  requiredSkills.forEach((reqSkill) => {
    const match = findMatchingStudentSkill(reqSkill, studentSkills);
    if (match) {
      matchedRequired.push(reqSkill);
      let multiplier = 1.0;
      if (match.level === 'Advanced') multiplier = 1.1;
      else if (match.level === 'Beginner') multiplier = 0.85;
      requiredWeightedSum += multiplier;
    } else {
      missingRequired.push(reqSkill);
    }
  });

  const matchedOptional: string[] = [];
  const missingOptional: string[] = [];
  let optionalWeightedSum = 0;

  if (optionalSkills && optionalSkills.length > 0) {
    optionalSkills.forEach((optSkill) => {
      const match = findMatchingStudentSkill(optSkill, studentSkills);
      if (match) {
        matchedOptional.push(optSkill);
        let multiplier = 1.0;
        if (match.level === 'Advanced') multiplier = 1.1;
        else if (match.level === 'Beginner') multiplier = 0.85;
        optionalWeightedSum += multiplier;
      } else {
        missingOptional.push(optSkill);
      }
    });
  }

  // Raw fractions
  const reqFraction = requiredSkills.length > 0 
    ? Math.min(1.0, requiredWeightedSum / requiredSkills.length) 
    : 1;

  const optFraction = optionalSkills.length > 0 
    ? Math.min(1.0, optionalWeightedSum / optionalSkills.length) 
    : 0;

  let calculatedScore: number;
  if (optionalSkills.length > 0) {
    calculatedScore = (reqFraction * 75) + (optFraction * 25);
  } else {
    calculatedScore = reqFraction * 100;
  }

  const finalScore = Math.min(100, Math.max(0, Math.round(calculatedScore)));

  let matchLevel: 'High' | 'Moderate' | 'Low' = 'Low';
  let scoreColor = 'text-amber-700 bg-amber-50 border-amber-200';
  let recommendation = '';

  if (finalScore >= 75) {
    matchLevel = 'High';
    scoreColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
    recommendation = 'Strong match! Your skill profile closely fits what this company is seeking.';
  } else if (finalScore >= 45) {
    matchLevel = 'Moderate';
    scoreColor = 'text-blue-700 bg-blue-50 border-blue-200';
    if (missingRequired.length > 0) {
      recommendation = `Good candidate. Upskilling in ${missingRequired.slice(0, 2).join(' & ')} can boost your candidacy.`;
    } else {
      recommendation = 'Moderate match. Consider highlighting relevant course projects.';
    }
  } else {
    matchLevel = 'Low';
    scoreColor = 'text-slate-600 bg-slate-100 border-slate-200';
    if (missingRequired.length > 0) {
      recommendation = `Key missing requirements: ${missingRequired.slice(0, 3).join(', ')}.`;
    } else {
      recommendation = 'Skills currently have low overlap with this posting.';
    }
  }

  return {
    score: finalScore,
    matchedRequired,
    missingRequired,
    matchedOptional,
    missingOptional,
    totalRequired: requiredSkills.length,
    totalOptional: optionalSkills.length,
    matchLevel,
    scoreColor,
    recommendation,
  };
}
