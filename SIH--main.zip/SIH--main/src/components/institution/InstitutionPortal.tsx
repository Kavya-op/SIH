import React, { useState, useMemo } from 'react';
import {
  InstitutionProfile,
  StudentProfile,
  InternshipPosting,
  ApplicationRecord,
  InstitutionTab,
} from '../../types';
import {
  School,
  GraduationCap,
  CheckCircle2,
  Clock,
  Search,
  Filter,
  TrendingUp,
  Award,
  Users,
  Briefcase,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Building2,
  ShieldCheck,
  AlertCircle,
  FileText,
  BadgeCheck,
  X,
  Layers,
  ArrowUpRight,
} from 'lucide-react';

interface InstitutionPortalProps {
  institutions: InstitutionProfile[];
  activeInstitutionId: string;
  onSelectInstitution: (id: string) => void;
  students: StudentProfile[];
  internships: InternshipPosting[];
  applications: ApplicationRecord[];
  onVerifyStudent: (studentId: string, verified: boolean) => Promise<void>;
  onUpdateInstitution?: (institution: InstitutionProfile) => Promise<void>;
}

export const InstitutionPortal: React.FC<InstitutionPortalProps> = ({
  institutions,
  activeInstitutionId,
  onSelectInstitution,
  students,
  internships,
  applications,
  onVerifyStudent,
}) => {
  const [activeTab, setActiveTab] = useState<InstitutionTab>('students');
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('All');
  const [verificationFilter, setVerificationFilter] = useState<'all' | 'verified' | 'pending'>('all');
  const [selectedStudentForModal, setSelectedStudentForModal] = useState<StudentProfile | null>(null);
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [verificationSuccessToast, setVerificationSuccessToast] = useState<string | null>(null);

  // Active institution
  const activeInstitution = useMemo(() => {
    return institutions.find((inst) => inst.id === activeInstitutionId) || institutions[0];
  }, [institutions, activeInstitutionId]);

  // Students enrolled in this institution
  const enrolledStudents = useMemo(() => {
    if (!activeInstitution) return [];
    return students.filter(
      (s) =>
        s.institutionId === activeInstitution.id ||
        s.college.toLowerCase().includes(activeInstitution.name.toLowerCase()) ||
        s.college.toLowerCase().includes(activeInstitution.code.toLowerCase())
    );
  }, [students, activeInstitution]);

  // Filtered students
  const filteredStudents = useMemo(() => {
    return enrolledStudents.filter((student) => {
      const matchesSearch =
        searchQuery === '' ||
        student.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
        student.skills.some((sk) => sk.name.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesDept =
        departmentFilter === 'All' ||
        (student.department && student.department.toLowerCase() === departmentFilter.toLowerCase()) ||
        student.degree.toLowerCase().includes(departmentFilter.toLowerCase());

      const matchesVerification =
        verificationFilter === 'all' ||
        (verificationFilter === 'verified' && student.verifiedByInstitution) ||
        (verificationFilter === 'pending' && !student.verifiedByInstitution);

      return matchesSearch && matchesDept && matchesVerification;
    });
  }, [enrolledStudents, searchQuery, departmentFilter, verificationFilter]);

  // Applications from this institution's enrolled students
  const institutionApplications = useMemo(() => {
    const studentIds = new Set(enrolledStudents.map((s) => s.id));
    return applications.filter((app) => studentIds.has(app.studentId));
  }, [applications, enrolledStudents]);

  // Analytics Calculations
  const analyticsData = useMemo(() => {
    const totalEnrolled = enrolledStudents.length;
    const verifiedStudentsCount = enrolledStudents.filter((s) => s.verifiedByInstitution).length;
    const studentsWithApplications = new Set(institutionApplications.map((a) => a.studentId)).size;

    // Matches with score >= 75
    const highMatches = institutionApplications.filter((a) => a.matchScore >= 75);
    const placedOrShortlisted = institutionApplications.filter(
      (a) => a.status === 'accepted' || a.status === 'shortlisted'
    );
    const acceptedCount = institutionApplications.filter((a) => a.status === 'accepted').length;

    const avgMatchScore =
      institutionApplications.length > 0
        ? Math.round(
            institutionApplications.reduce((acc, curr) => acc + curr.matchScore, 0) /
              institutionApplications.length
          )
        : 86;

    // Status breakdown
    const statusCounts = {
      applied: institutionApplications.filter((a) => a.status === 'applied').length,
      reviewing: institutionApplications.filter((a) => a.status === 'reviewing').length,
      shortlisted: institutionApplications.filter((a) => a.status === 'shortlisted').length,
      accepted: acceptedCount,
      rejected: institutionApplications.filter((a) => a.status === 'rejected').length,
    };

    // Department-wise stats
    const deptMap: Record<string, { total: number; verified: number; applied: number; accepted: number }> = {};
    enrolledStudents.forEach((student) => {
      const dept = student.department || 'Computer Science';
      if (!deptMap[dept]) {
        deptMap[dept] = { total: 0, verified: 0, applied: 0, accepted: 0 };
      }
      deptMap[dept].total += 1;
      if (student.verifiedByInstitution) deptMap[dept].verified += 1;
    });

    institutionApplications.forEach((app) => {
      const student = enrolledStudents.find((s) => s.id === app.studentId);
      const dept = student?.department || 'Computer Science';
      if (deptMap[dept]) {
        deptMap[dept].applied += 1;
        if (app.status === 'accepted') {
          deptMap[dept].accepted += 1;
        }
      }
    });

    // Partner companies hiring from this college
    const partnerCompanyMap: Record<string, { name: string; count: number; accepted: number; avgScore: number }> = {};
    institutionApplications.forEach((app) => {
      if (!partnerCompanyMap[app.companyId]) {
        partnerCompanyMap[app.companyId] = {
          name: app.companyName,
          count: 0,
          accepted: 0,
          avgScore: 0,
        };
      }
      partnerCompanyMap[app.companyId].count += 1;
      partnerCompanyMap[app.companyId].avgScore += app.matchScore;
      if (app.status === 'accepted') {
        partnerCompanyMap[app.companyId].accepted += 1;
      }
    });

    const partnerCompanies = Object.values(partnerCompanyMap).map((p) => ({
      ...p,
      avgScore: Math.round(p.avgScore / p.count),
    }));

    return {
      totalEnrolled,
      verifiedStudentsCount,
      studentsWithApplications,
      totalApplications: institutionApplications.length,
      highMatchesCount: highMatches.length,
      placedOrShortlistedCount: placedOrShortlisted.length,
      acceptedCount,
      avgMatchScore,
      statusCounts,
      deptBreakdown: Object.entries(deptMap).map(([dept, data]) => ({ dept, ...data })),
      partnerCompanies,
    };
  }, [enrolledStudents, institutionApplications]);

  // Trending Skills dynamically aggregated from active internships
  const trendingSkillsData = useMemo(() => {
    const activeInternships = internships.filter((i) => i.status === 'active');
    const skillCounts: Record<
      string,
      {
        name: string;
        requiredCount: number;
        optionalCount: number;
        totalCount: number;
        associatedRoles: string[];
      }
    > = {};

    activeInternships.forEach((intern) => {
      intern.requiredSkills.forEach((skill) => {
        const trimmed = skill.trim();
        if (!skillCounts[trimmed]) {
          skillCounts[trimmed] = {
            name: trimmed,
            requiredCount: 0,
            optionalCount: 0,
            totalCount: 0,
            associatedRoles: [],
          };
        }
        skillCounts[trimmed].requiredCount += 1;
        skillCounts[trimmed].totalCount += 2; // weighted higher for required
        if (!skillCounts[trimmed].associatedRoles.includes(intern.title)) {
          skillCounts[trimmed].associatedRoles.push(intern.title);
        }
      });

      intern.optionalSkills.forEach((skill) => {
        const trimmed = skill.trim();
        if (!skillCounts[trimmed]) {
          skillCounts[trimmed] = {
            name: trimmed,
            requiredCount: 0,
            optionalCount: 0,
            totalCount: 0,
            associatedRoles: [],
          };
        }
        skillCounts[trimmed].optionalCount += 1;
        skillCounts[trimmed].totalCount += 1;
        if (!skillCounts[trimmed].associatedRoles.includes(intern.title)) {
          skillCounts[trimmed].associatedRoles.push(intern.title);
        }
      });
    });

    // Compute supply in college students
    const studentSkillSupply: Record<string, number> = {};
    enrolledStudents.forEach((student) => {
      student.skills.forEach((sk) => {
        const trimmed = sk.name.trim();
        studentSkillSupply[trimmed] = (studentSkillSupply[trimmed] || 0) + 1;
      });
    });

    const list = Object.values(skillCounts).map((item) => {
      const studentSupply = studentSkillSupply[item.name] || 0;
      const demandPercentage = Math.round(
        (item.requiredCount / (activeInternships.length || 1)) * 100
      );

      let supplyStatus: 'high_demand_low_supply' | 'balanced' | 'strong_supply' = 'balanced';
      if (item.requiredCount >= 2 && studentSupply === 0) {
        supplyStatus = 'high_demand_low_supply';
      } else if (studentSupply >= 2 && item.totalCount >= 2) {
        supplyStatus = 'strong_supply';
      }

      return {
        ...item,
        demandPercentage,
        studentSupply,
        supplyStatus,
      };
    });

    // Sort by total weighted count descending
    return list.sort((a, b) => b.totalCount - a.totalCount);
  }, [internships, enrolledStudents]);

  const handleVerifyToggle = async (student: StudentProfile) => {
    setVerifyingId(student.id);
    const newStatus = !student.verifiedByInstitution;
    try {
      await onVerifyStudent(student.id, newStatus);
      setVerificationSuccessToast(
        newStatus
          ? `Verified skill profile for ${student.name}. Endorsement recorded with institutional credentials.`
          : `Verification revoked for ${student.name}.`
      );
      setTimeout(() => setVerificationSuccessToast(null), 4000);
    } catch (err) {
      console.error('Error toggling student verification:', err);
    } finally {
      setVerifyingId(null);
    }
  };

  return (
    <div id="institution-portal-container" className="space-y-6">
      {/* Toast Notification */}
      {verificationSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-xl shadow-lg border border-slate-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <BadgeCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-sm font-medium">{verificationSuccessToast}</p>
          <button
            type="button"
            onClick={() => setVerificationSuccessToast(null)}
            className="text-slate-400 hover:text-white ml-2"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* College Identity Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center shrink-0 text-blue-600">
                <School className="w-8 h-8" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
                    {activeInstitution?.name || 'Institution Portal'}
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200">
                    {activeInstitution?.code}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200">
                    {activeInstitution?.type}
                  </span>
                </div>
                <p className="text-sm text-slate-500 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span>{activeInstitution?.location}</span>
                  <span>•</span>
                  <span className="text-slate-700 font-medium">
                    {activeInstitution?.accreditation}
                  </span>
                  <span>•</span>
                  <span>{activeInstitution?.contactEmail}</span>
                </p>
              </div>
            </div>

            {/* Institution Switcher Dropdown */}
            <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-xl border border-slate-200 shrink-0">
              <label htmlFor="institution-select" className="text-xs font-semibold text-slate-500 uppercase tracking-wider pl-2">
                College:
              </label>
              <select
                id="institution-select"
                value={activeInstitutionId}
                onChange={(e) => onSelectInstitution(e.target.value)}
                className="bg-white border border-slate-200 text-slate-800 text-sm rounded-lg px-3 py-1.5 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
              >
                {institutions.map((inst) => (
                  <option key={inst.id} value={inst.id}>
                    {inst.name} ({inst.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium">Cohort Students</p>
                <p className="text-lg font-bold text-slate-800">{enrolledStudents.length}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                <BadgeCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium">Verified Profiles</p>
                <p className="text-lg font-bold text-slate-800">
                  {analyticsData.verifiedStudentsCount} / {enrolledStudents.length}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium">Avg Match Score</p>
                <p className="text-lg font-bold text-slate-800">{analyticsData.avgMatchScore}%</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                <Briefcase className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 font-medium">Placed & Shortlisted</p>
                <p className="text-lg font-bold text-slate-800">
                  {analyticsData.placedOrShortlistedCount} Roles
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation Menu */}
        <div className="bg-slate-50/80 px-6 sm:px-8 border-t border-slate-200 flex flex-wrap gap-2">
          <button
            type="button"
            id="tab-institution-students"
            onClick={() => setActiveTab('students')}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'students'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            Enrolled Students & Verification
            <span className="px-2 py-0.5 rounded-full text-xs bg-slate-200 text-slate-700 font-bold">
              {enrolledStudents.length}
            </span>
          </button>

          <button
            type="button"
            id="tab-institution-analytics"
            onClick={() => setActiveTab('analytics')}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'analytics'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            Internship & Match Analytics
            <span className="px-2 py-0.5 rounded-full text-xs bg-blue-100 text-blue-700 font-bold">
              {analyticsData.totalApplications} Apps
            </span>
          </button>

          <button
            type="button"
            id="tab-institution-trending"
            onClick={() => setActiveTab('trending-skills')}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'trending-skills'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            Trending Industry Skills
            <span className="px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-800 font-bold">
              Live
            </span>
          </button>

          <button
            type="button"
            id="tab-institution-profile"
            onClick={() => setActiveTab('profile')}
            className={`py-3 px-4 text-sm font-semibold border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'profile'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-4 h-4" />
            College Details
          </button>
        </div>
      </div>

      {/* TAB 1: Enrolled Students & Skill Verification */}
      {activeTab === 'students' && (
        <div id="enrolled-students-section" className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                id="search-students-input"
                type="text"
                placeholder="Search students, skills, roll..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-3 w-full sm:w-auto justify-end flex-wrap">
              {/* Department Filter */}
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Filter className="w-3.5 h-3.5" />
                <span>Dept:</span>
                <select
                  id="filter-student-dept"
                  value={departmentFilter}
                  onChange={(e) => setDepartmentFilter(e.target.value)}
                  className="bg-slate-50 border border-slate-200 text-slate-700 text-xs font-medium rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-blue-500 focus:outline-none cursor-pointer"
                >
                  <option value="All">All Departments</option>
                  {activeInstitution?.departments.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {/* Verification Status Filter */}
              <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-medium">
                <button
                  type="button"
                  onClick={() => setVerificationFilter('all')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    verificationFilter === 'all'
                      ? 'bg-white shadow-sm text-slate-800 font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  All ({enrolledStudents.length})
                </button>
                <button
                  type="button"
                  onClick={() => setVerificationFilter('verified')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    verificationFilter === 'verified'
                      ? 'bg-white shadow-sm text-emerald-700 font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Verified ({enrolledStudents.filter((s) => s.verifiedByInstitution).length})
                </button>
                <button
                  type="button"
                  onClick={() => setVerificationFilter('pending')}
                  className={`px-2.5 py-1 rounded cursor-pointer ${
                    verificationFilter === 'pending'
                      ? 'bg-white shadow-sm text-amber-700 font-bold'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  Pending ({enrolledStudents.filter((s) => !s.verifiedByInstitution).length})
                </button>
              </div>
            </div>
          </div>

          {/* Student Roster Cards */}
          {filteredStudents.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-sm">
              <Users className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-slate-700">No students match your filter</h3>
              <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
                Try adjusting your search keywords, department filter, or verification status selector.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {filteredStudents.map((student) => {
                const isVerified = Boolean(student.verifiedByInstitution);
                const isVerifying = verifyingId === student.id;
                const studentApps = institutionApplications.filter((a) => a.studentId === student.id);

                return (
                  <div
                    key={student.id}
                    id={`student-card-${student.id}`}
                    className={`bg-white border rounded-2xl p-5 shadow-sm transition-all hover:border-slate-300 ${
                      isVerified ? 'border-slate-200' : 'border-amber-200/80 bg-amber-50/20'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                      {/* Left: Info */}
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-700 text-base shrink-0">
                          {student.name
                            .split(' ')
                            .map((n) => n[0])
                            .slice(0, 2)
                            .join('')}
                        </div>

                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-base font-bold text-slate-800 leading-tight">
                              {student.name}
                            </h3>
                            {isVerified ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                Verified by College
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200">
                                <Clock className="w-3.5 h-3.5 text-amber-600" />
                                Verification Pending
                              </span>
                            )}
                            <span className="text-xs px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-medium">
                              CGPA: {student.cgpa}
                            </span>
                          </div>

                          <p className="text-xs text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-1">
                            <span className="text-slate-700 font-medium">
                              {student.department || student.degree}
                            </span>
                            <span>•</span>
                            <span>{student.yearOfStudy}</span>
                            <span>•</span>
                            <span className="text-blue-600">{student.email}</span>
                          </p>

                          {/* Skill Tags */}
                          <div className="pt-2 flex flex-wrap items-center gap-1.5">
                            <span className="text-xs font-semibold text-slate-500 mr-1">
                              Skill Profile:
                            </span>
                            {student.skills.map((skill, idx) => (
                              <span
                                key={idx}
                                className={`text-xs px-2.5 py-0.5 rounded-md font-medium border flex items-center gap-1 ${
                                  skill.verified || isVerified
                                    ? 'bg-blue-50 text-blue-700 border-blue-200'
                                    : 'bg-slate-100 text-slate-700 border-slate-200'
                                }`}
                              >
                                {skill.name}
                                <span className="text-[10px] text-slate-400 font-normal">
                                  ({skill.level})
                                </span>
                                {(skill.verified || isVerified) && (
                                  <CheckCircle2 className="w-2.5 h-2.5 text-blue-600" />
                                )}
                              </span>
                            ))}
                          </div>

                          {/* Verification Record details if already endorsed */}
                          {isVerified && student.verifiedAt && (
                            <p className="text-[11px] text-emerald-700 pt-1 font-medium">
                              ✓ Verified by {student.verifiedBy || 'Institution Placement Cell'} on{' '}
                              {new Date(student.verifiedAt).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-3 shrink-0 lg:flex-col lg:items-end justify-between border-t lg:border-t-0 pt-3 lg:pt-0 border-slate-100">
                        <div className="text-xs text-slate-500">
                          <span className="font-semibold text-slate-700">
                            {studentApps.length}
                          </span>{' '}
                          Active Applications
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            id={`inspect-student-btn-${student.id}`}
                            onClick={() => setSelectedStudentForModal(student)}
                            className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition cursor-pointer"
                          >
                            View Dossier
                          </button>

                          {/* Verification Action Button */}
                          <button
                            type="button"
                            id={`verify-student-btn-${student.id}`}
                            disabled={isVerifying}
                            onClick={() => handleVerifyToggle(student)}
                            className={`px-4 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition shadow-sm cursor-pointer ${
                              isVerified
                                ? 'bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200'
                                : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            }`}
                          >
                            {isVerifying ? (
                              <span>Updating...</span>
                            ) : isVerified ? (
                              <>
                                <BadgeCheck className="w-3.5 h-3.5 text-emerald-600" />
                                Endorsed (Click to Revoke)
                              </>
                            ) : (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                Verify Skill Profile
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: Internship & Placement Analytics */}
      {activeTab === 'analytics' && (
        <div id="analytics-section" className="space-y-6">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Matched Students</span>
                <TrendingUp className="w-4 h-4 text-emerald-600" />
              </div>
              <p className="text-2xl font-black text-slate-800">
                {analyticsData.highMatchesCount}
              </p>
              <p className="text-xs text-emerald-600 font-medium mt-1">
                ≥ 75% compatibility with active industry roles
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Accepted / Placed</span>
                <Award className="w-4 h-4 text-blue-600" />
              </div>
              <p className="text-2xl font-black text-slate-800">
                {analyticsData.acceptedCount} Students
              </p>
              <p className="text-xs text-slate-500 font-medium mt-1">
                {analyticsData.placedOrShortlistedCount} including shortlists
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Total Applications</span>
                <Briefcase className="w-4 h-4 text-purple-600" />
              </div>
              <p className="text-2xl font-black text-slate-800">
                {analyticsData.totalApplications}
              </p>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Across {analyticsData.partnerCompanies.length} partner enterprises
              </p>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
              <div className="flex items-center justify-between text-slate-500 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider">Skill Verification Rate</span>
                <BadgeCheck className="w-4 h-4 text-amber-600" />
              </div>
              <p className="text-2xl font-black text-slate-800">
                {enrolledStudents.length > 0
                  ? Math.round((analyticsData.verifiedStudentsCount / enrolledStudents.length) * 100)
                  : 0}
                %
              </p>
              <p className="text-xs text-slate-500 font-medium mt-1">
                {analyticsData.verifiedStudentsCount} of {enrolledStudents.length} endorsed by college
              </p>
            </div>
          </div>

          {/* Detailed Analytics Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Application Pipeline Stage Distribution */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                Internship Matching & Application Funnel
              </h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-emerald-700">Accepted by Industry Partner</span>
                    <span className="text-slate-800 font-bold">{analyticsData.statusCounts.accepted}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-2.5 rounded-full transition-all"
                      style={{
                        width: `${Math.max(
                          (analyticsData.statusCounts.accepted / (analyticsData.totalApplications || 1)) * 100,
                          analyticsData.statusCounts.accepted > 0 ? 15 : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-blue-700">Shortlisted for Interviews</span>
                    <span className="text-slate-800 font-bold">{analyticsData.statusCounts.shortlisted}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-blue-600 h-2.5 rounded-full transition-all"
                      style={{
                        width: `${Math.max(
                          (analyticsData.statusCounts.shortlisted / (analyticsData.totalApplications || 1)) * 100,
                          analyticsData.statusCounts.shortlisted > 0 ? 25 : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-purple-700">Under Technical Review</span>
                    <span className="text-slate-800 font-bold">{analyticsData.statusCounts.reviewing}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-purple-500 h-2.5 rounded-full transition-all"
                      style={{
                        width: `${Math.max(
                          (analyticsData.statusCounts.reviewing / (analyticsData.totalApplications || 1)) * 100,
                          analyticsData.statusCounts.reviewing > 0 ? 15 : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-slate-600">Submitted / Awaiting First Screen</span>
                    <span className="text-slate-800 font-bold">{analyticsData.statusCounts.applied}</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-slate-400 h-2.5 rounded-full transition-all"
                      style={{
                        width: `${Math.max(
                          (analyticsData.statusCounts.applied / (analyticsData.totalApplications || 1)) * 100,
                          analyticsData.statusCounts.applied > 0 ? 20 : 0
                        )}%`,
                      }}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
                <span>Real-time aggregation from verified company dashboards</span>
                <span className="font-semibold text-slate-700">
                  Avg match rating: {analyticsData.avgMatchScore}%
                </span>
              </div>
            </div>

            {/* Department Breakdown */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
              <h3 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-600" />
                Departmental Placement & Verification Health
              </h3>

              <div className="space-y-3">
                {analyticsData.deptBreakdown.map((dept, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-sm"
                  >
                    <div>
                      <p className="font-bold text-slate-800 leading-tight">{dept.dept}</p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {dept.total} enrolled • {dept.verified} verified
                      </p>
                    </div>

                    <div className="text-right">
                      <p className="text-xs font-bold text-blue-700">
                        {dept.applied} Applications
                      </p>
                      <span className="text-[11px] font-semibold text-emerald-600">
                        {dept.accepted > 0 ? `${dept.accepted} Placed` : 'In Progress'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Hiring Partners Active with College */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-blue-600" />
              Industry Recruitment Partners Engaging with Your Enrolled Students
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {analyticsData.partnerCompanies.map((partner, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 hover:bg-white hover:shadow-sm transition"
                >
                  <h4 className="font-bold text-slate-800 text-sm mb-1">{partner.name}</h4>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
                    <span>Candidates Evaluated:</span>
                    <span className="font-semibold text-slate-700">{partner.count}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                    <span>Average Match Score:</span>
                    <span className="font-bold text-blue-600">{partner.avgScore}%</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
                    <span>Offers Extended:</span>
                    <span className="font-bold text-emerald-600">{partner.accepted} accepted</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: Trending Skills Section */}
      {activeTab === 'trending-skills' && (
        <div id="trending-skills-section" className="space-y-6">
          {/* Section Introduction Banner */}
          <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-white border border-blue-200/80 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-200 mb-2">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  Live Industry Postings Telemetry
                </span>
                <h2 className="text-xl font-bold text-slate-800 tracking-tight">
                  High-Demand Skills in Active Industry Job Postings
                </h2>
                <p className="text-sm text-slate-600 mt-1 max-w-2xl">
                  This telemetry is automatically parsed from active corporate internship openings on the platform, comparing current market demands against your enrolled students' skill roster to identify curriculum alignment and workshop opportunities.
                </p>
              </div>

              <div className="bg-white px-4 py-3 rounded-xl border border-blue-100 shadow-sm shrink-0 text-center">
                <span className="text-xs text-slate-500 font-semibold block uppercase">
                  Active Corporate Roles
                </span>
                <span className="text-2xl font-black text-blue-600">
                  {internships.filter((i) => i.status === 'active').length}
                </span>
              </div>
            </div>
          </div>

          {/* Trending Skills Table / Grid */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Ranked Industry Skill Demands ({trendingSkillsData.length} identified skills)
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ordered by frequency and required weight in active postings
                </p>
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
                  Well-supplied in College
                </span>
                <span className="flex items-center gap-1 text-slate-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
                  High Demand Supply Gap
                </span>
              </div>
            </div>

            <div className="divide-y divide-slate-100">
              {trendingSkillsData.map((skill, index) => {
                const isTopThree = index < 3;

                return (
                  <div
                    key={skill.name}
                    className="p-5 hover:bg-slate-50/70 transition flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    {/* Left: Skill name & Ranking */}
                    <div className="flex items-start gap-3 min-w-[240px]">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                          isTopThree
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        #{index + 1}
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-slate-800 text-base">{skill.name}</h4>
                          {skill.supplyStatus === 'high_demand_low_supply' && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                              Opportunity / Gap
                            </span>
                          )}
                          {skill.supplyStatus === 'strong_supply' && (
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              Curriculum Strength
                            </span>
                          )}
                        </div>

                        {/* Associated Roles */}
                        <p className="text-xs text-slate-500 mt-1">
                          Requested in:{' '}
                          <span className="text-slate-700 font-medium">
                            {skill.associatedRoles.slice(0, 2).join(', ')}
                            {skill.associatedRoles.length > 2
                              ? ` +${skill.associatedRoles.length - 2} more`
                              : ''}
                          </span>
                        </p>
                      </div>
                    </div>

                    {/* Middle: Industry Demand Metrics */}
                    <div className="flex items-center gap-6 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px] font-medium">
                          Job Postings:
                        </span>
                        <span className="font-bold text-slate-800 text-sm">
                          {skill.requiredCount} required, {skill.optionalCount} bonus
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-400 block text-[11px] font-medium">
                          Postings Share:
                        </span>
                        <span className="font-bold text-blue-600 text-sm">
                          {skill.demandPercentage}% of openings
                        </span>
                      </div>
                    </div>

                    {/* Right: College Student Supply */}
                    <div className="flex items-center justify-between md:justify-end gap-4 min-w-[200px] pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                      <div className="text-left md:text-right">
                        <span className="text-slate-400 block text-[11px] font-medium">
                          Enrolled Students with Skill:
                        </span>
                        <span
                          className={`font-bold text-sm ${
                            skill.studentSupply > 0 ? 'text-slate-800' : 'text-amber-600'
                          }`}
                        >
                          {skill.studentSupply} student{skill.studentSupply === 1 ? '' : 's'}
                        </span>
                      </div>

                      <div
                        className={`w-3 h-3 rounded-full shrink-0 ${
                          skill.supplyStatus === 'high_demand_low_supply'
                            ? 'bg-amber-500 ring-4 ring-amber-100'
                            : 'bg-emerald-500 ring-4 ring-emerald-100'
                        }`}
                        title={
                          skill.supplyStatus === 'high_demand_low_supply'
                            ? 'Skill has high demand in job postings with low college supply'
                            : 'College students match this industry demand well'
                        }
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Actionable Curriculum Recommendations */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
            <h3 className="text-base font-bold text-slate-800 mb-3 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-600" />
              Institutional Curriculum Insights & Recommendations
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-600">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-800 text-sm mb-1">
                  1. High Demand in Cloud & Containers
                </p>
                <p>
                  Docker, Kubernetes, and Node.js are requested in over 60% of technical roles. Consider offering a weekend hands-on boot camp for 3rd-year engineers.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-800 text-sm mb-1">
                  2. Web Modernization
                </p>
                <p>
                  React and TypeScript remain the predominant web framework combo across all software postings. 4 of your enrolled students already excel in this area.
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-800 text-sm mb-1">
                  3. Verified Credential Advantage
                </p>
                <p>
                  Students with college-verified profiles receive 2.4x more interview shortlists from verified corporate recruiters on AcademiaLink.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: College Details & Profile */}
      {activeTab === 'profile' && (
        <div id="institution-profile-section" className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-5">
            <h2 className="text-xl font-bold text-slate-800">
              {activeInstitution.name} Institutional Profile
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Registered academic credentials, official liaison contacts, and affiliated departments.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Institution Code
              </span>
              <p className="font-medium text-slate-800">{activeInstitution.code}</p>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Classification Type
              </span>
              <p className="font-medium text-slate-800">{activeInstitution.type}</p>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Official Placement Email
              </span>
              <p className="font-medium text-blue-600">{activeInstitution.contactEmail}</p>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Official Portal Website
              </span>
              <a
                href={activeInstitution.website}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-blue-600 hover:underline inline-flex items-center gap-1"
              >
                {activeInstitution.website}
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Accreditation & Ranking
              </span>
              <p className="font-medium text-slate-800">{activeInstitution.accreditation}</p>
            </div>

            <div>
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                Total Campus Student Enrolment
              </span>
              <p className="font-medium text-slate-800">
                {activeInstitution.totalStudentsEnrolled.toLocaleString()} Active Undergraduates
              </p>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Affiliated Academic Departments
            </span>
            <div className="flex flex-wrap gap-2">
              {activeInstitution.departments.map((dept) => (
                <span
                  key={dept}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200"
                >
                  {dept}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Student Dossier Modal */}
      {selectedStudentForModal && (
        <div
          id="student-dossier-modal"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setSelectedStudentForModal(null)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-xl border border-slate-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 font-bold flex items-center justify-center">
                  {selectedStudentForModal.name[0]}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">
                    {selectedStudentForModal.name}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {selectedStudentForModal.degree} • {selectedStudentForModal.yearOfStudy}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedStudentForModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 text-sm">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-1">
                  Academic Record & Bio
                </span>
                <p className="text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200/80">
                  {selectedStudentForModal.bio || 'No personal statement provided.'}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-medium">Cumulative GPA:</span>
                  <span className="text-sm font-bold text-slate-800">
                    {selectedStudentForModal.cgpa}
                  </span>
                </div>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <span className="text-slate-400 block font-medium">Availability:</span>
                  <span className="text-sm font-bold text-slate-800">
                    {selectedStudentForModal.availability}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Skills & Endorsement Audit
                </span>
                <div className="space-y-2">
                  {selectedStudentForModal.skills.map((skill, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs"
                    >
                      <span className="font-semibold text-slate-800">{skill.name}</span>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-white text-slate-600 border border-slate-200 text-[10px]">
                          {skill.level}
                        </span>
                        {skill.verified || selectedStudentForModal.verifiedByInstitution ? (
                          <span className="text-emerald-700 font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            Verified
                          </span>
                        ) : (
                          <span className="text-slate-400">Self-reported</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action in Modal */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  {selectedStudentForModal.verifiedByInstitution ? (
                    <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                      <BadgeCheck className="w-4 h-4 text-emerald-600" />
                      Endorsed by Institution
                    </span>
                  ) : (
                    <span className="text-xs text-amber-700 font-medium flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Pending formal verification
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={async () => {
                    await handleVerifyToggle(selectedStudentForModal);
                    setSelectedStudentForModal((prev) =>
                      prev
                        ? {
                            ...prev,
                            verifiedByInstitution: !prev.verifiedByInstitution,
                          }
                        : null
                    );
                  }}
                  className={`px-4 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
                    selectedStudentForModal.verifiedByInstitution
                      ? 'bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 border border-slate-200'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                  }`}
                >
                  {selectedStudentForModal.verifiedByInstitution
                    ? 'Revoke Verification'
                    : 'Endorse & Verify Student Profile'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
