import React from 'react';
import { MatchScoreDetails } from '../../types';
import { Sparkles, CheckCircle2 } from 'lucide-react';

interface MatchBadgeProps {
  details: MatchScoreDetails;
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
}

export const MatchBadge: React.FC<MatchBadgeProps> = ({
  details,
  size = 'md',
  showDetails = false,
}) => {
  const { score, matchLevel, matchedRequired, totalRequired } = details;

  const badgeStyle =
    score >= 75
      ? 'bg-green-50 text-green-600 border border-green-200/80'
      : score >= 45
      ? 'bg-blue-50 text-blue-600 border border-blue-200/80'
      : 'bg-orange-50 text-orange-600 border border-orange-200/80';

  const ringColor =
    score >= 75
      ? 'stroke-green-600'
      : score >= 45
      ? 'stroke-blue-600'
      : 'stroke-orange-500';

  const circumference = 2 * Math.PI * 14;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-start gap-1">
      <div
        id={`match-badge-${score}`}
        className={`inline-flex items-center gap-2 rounded-full font-bold transition-all ${
          size === 'sm'
            ? 'text-[11px] px-2 py-0.5'
            : size === 'lg'
            ? 'text-sm px-3.5 py-1.5'
            : 'text-xs px-2.5 py-1'
        } ${badgeStyle}`}
      >
        {/* Progress ring */}
        <div className="relative flex items-center justify-center w-4 h-4 shrink-0">
          <svg className="w-4 h-4 -rotate-90 transform" viewBox="0 0 32 32">
            <circle
              cx="16"
              cy="16"
              r="14"
              className="stroke-slate-200 fill-none"
              strokeWidth="3.5"
            />
            <circle
              cx="16"
              cy="16"
              r="14"
              className={`fill-none transition-all duration-700 ease-out ${ringColor}`}
              strokeWidth="3.5"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
            />
          </svg>
        </div>

        <span>{score}% Profile Match</span>
      </div>

      {showDetails && (
        <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-green-600 shrink-0" />
          <span>
            Matches {matchedRequired.length} of {totalRequired} core requirements
          </span>
        </div>
      )}
    </div>
  );
};
