import React from 'react';
import { NotificationRecord } from '../../types';
import {
  Bell,
  Sparkles,
  UserCheck,
  ArrowRight,
  Check,
  Radio,
  ExternalLink,
  CheckCircle2,
} from 'lucide-react';

interface DashboardNotificationBannerProps {
  role: 'student' | 'company';
  notifications: NotificationRecord[];
  onMarkAsRead: (id: string) => void;
  onActionClick?: (notif: NotificationRecord) => void;
}

export const DashboardNotificationBanner: React.FC<DashboardNotificationBannerProps> = ({
  role,
  notifications,
  onMarkAsRead,
  onActionClick,
}) => {
  const unreadNotifs = notifications.filter((n) => !n.read);

  if (unreadNotifs.length === 0) return null;

  // Most recent unread notification
  const primaryNotif = unreadNotifs[0];
  const isMatch = primaryNotif.type === 'internship_match';
  const isApplicant = primaryNotif.type === 'application_received';

  return (
    <div
      id="dashboard-notification-alert"
      className="mb-6 rounded-2xl border border-blue-200 bg-gradient-to-r from-blue-50/80 via-indigo-50/40 to-white p-4 sm:p-5 shadow-xs transition"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left icon and message */}
        <div className="flex items-start sm:items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm shadow-blue-200">
            {isMatch ? (
              <Sparkles className="w-5 h-5" />
            ) : isApplicant ? (
              <UserCheck className="w-5 h-5" />
            ) : (
              <Bell className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-blue-700 bg-blue-100/70 px-2 py-0.5 rounded-full">
                <Radio className="w-2.5 h-2.5 text-blue-600 animate-pulse" />
                {role === 'student' ? 'Real-Time Match Alert' : 'Real-Time Application Alert'}
              </span>
              {unreadNotifs.length > 1 && (
                <span className="text-[11px] font-semibold text-slate-500">
                  +{unreadNotifs.length - 1} more unread
                </span>
              )}
            </div>

            <h3 className="text-sm sm:text-base font-bold text-slate-800 mt-1">
              {primaryNotif.title}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-0.5 line-clamp-1">
              {primaryNotif.message}
            </p>
          </div>
        </div>

        {/* Right actions */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
          {onActionClick && (
            <button
              type="button"
              onClick={() => {
                onMarkAsRead(primaryNotif.id);
                onActionClick(primaryNotif);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-200 transition cursor-pointer"
            >
              <span>{role === 'student' ? 'View Matching Role' : 'Review Applicant'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            type="button"
            onClick={() => onMarkAsRead(primaryNotif.id)}
            title="Mark as read"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-white/80 border border-transparent hover:border-slate-200 transition cursor-pointer"
          >
            <Check className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
