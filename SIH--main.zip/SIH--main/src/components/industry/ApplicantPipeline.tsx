import React, { useState, useMemo } from 'react';
import {
  ApplicationRecord,
  InternshipPosting,
  CompanyProfile,
} from '../../types';
import {
  Users,
  CheckCircle2,
  Clock,
  Award,
  Filter,
  Search,
  ExternalLink,
  ChevronDown,
  Sparkles,
  GraduationCap,
} from 'lucide-react';

interface ApplicantPipelineProps {
  applications: ApplicationRecord[];
  internships: InternshipPosting[];
  activeCompanyId: string;
  onUpdateStatus: (
    appId: string,
    status: ApplicationRecord['status']
  ) => Promise<void>;
}

export const ApplicantPipeline: React.FC<ApplicantPipelineProps> = ({
  applications,
  internships,
  activeCompanyId,
  onUpdateStatus,
}) => {
  const [selectedInternshipFilter, setSelectedInternshipFilter] =
    useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  // Filter applications belonging to this company's postings or all if multi-company
  const companyApplications = useMemo(() => {
    return applications.filter((app) => {
      // If company matches
      if (activeCompanyId && app.companyId !== activeCompanyId) {
        // also check if internship belongs to this company
        const intern = internships.find((i) => i.id === app.internshipId);
        if (!intern || intern.companyId !== activeCompanyId) {
          return false;
        }
      }

      if (
        selectedInternshipFilter !== 'all' &&
        app.internshipId !== selectedInternshipFilter
      ) {
        return false;
      }

      if (statusFilter !== 'all' && app.status !== statusFilter) {
        return false;
      }

      return true;
    }).sort((a, b) => b.matchScore - a.matchScore);
  }, [applications, activeCompanyId, internships, selectedInternshipFilter, statusFilter]);

  const companyInternships = useMemo(() => {
    return internships.filter((i) => i.companyId === activeCompanyId);
  }, [internships, activeCompanyId]);

  const handleStatusChange = async (
    appId: string,
    newStatus: ApplicationRecord['status']
  ) => {
    setUpdatingId(appId);
    try {
      await onUpdateStatus(appId, newStatus);
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6" id="applicant-pipeline-container">
      {/* Top Filter Bar */}
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              Applicant Review & Match Pipeline ({companyApplications.length})
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Candidates are automatically ranked by their skill compatibility score against your requirements.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-blue-700 bg-blue-50/80 px-3 py-1.5 rounded-lg border border-blue-200/60">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span className="font-semibold">Sorted by Highest Match Score</span>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Filter by Internship Role
            </label>
            <select
              value={selectedInternshipFilter}
              onChange={(e) => setSelectedInternshipFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-700 transition"
            >
              <option value="all">All Roles ({companyInternships.length} active)</option>
              {companyInternships.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.title}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              Filter by Review Status
            </label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-700 transition"
            >
              <option value="all">All Statuses</option>
              <option value="applied">Applied (New)</option>
              <option value="reviewing">Under Review</option>
              <option value="shortlisted">Shortlisted</option>
              <option value="accepted">Accepted</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {/* Applications List */}
      {companyApplications.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
            <Users className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-slate-800">No applicants matching this criteria</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Applications submitted by students will appear here with calculated match analytics.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {companyApplications.map((app) => {
            const scoreColor =
              app.matchScore >= 75
                ? 'text-green-700 bg-green-50 border-green-200'
                : app.matchScore >= 45
                ? 'text-blue-700 bg-blue-50 border-blue-200'
                : 'text-orange-700 bg-orange-50 border-orange-200';

            return (
              <div
                key={app.id}
                id={`applicant-card-${app.id}`}
                className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition space-y-4"
              >
                {/* Candidate header row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-base font-bold text-slate-800">
                        {app.studentName}
                      </h4>
                      <span className="text-xs text-slate-300">•</span>
                      <span className="text-xs text-slate-500">
                        Applied for <span className="font-semibold text-slate-700">{app.internshipTitle}</span>
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600">
                      <span className="flex items-center gap-1">
                        <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
                        {app.studentCollege}
                      </span>
                      <span className="text-slate-300">•</span>
                      <span>{app.studentDegree}</span>
                      <span className="text-slate-300">•</span>
                      <span>{app.studentEmail}</span>
                    </div>
                  </div>

                  {/* Match Score Display */}
                  <div className="flex items-center gap-3 shrink-0">
                    <div className={`px-3.5 py-1.5 rounded-full border text-xs font-bold flex items-center gap-1.5 ${scoreColor}`}>
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>{app.matchScore}% Compatibility</span>
                    </div>
                  </div>
                </div>

                {/* Matched skills and missing skills row */}
                <div className="p-4 bg-slate-50 rounded-xl space-y-2 text-xs border border-slate-100">
                  <div>
                    <span className="font-semibold text-slate-700 mr-2">
                      Matched Skills ({app.matchedSkills.length}):
                    </span>
                    <div className="inline-flex flex-wrap gap-1.5 mt-1 sm:mt-0">
                      {app.matchedSkills.map((s) => (
                        <span
                          key={s}
                          className="px-2 py-0.5 rounded bg-green-50 text-green-700 text-[11px] font-medium border border-green-200/80"
                        >
                          ✓ {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  {app.missingSkills.length > 0 && (
                    <div>
                      <span className="font-semibold text-slate-600 mr-2">
                        Missing Required Skills:
                      </span>
                      <div className="inline-flex flex-wrap gap-1.5 mt-1 sm:mt-0">
                        {app.missingSkills.map((s) => (
                          <span
                            key={s}
                            className="px-2 py-0.5 rounded bg-orange-50 text-orange-700 text-[11px] border border-orange-200/80"
                          >
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {app.coverNote && (
                    <div className="pt-2 border-t border-slate-200/60">
                      <span className="font-semibold text-slate-700">Applicant Note: </span>
                      <span className="text-slate-600 italic">
                        &ldquo;{app.coverNote}&rdquo;
                      </span>
                    </div>
                  )}
                </div>

                {/* Candidate Action Status Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Applied on {new Date(app.appliedAt).toLocaleDateString()}</span>
                  </div>

                  {/* Status buttons */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-slate-500 mr-1">Status:</span>
                    {(['reviewing', 'shortlisted', 'accepted', 'rejected'] as const).map(
                      (st) => {
                        const isCurrent = app.status === st;
                        return (
                          <button
                            key={st}
                            type="button"
                            disabled={updatingId === app.id}
                            onClick={() => handleStatusChange(app.id, st)}
                            className={`px-3 py-1 text-xs font-semibold rounded-lg capitalize border transition cursor-pointer ${
                              isCurrent
                                ? st === 'accepted'
                                  ? 'bg-green-600 text-white border-green-600 shadow-sm'
                                  : st === 'shortlisted'
                                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                                  : st === 'reviewing'
                                  ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
                                  : 'bg-slate-700 text-white border-slate-700'
                                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            {st}
                          </button>
                        );
                      }
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
