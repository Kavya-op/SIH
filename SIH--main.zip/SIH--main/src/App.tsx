/**
 * Academia-Industry Collaboration Portal (SIH26044)
 * Skill-Powered Internship & Project Matching Platform with Firebase Firestore
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  RoleView,
  AccountType,
  UserAccount,
  StudentProfile,
  CompanyProfile,
  InternshipPosting,
  ApplicationRecord,
  NotificationRecord,
  InstitutionProfile,
} from './types';
import {
  fetchStudentProfile,
  fetchAllCompanies,
  fetchAllInternships,
  fetchApplications,
  fetchAllInstitutions,
  fetchAllStudents,
  verifyStudentSkillProfile,
  saveStudentProfile,
  saveCompanyProfile,
  saveInternship,
  submitApplication,
  updateApplicationStatus,
  seedInitialFirestoreData,
  listenToNotifications,
  saveNotification,
  markNotificationAsRead,
  markAllNotificationsAsRead,
  subscribeToAuthState,
  signOutUser,
  SEED_STUDENT,
  SEED_STUDENTS,
  SEED_COMPANIES,
  SEED_INTERNSHIPS,
  SEED_APPLICATIONS,
  SEED_NOTIFICATIONS,
  SEED_INSTITUTIONS,
} from './lib/firebase';
import { calculateMatchScore } from './lib/matching';
import { Header } from './components/Header';
import { AuthPage } from './components/auth/AuthPage';
import { StudentDashboard } from './components/student/StudentDashboard';
import { IndustryPortal } from './components/industry/IndustryPortal';
import { InstitutionPortal } from './components/institution/InstitutionPortal';
import { Sparkles, Database, CheckCircle2, RefreshCw } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState<boolean>(true);

  const [currentRole, setCurrentRole] = useState<RoleView>('student');
  const [student, setStudent] = useState<StudentProfile>(SEED_STUDENT);
  const [allStudents, setAllStudents] = useState<StudentProfile[]>(SEED_STUDENTS);
  const [institutions, setInstitutions] = useState<InstitutionProfile[]>(SEED_INSTITUTIONS);
  const [activeInstitutionId, setActiveInstitutionId] = useState<string>(SEED_INSTITUTIONS[0].id);
  const [companies, setCompanies] = useState<CompanyProfile[]>(SEED_COMPANIES);
  const [internships, setInternships] = useState<InternshipPosting[]>(SEED_INTERNSHIPS);
  const [applications, setApplications] = useState<ApplicationRecord[]>(SEED_APPLICATIONS);
  const [notifications, setNotifications] = useState<NotificationRecord[]>(SEED_NOTIFICATIONS);
  const [activeCompanyId, setActiveCompanyId] = useState<string>(SEED_COMPANIES[0].id);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDbSyncing, setIsDbSyncing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3000);
  };

  // Listen to Firebase Auth state changes for persistent session & role routing
  useEffect(() => {
    const unsubscribe = subscribeToAuthState((account) => {
      setCurrentUser(account);
      if (account) {
        // Automatic role-based routing
        setCurrentRole(account.role);
        if (account.role === 'institution' && account.institutionId) {
          setActiveInstitutionId(account.institutionId);
        } else if (account.role === 'industry' && account.companyId) {
          setActiveCompanyId(account.companyId);
        }
      }
      setIsAuthChecking(false);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Listen to Firestore real-time notifications
  useEffect(() => {
    const unsubscribe = listenToNotifications((incoming) => {
      setNotifications(incoming);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  // Initial load & Firestore sync
  const loadPortalData = useCallback(async () => {
    setIsDbSyncing(true);
    try {
      // Seed Firestore with initial records if collection is completely fresh
      await seedInitialFirestoreData();

      const [
        loadedStudent,
        loadedAllStudents,
        loadedInstitutions,
        loadedCompanies,
        loadedInternships,
        loadedApplications,
      ] = await Promise.all([
        fetchStudentProfile(SEED_STUDENT.id),
        fetchAllStudents(),
        fetchAllInstitutions(),
        fetchAllCompanies(),
        fetchAllInternships(),
        fetchApplications(),
      ]);

      setStudent(loadedStudent);
      setAllStudents(loadedAllStudents);
      setInstitutions(loadedInstitutions);
      setCompanies(loadedCompanies);
      setInternships(loadedInternships);
      setApplications(loadedApplications);
      if (loadedCompanies.length > 0) {
        setActiveCompanyId(loadedCompanies[0].id);
      }
      if (loadedInstitutions.length > 0) {
        setActiveInstitutionId(loadedInstitutions[0].id);
      }
    } catch (err) {
      console.warn('Failed to fetch from Firestore, using initial seed state:', err);
    } finally {
      setIsLoading(false);
      setIsDbSyncing(false);
    }
  }, []);

  useEffect(() => {
    loadPortalData();
  }, [loadPortalData]);

  // Handlers for Institution & Student Verification
  const handleVerifyStudent = async (studentId: string, verified: boolean) => {
    const currentInst = institutions.find((i) => i.id === activeInstitutionId) || institutions[0];
    const verifiedBy = `${currentInst.name} Academic & Placement Directorate`;
    const updated = await verifyStudentSkillProfile(studentId, verified, verifiedBy);
    if (updated) {
      setAllStudents((prev) =>
        prev.map((s) => (s.id === studentId ? updated : s))
      );
      if (student.id === studentId) {
        setStudent(updated);
      }
    }
    showToast(
      verified
        ? 'Student skill profile officially verified and endorsed.'
        : 'Student skill profile verification status revoked.'
    );
  };

  // Handlers for Notifications
  const handleMarkNotificationAsRead = async (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
    await markNotificationAsRead(id);
  };

  const handleMarkAllNotificationsAsRead = async () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    await markAllNotificationsAsRead();
    showToast('All notifications marked as read.');
  };

  // Handlers for Student
  const handleUpdateStudentProfile = async (updated: StudentProfile) => {
    setStudent(updated);
    showToast('Student profile & skills synchronized to Firestore!');
    await saveStudentProfile(updated);

    // Re-evaluate matching internships and create notification if high-match role found
    internships.forEach(async (intern) => {
      if (intern.status === 'active') {
        const match = calculateMatchScore(
          updated.skills,
          intern.requiredSkills,
          intern.optionalSkills
        );
        // If high match score (>=85%) and not notified recently
        if (match.score >= 85) {
          const alreadyNotified = notifications.some(
            (n) => n.linkId === intern.id && n.type === 'internship_match'
          );
          if (!alreadyNotified) {
            const notif: NotificationRecord = {
              id: `notif-match-${Date.now()}-${intern.id}`,
              recipientType: 'student',
              recipientId: updated.id,
              title: `High Skill Match: ${intern.title}`,
              message: `${intern.companyName} requires competencies you master (${match.matchedRequired.join(', ')}). Your compatibility score is ${match.score}%!`,
              type: 'internship_match',
              linkId: intern.id,
              read: false,
              createdAt: new Date().toISOString(),
              metadata: {
                internshipId: intern.id,
                internshipTitle: intern.title,
                companyName: intern.companyName,
                matchScore: match.score,
                matchedSkills: match.matchedRequired,
              },
            };
            await saveNotification(notif);
          }
        }
      }
    });
  };

  const handleSubmitApplication = async (newApp: ApplicationRecord) => {
    setApplications((prev) => [newApp, ...prev]);
    showToast(`Application submitted! Recruiter compatibility: ${newApp.matchScore}%`);
    await submitApplication(newApp);

    // Also update applicants count on the internship locally
    setInternships((prev) =>
      prev.map((item) =>
        item.id === newApp.internshipId
          ? { ...item, applicantsCount: (item.applicantsCount || 0) + 1 }
          : item
      )
    );

    // Create real-time notification for the company
    const companyNotif: NotificationRecord = {
      id: `notif-app-${Date.now()}`,
      recipientType: 'company',
      recipientId: newApp.companyId,
      title: `New Candidate: ${newApp.studentName}`,
      message: `${newApp.studentName} (${newApp.studentCollege}) applied for "${newApp.internshipTitle}" with a ${newApp.matchScore}% skill match!`,
      type: 'application_received',
      linkId: newApp.id,
      read: false,
      createdAt: new Date().toISOString(),
      metadata: {
        applicationId: newApp.id,
        internshipId: newApp.internshipId,
        companyId: newApp.companyId,
        studentName: newApp.studentName,
        studentCollege: newApp.studentCollege,
        matchScore: newApp.matchScore,
      },
    };
    await saveNotification(companyNotif);
  };

  // Handlers for Industry Portal
  const handleSaveCompany = async (updated: CompanyProfile) => {
    setCompanies((prev) =>
      prev.map((c) => (c.id === updated.id ? updated : c))
    );
    showToast('Company profile updated in Firestore!');
    await saveCompanyProfile(updated);
  };

  const handleCreateCompany = async (newCompany: CompanyProfile) => {
    setCompanies((prev) => [...prev, newCompany]);
    setActiveCompanyId(newCompany.id);
    showToast(`New company partner "${newCompany.name}" registered!`);
    await saveCompanyProfile(newCompany);
  };

  const handlePostInternship = async (newInternship: InternshipPosting) => {
    setInternships((prev) => [newInternship, ...prev]);
    showToast(`New internship "${newInternship.title}" published!`);
    await saveInternship(newInternship);

    // Check if newly posted role matches student's skills
    const match = calculateMatchScore(
      student.skills,
      newInternship.requiredSkills,
      newInternship.optionalSkills
    );

    if (match.score >= 50) {
      const matchNotif: NotificationRecord = {
        id: `notif-match-${Date.now()}`,
        recipientType: 'student',
        recipientId: student.id,
        title: `New Matching Role: ${newInternship.title}`,
        message: `${newInternship.companyName} just posted a new requirement matching your skill profile with a ${match.score}% score!`,
        type: 'internship_match',
        linkId: newInternship.id,
        read: false,
        createdAt: new Date().toISOString(),
        metadata: {
          internshipId: newInternship.id,
          internshipTitle: newInternship.title,
          companyName: newInternship.companyName,
          matchScore: match.score,
          matchedSkills: match.matchedRequired,
        },
      };
      await saveNotification(matchNotif);
    }
  };

  const handleUpdateInternshipStatus = async (
    id: string,
    status: 'active' | 'closed'
  ) => {
    setInternships((prev) =>
      prev.map((i) => (i.id === id ? { ...i, status } : i))
    );
    const target = internships.find((i) => i.id === id);
    if (target) {
      await saveInternship({ ...target, status });
    }
    showToast(`Internship marked as ${status}.`);
  };

  const handleUpdateApplicationStatus = async (
    appId: string,
    status: ApplicationRecord['status']
  ) => {
    setApplications((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status } : a))
    );
    showToast(`Application status updated to "${status}".`);
    await updateApplicationStatus(appId, status);

    const targetApp = applications.find((a) => a.id === appId);
    if (targetApp) {
      const statusNotif: NotificationRecord = {
        id: `notif-status-${Date.now()}`,
        recipientType: 'student',
        recipientId: targetApp.studentId,
        title: `Application Status: ${status}`,
        message: `Your application for "${targetApp.internshipTitle}" at ${targetApp.companyName} was updated to "${status}".`,
        type: 'application_status',
        linkId: targetApp.internshipId,
        read: false,
        createdAt: new Date().toISOString(),
      };
      await saveNotification(statusNotif);
    }
  };

  const handleAuthSuccess = (account: UserAccount) => {
    setCurrentUser(account);
    setCurrentRole(account.role);

    if (account.role === 'institution') {
      const targetInstId = account.institutionId || 'inst-skit-jaipur';
      setActiveInstitutionId(targetInstId);
    } else if (account.role === 'industry') {
      const targetCompanyId = account.companyId || companies[0]?.id || 'company-finsecure';
      setActiveCompanyId(targetCompanyId);
    } else if (account.role === 'student') {
      const existing = allStudents.find(
        (s) => s.id === account.uid || s.email.toLowerCase() === account.email.toLowerCase()
      );
      if (existing) {
        setStudent(existing);
      } else {
        setStudent((prev) => ({
          ...prev,
          id: account.uid,
          name: account.username,
          email: account.email,
        }));
      }
    }

    showToast(`Welcome, ${account.username}! Redirected to your ${account.accountType} portal.`);
  };

  const handleSignOut = async () => {
    await signOutUser();
    setCurrentUser(null);
    showToast('You have been signed out successfully.');
  };

  const handleResetData = async () => {
    setIsDbSyncing(true);
    try {
      localStorage.clear();
      setStudent(SEED_STUDENT);
      setAllStudents(SEED_STUDENTS);
      setInstitutions(SEED_INSTITUTIONS);
      setActiveInstitutionId(SEED_INSTITUTIONS[0].id);
      setCompanies(SEED_COMPANIES);
      setInternships(SEED_INTERNSHIPS);
      setApplications(SEED_APPLICATIONS);
      setNotifications(SEED_NOTIFICATIONS);
      setActiveCompanyId(SEED_COMPANIES[0].id);
      await seedInitialFirestoreData();
      showToast('Sample dataset refreshed.');
    } finally {
      setIsDbSyncing(false);
    }
  };

  // Filter notifications for current header context
  const activeCompany = companies.find((c) => c.id === activeCompanyId) || companies[0];
  const activeInstitution = institutions.find((i) => i.id === activeInstitutionId) || institutions[0];
  const currentHeaderNotifications = notifications.filter((n) => {
    if (currentRole === 'student') {
      return n.recipientType === 'student';
    }
    return n.recipientType === 'company' && (!n.recipientId || n.recipientId === activeCompany?.id || n.metadata?.companyId === activeCompany?.id);
  });

  const studentNotifications = notifications.filter((n) => n.recipientType === 'student');

  // Loading state while verifying Firebase Auth session
  if (isAuthChecking) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mb-3" />
        <p className="text-sm font-medium text-slate-600">
          Connecting to Firebase Authentication...
        </p>
      </div>
    );
  }

  // First screen: Secure Login and Sign-up landing page
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
        {/* Header during Auth Gate */}
        <header className="h-16 bg-white border-b border-slate-200 shrink-0 sticky top-0 z-30">
          <div className="max-w-7xl mx-auto px-4 sm:px-8 h-full flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-sm">
                <span className="text-white font-bold text-base leading-none">A</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold tracking-tight text-slate-800">AcademiaLink</span>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  SIH26044
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Secure Authentication Gateway</span>
            </div>
          </div>
        </header>

        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <AuthPage
            institutions={institutions}
            companies={companies}
            onAuthSuccess={handleAuthSuccess}
          />
        </main>

        <footer className="border-t border-slate-200 bg-white py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-700">Academia-Industry Collaboration Portal</span>
              <span>•</span>
              <span className="text-indigo-600 font-bold">SIH26044 Problem Statement</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-emerald-600" />
                <span>Firebase Authentication & Firestore Live</span>
              </span>
            </div>
          </div>
        </footer>

        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
            <div className="flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white rounded-xl shadow-xl text-xs sm:text-sm font-medium border border-slate-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{toastMessage}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-blue-100 selection:text-blue-900">
      {/* Global Header with Navigation & Switcher */}
      <Header
        currentRole={currentRole}
        onSelectRole={setCurrentRole}
        internshipsCount={internships.length}
        companiesCount={companies.length}
        onResetData={handleResetData}
        isDbSyncing={isDbSyncing}
        student={student}
        activeCompany={activeCompany}
        activeInstitution={activeInstitution}
        authenticatedUser={currentUser}
        onSignOut={handleSignOut}
        notifications={currentHeaderNotifications}
        onMarkNotificationAsRead={handleMarkNotificationAsRead}
        onMarkAllNotificationsAsRead={handleMarkAllNotificationsAsRead}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-24 space-y-4">
            <div className="w-10 h-10 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm font-medium text-slate-500">
              Initializing AcademiaLink & connecting Firestore...
            </p>
          </div>
        ) : (
          <>
            {currentRole === 'student' && (
              <StudentDashboard
                student={student}
                internships={internships}
                applications={applications}
                notifications={studentNotifications}
                onUpdateProfile={handleUpdateStudentProfile}
                onSubmitApplication={handleSubmitApplication}
                onMarkNotificationAsRead={handleMarkNotificationAsRead}
                onMarkAllNotificationsAsRead={handleMarkAllNotificationsAsRead}
              />
            )}

            {currentRole === 'industry' && (
              <IndustryPortal
                companies={companies}
                internships={internships}
                applications={applications}
                activeCompanyId={activeCompanyId}
                notifications={notifications}
                onSelectCompany={setActiveCompanyId}
                onSaveCompany={handleSaveCompany}
                onCreateCompany={handleCreateCompany}
                onPostInternship={handlePostInternship}
                onUpdateInternshipStatus={handleUpdateInternshipStatus}
                onUpdateApplicationStatus={handleUpdateApplicationStatus}
                onMarkNotificationAsRead={handleMarkNotificationAsRead}
                onMarkAllNotificationsAsRead={handleMarkAllNotificationsAsRead}
              />
            )}

            {currentRole === 'institution' && (
              <InstitutionPortal
                institutions={institutions}
                activeInstitutionId={activeInstitutionId}
                onSelectInstitution={setActiveInstitutionId}
                students={allStudents}
                internships={internships}
                applications={applications}
                onVerifyStudent={handleVerifyStudent}
              />
            )}
          </>
        )}
      </main>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="flex items-center gap-2.5 px-4 py-3 bg-slate-900 text-white rounded-xl shadow-xl text-xs sm:text-sm font-medium border border-slate-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Academia-Industry Collaboration Portal</span>
            <span>•</span>
            <span className="text-indigo-600 font-bold">SIH26044 Problem Statement</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>Firebase Firestore Live</span>
            </span>
            <span>•</span>
            <span>Skill Match Engine v1.0</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
