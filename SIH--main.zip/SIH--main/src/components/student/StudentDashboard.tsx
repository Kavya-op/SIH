import React, { useState, useMemo } from 'react';
import {
  StudentProfile,
  InternshipPosting,
  ApplicationRecord,
  StudentTab,
  MatchScoreDetails,
  NotificationRecord,
} from '../../types';
import { calculateMatchScore } from '../../lib/matching';
import { MatchBadge } from '../common/MatchBadge';
import { StudentProfileForm } from './StudentProfileForm';
import { InternshipDetailModal } from './InternshipDetailModal';
import { ApplyModal } from './ApplyModal';
import { DashboardNotificationBanner } from '../common/DashboardNotificationBanner';
import { NotificationFeed } from '../common/NotificationFeed';
import {
  Sparkles,
  Search,
  Filter,
  Building2,
  MapPin,
  Clock,
  IndianRupee,
  Calendar,
  Send,
  CheckCircle2,
  SlidersHorizontal,
  ChevronRight,
  Briefcase,
  AlertCircle,
  FileCheck2,
  Bell,
} from 'lucide-react';

interface StudentDashboardProps {
  student: StudentProfile;
  internships: InternshipPosting[];
  applications: ApplicationRecord[];
  notifications: NotificationRecord[];
  onUpdateProfile: (updated: StudentProfile) => Promise<void>;
  onSubmitApplication: (app: ApplicationRecord) => Promise<void>;
  onMarkNotificationAsRead: (id: string) => void;
  onMarkAllNotificationsAsRead: () => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  internships,
  applications,
  notifications,
  onUpdateProfile,
  onSubmitApplication,
  onMarkNotificationAsRead,
  onMarkAllNotificationsAsRead,
}) => {
  const [activeTab, setActiveTab] = useState<StudentTab>('matching');
  const [searchQuery, setSearchQuery] = useState('');
  const [minScoreFilter, setMinScoreFilter] = useState<number>(0);
  const [roleTypeFilter, setRoleTypeFilter] = useState<string>('all');
  const [selectedInternship, setSelectedInternship] = useState<InternshipPosting | null>(null);
  const [applyingInternship, setApplyingInternship] = useState<InternshipPosting | null>(null);

  // Calculate match scores for all active internships against current student skills
  const rankedInternships = useMemo(() => {
    return internships
      .filter((item) => item.status === 'active')
      .map((item) => {
        const match = calculateMatchScore(
          student.skills,
          item.requiredSkills,
          item.optionalSkills
        );
        return {
          internship: item,
          match,
        };
      })
      .sort((a, b) => b.match.score - a.match.score);
  }, [internships, student.skills]);

  // Apply UI filters (search, minimum score, role type)
  const filteredInternships = useMemo(() => {
    return rankedInternships.filter(({ internship, match }) => {
      if (match.score < minScoreFilter) return false;

      if (roleTypeFilter !== 'all' && internship.roleType !== roleTypeFilter) {
        return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = internship.title.toLowerCase().includes(q);
        const matchCompany = internship.companyName.toLowerCase().includes(q);
        const matchSkills = internship.requiredSkills.some((s) =>
          s.toLowerCase().includes(q)
        );
        return matchTitle || matchCompany || matchSkills;
      }

      return true;
    });
  }, [rankedInternships, minScoreFilter, roleTypeFilter, searchQuery]);

  // Map of internships this student has applied to
  const appliedInternshipIds = useMemo(() => {
    return new Set(
      applications
        .filter((a) => a.studentId === student.id)
        .map((a) => a.internshipId)
    );
  }, [applications, student.id]);

  const studentApplications = useMemo(() => {
    return applications.filter((a) => a.studentId === student.id);
  }, [applications, student.id]);

  const topMatch = rankedInternships[0];
  const secondMatch = rankedInternships[1];

  const formattedDate = new Intl.DateTimeFormat('en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(new Date());

  return (
    <div className="space-y-6" id="student-dashboard-root">
      {/* Top Welcome & Subnavigation Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">
            Welcome back, {student.name}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            {student.degree} • {student.college} • {student.skills.length} verified technical competencies
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="text-xs text-slate-500 font-medium bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200/80">
            {formattedDate}
          </div>

          {/* Segmented Tab Switcher */}
          <nav aria-label="Student dashboard tabs" className="flex bg-slate-100 p-1 rounded-md border border-slate-200/80">
            <button
              id="tab-student-matching"
              type="button"
              onClick={() => setActiveTab('matching')}
              className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
                activeTab === 'matching'
                  ? 'bg-white shadow-sm text-blue-600 font-semibold'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Smart Matches ({rankedInternships.length})
            </button>

            <button
              id="tab-student-profile"
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
                activeTab === 'profile'
                  ? 'bg-white shadow-sm text-blue-600 font-semibold'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Your Skills
            </button>

            <button
              id="tab-student-applications"
              type="button"
              onClick={() => setActiveTab('applications')}
              className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition cursor-pointer ${
                activeTab === 'applications'
                  ? 'bg-white shadow-sm text-blue-600 font-semibold'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Applications ({studentApplications.length})
            </button>

            <button
              id="tab-student-notifications"
              type="button"
              onClick={() => setActiveTab('notifications')}
              className={`px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-medium rounded transition flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'notifications'
                  ? 'bg-white shadow-sm text-blue-600 font-semibold'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              <span>Notifications</span>
              {notifications.filter((n) => !n.read).length > 0 && (
                <span className="px-1.5 py-0.2 text-[10px] font-bold bg-blue-600 text-white rounded-full">
                  {notifications.filter((n) => !n.read).length}
                </span>
              )}
            </button>
          </nav>
        </div>
      </div>

      {/* Real-time Dashboard Notification Alert Banner */}
      <DashboardNotificationBanner
        role="student"
        notifications={notifications}
        onMarkAsRead={onMarkNotificationAsRead}
        onActionClick={(notif) => {
          if (notif.type === 'internship_match') {
            const target = internships.find((i) => i.id === notif.linkId || i.title === notif.metadata?.internshipTitle);
            if (target) {
              setSelectedInternship(target);
            } else {
              setActiveTab('matching');
            }
          } else if (notif.type === 'application_status') {
            setActiveTab('applications');
          }
        }}
      />

      {/* TAB 1: MATCHING INTERNSHIPS */}
      {activeTab === 'matching' && (
        <div className="space-y-6">
          {/* Top 3-Column Highlights: Top Pick, Second Pick, Industry Trends */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Top Match Highlight */}
            {topMatch ? (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-green-50 text-green-600 rounded-lg">
                      <span className="text-xl">🚀</span>
                    </div>
                    <span className="text-xs font-bold text-green-600 bg-green-50 px-2.5 py-1 rounded-full border border-green-200/60">
                      {topMatch.match.score}% Profile Match
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-800 text-base mb-1 line-clamp-1">
                    {topMatch.internship.title}
                  </h3>
                  <p className="text-sm text-slate-500 mb-4">
                    {topMatch.internship.companyName} • {topMatch.internship.roleType}
                  </p>
                  <div className="flex items-center gap-4 text-xs font-semibold text-slate-400 mb-4">
                    <span className="flex items-center gap-1">📍 {topMatch.internship.companyLocation}</span>
                    <span className="flex items-center gap-1">⏰ {topMatch.internship.duration}</span>
                  </div>
                </div>
                {appliedInternshipIds.has(topMatch.internship.id) ? (
                  <button
                    type="button"
                    disabled
                    className="w-full py-2.5 bg-green-50 text-green-700 border border-green-200 rounded-lg font-semibold text-sm cursor-default"
                  >
                    ✓ Applied
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setApplyingInternship(topMatch.internship)}
                    className="w-full py-2.5 bg-blue-600 text-white rounded-lg font-semibold text-sm hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 cursor-pointer"
                  >
                    Quick Apply
                  </button>
                )}
              </div>
            ) : null}

            {/* Second Match Highlight */}
            {secondMatch ? (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                      <span className="text-xl">💻</span>
                    </div>
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200/60">
                      {secondMatch.match.score}% Profile Match
                    </span>
                  </div>
                  <h3 className="font-bold text-slate-800 text-base mb-1 line-clamp-1">
                    {secondMatch.internship.title}
                  </h3>
                  <p className="text-sm text-slate-500 mb-4">
                    {secondMatch.internship.companyName} • {secondMatch.internship.companyLocation}
                  </p>
                  <div className="flex items-center gap-4 text-xs font-semibold text-slate-400 mb-4">
                    <span className="flex items-center gap-1">📍 {secondMatch.internship.roleType}</span>
                    <span className="flex items-center gap-1">⏰ {secondMatch.internship.duration}</span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedInternship(secondMatch.internship)}
                  className="w-full py-2.5 border border-blue-600 text-blue-600 rounded-lg font-semibold text-sm hover:bg-blue-50 transition-colors cursor-pointer"
                >
                  View Details
                </button>
              </div>
            ) : null}

            {/* Recent Industry Trends Widget */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-3">
                  <div className="p-2 bg-orange-50 text-orange-600 rounded-lg">
                    <span className="text-xl">⚡</span>
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Market Insights</span>
                </div>
                <h3 className="font-bold text-slate-800 mb-1">Recent Industry Trends</h3>
                <div className="mt-4 flex flex-col gap-2.5">
                  <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                    <span className="text-xs font-medium text-slate-600">Cloud Architecture</span>
                    <span className="text-[11px] font-bold text-green-600 uppercase">+22% Demand</span>
                  </div>
                  <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                    <span className="text-xs font-medium text-slate-600">Blockchain Security</span>
                    <span className="text-[11px] font-bold text-slate-500 uppercase">+14% Demand</span>
                  </div>
                  <div className="flex items-center justify-between py-1.5">
                    <span className="text-xs font-medium text-slate-600">Generative AI & LLMs</span>
                    <span className="text-[11px] font-bold text-blue-600 uppercase">+45% Demand</span>
                  </div>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-400">
                Updated from active enterprise job specifications
              </div>
            </div>
          </div>

          {/* Pro Tip Banner */}
          <div className="p-4 bg-slate-900 rounded-xl text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm">
            <div>
              <p className="text-xs font-semibold text-blue-400 mb-0.5">Pro Tip</p>
              <p className="text-xs leading-relaxed opacity-85">
                Adding verified proficiencies and certifications increases your recruiter match ranking by up to 25%.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className="shrink-0 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition"
            >
              + Manage Skills ({student.skills.length})
            </button>
          </div>

          {/* Filter and Search Bar */}
          <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              {/* Search input */}
              <div className="sm:col-span-6 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  id="internship-search-input"
                  type="text"
                  placeholder="Search by role title, company, or tech skill..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white transition"
                />
              </div>

              {/* Role Type Filter */}
              <div className="sm:col-span-3">
                <select
                  id="role-type-filter-select"
                  aria-label="Filter by role type"
                  value={roleTypeFilter}
                  onChange={(e) => setRoleTypeFilter(e.target.value)}
                  className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white transition text-slate-700"
                >
                  <option value="all">All Modes (Remote / Hybrid / In-Office)</option>
                  <option value="Remote">Remote Only</option>
                  <option value="Hybrid">Hybrid</option>
                  <option value="In-office">In-office</option>
                </select>
              </div>

              {/* Min Match Filter buttons */}
              <div className="sm:col-span-3 flex items-center gap-1.5">
                <span className="text-xs text-slate-500 font-medium shrink-0">Match:</span>
                <button
                  type="button"
                  onClick={() => setMinScoreFilter(0)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition ${
                    minScoreFilter === 0
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  All
                </button>
                <button
                  type="button"
                  onClick={() => setMinScoreFilter(50)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition ${
                    minScoreFilter === 50
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  &ge;50%
                </button>
                <button
                  type="button"
                  onClick={() => setMinScoreFilter(75)}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-lg border transition ${
                    minScoreFilter === 75
                      ? 'bg-green-600 text-white border-green-600'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  &ge;75%
                </button>
              </div>
            </div>

            {/* Quick Skills Summary bar */}
            <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="font-semibold text-slate-700">Your Skills:</span>
                <div className="flex flex-wrap gap-1.5">
                  {student.skills.slice(0, 6).map((sk) => (
                    <span
                      key={sk.name}
                      className="px-2 py-0.5 bg-slate-100 text-slate-600 text-[11px] font-medium rounded border border-slate-200"
                    >
                      {sk.name}
                    </span>
                  ))}
                  <button
                    type="button"
                    onClick={() => setActiveTab('profile')}
                    className="px-2 py-0.5 bg-blue-50 text-blue-600 text-[11px] font-medium rounded border border-blue-200 hover:bg-blue-100 transition"
                  >
                    + Add Skill
                  </button>
                </div>
              </div>
              <span className="text-slate-400">Showing {filteredInternships.length} opportunities</span>
            </div>
          </div>

          {/* Internships List */}
          {filteredInternships.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">No matching internships found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Try lowering the match filter threshold or adding more skills to your profile.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setMinScoreFilter(0);
                  setRoleTypeFilter('all');
                }}
                className="text-xs font-semibold px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredInternships.map(({ internship, match }) => {
                const hasApplied = appliedInternshipIds.has(internship.id);

                return (
                  <div
                    key={internship.id}
                    id={`internship-card-${internship.id}`}
                    className="flex flex-col justify-between bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all p-6 space-y-4 group"
                  >
                    <div>
                      {/* Top row: Match Score Badge and Role Type */}
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <MatchBadge details={match} size="md" />
                        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 shrink-0">
                          {internship.roleType}
                        </span>
                      </div>

                      {/* Title & Company */}
                      <h3 className="text-base font-bold text-slate-800 group-hover:text-blue-600 transition line-clamp-1">
                        {internship.title}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                        <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-semibold text-slate-700 line-clamp-1">{internship.companyName}</span>
                      </div>

                      <div className="flex items-center gap-1 text-xs text-slate-400 mt-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="line-clamp-1">{internship.companyLocation}</span>
                      </div>

                      {/* Key details: Stipend, Duration */}
                      <div className="grid grid-cols-2 gap-2 mt-3 p-2.5 bg-slate-50 rounded-xl text-xs">
                        <div>
                          <span className="text-[10px] uppercase text-slate-400 font-bold block">Stipend</span>
                          <span className="font-bold text-slate-800">{internship.stipend}</span>
                        </div>
                        <div>
                          <span className="text-[10px] uppercase text-slate-400 font-bold block">Duration</span>
                          <span className="font-semibold text-slate-700">{internship.duration}</span>
                        </div>
                      </div>

                      {/* Required Skills breakdown */}
                      <div className="mt-3.5 space-y-1.5">
                        <span className="text-[11px] font-semibold text-slate-500 block">
                          Skills Required:
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {internship.requiredSkills.map((reqSkill) => {
                            const isMatched = match.matchedRequired.includes(reqSkill);
                            return (
                              <span
                                key={reqSkill}
                                className={`text-[11px] px-2 py-0.5 rounded font-medium border ${
                                  isMatched
                                    ? 'bg-green-50 text-green-700 border-green-200'
                                    : 'bg-slate-100 text-slate-600 border-slate-200'
                                }`}
                              >
                                {isMatched ? `✓ ${reqSkill}` : reqSkill}
                              </span>
                            );
                          })}
                        </div>
                      </div>

                      {/* Missing skills prompt if any */}
                      {match.missingRequired.length > 0 && (
                        <p className="text-[11px] text-orange-700 bg-orange-50 rounded-lg p-2 border border-orange-200 mt-2.5 leading-snug">
                          <span className="font-semibold">Recommended to learn: </span>
                          {match.missingRequired.join(', ')}
                        </p>
                      )}
                    </div>

                    {/* Card Actions */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedInternship(internship)}
                        className="text-xs font-semibold border border-blue-600 text-blue-600 rounded-lg hover:bg-blue-50 transition-colors px-3 py-1.5"
                      >
                        Match Breakdown
                      </button>

                      {hasApplied ? (
                        <span className="inline-flex items-center gap-1.5 text-xs font-bold text-green-600 bg-green-50 px-3 py-1.5 rounded-lg border border-green-200">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Applied
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setApplyingInternship(internship)}
                          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition shadow-lg shadow-blue-200 cursor-pointer"
                        >
                          <Send className="w-3 h-3" />
                          Quick Apply
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PROFILE & SKILLS */}
      {activeTab === 'profile' && (
        <StudentProfileForm profile={student} onSave={onUpdateProfile} />
      )}

      {/* TAB 3: APPLICATIONS RECORD */}
      {activeTab === 'applications' && (
        <div className="space-y-4">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-base font-bold text-slate-800 mb-1">
              Your Submitted Applications ({studentApplications.length})
            </h3>
            <p className="text-xs text-slate-500">
              Track your review updates and status across participating companies.
            </p>
          </div>

          {studentApplications.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-sm text-slate-500 text-xs space-y-3">
              <Briefcase className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-semibold text-slate-700 text-sm">No applications submitted yet.</p>
              <p>Explore matching internships to submit your profile with 1 click.</p>
              <button
                type="button"
                onClick={() => setActiveTab('matching')}
                className="mt-2 text-xs font-semibold px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition shadow-lg shadow-blue-200 cursor-pointer"
              >
                Browse Matched Roles
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {studentApplications.map((app) => {
                const statusColors = {
                  applied: 'bg-blue-50 text-blue-600 border-blue-200',
                  reviewing: 'bg-amber-50 text-amber-600 border-amber-200',
                  shortlisted: 'bg-blue-50 text-blue-700 border-blue-300 font-bold',
                  accepted: 'bg-green-50 text-green-600 border-green-200',
                  rejected: 'bg-slate-100 text-slate-500 border-slate-200',
                };

                return (
                  <div
                    key={app.id}
                    className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm sm:text-base font-bold text-slate-800">
                          {app.internshipTitle}
                        </h4>
                        <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border capitalize ${statusColors[app.status]}`}>
                          {app.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium">
                        {app.companyName} • Applied on {new Date(app.appliedAt).toLocaleDateString()}
                      </p>
                      {app.coverNote && (
                        <p className="text-xs text-slate-500 italic mt-1 bg-slate-50 p-2.5 rounded-lg border border-slate-100 max-w-xl">
                          &ldquo;{app.coverNote}&rdquo;
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <span className="text-[11px] text-slate-400 block font-semibold uppercase">Profile Match</span>
                        <span className="text-xs font-bold text-green-600 bg-green-50 px-2.5 py-1 rounded-full border border-green-200/80 inline-block mt-0.5">
                          {app.matchScore}% Match
                        </span>
                      </div>
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs border border-slate-200">
                        {app.matchedSkills.length}✓
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: REAL-TIME NOTIFICATIONS FEED */}
      {activeTab === 'notifications' && (
        <NotificationFeed
          role="student"
          notifications={notifications}
          onMarkAsRead={onMarkNotificationAsRead}
          onMarkAllAsRead={onMarkAllNotificationsAsRead}
          onActionClick={(notif) => {
            if (notif.type === 'internship_match') {
              const target = internships.find((i) => i.id === notif.linkId || i.title === notif.metadata?.internshipTitle);
              if (target) {
                setSelectedInternship(target);
              } else {
                setActiveTab('matching');
              }
            } else if (notif.type === 'application_status') {
              setActiveTab('applications');
            }
          }}
        />
      )}

      {/* Detail Modal */}
      {selectedInternship && (
        <InternshipDetailModal
          internship={selectedInternship}
          matchDetails={calculateMatchScore(
            student.skills,
            selectedInternship.requiredSkills,
            selectedInternship.optionalSkills
          )}
          student={student}
          hasApplied={appliedInternshipIds.has(selectedInternship.id)}
          onClose={() => setSelectedInternship(null)}
          onApply={(item) => {
            setSelectedInternship(null);
            setApplyingInternship(item);
          }}
        />
      )}

      {/* Apply Modal */}
      {applyingInternship && (
        <ApplyModal
          internship={applyingInternship}
          matchDetails={calculateMatchScore(
            student.skills,
            applyingInternship.requiredSkills,
            applyingInternship.optionalSkills
          )}
          student={student}
          isOpen={true}
          onClose={() => setApplyingInternship(null)}
          onSubmit={async (app) => {
            await onSubmitApplication(app);
          }}
        />
      )}
    </div>
  );
};
