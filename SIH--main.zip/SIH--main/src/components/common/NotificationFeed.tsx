import React, { useState } from 'react';
import { NotificationRecord } from '../../types';
import {
  Bell,
  Sparkles,
  UserCheck,
  Briefcase,
  Clock,
  Check,
  CheckCheck,
  Radio,
  ArrowRight,
  Filter,
} from 'lucide-react';

interface NotificationFeedProps {
  role: 'student' | 'company';
  notifications: NotificationRecord[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onActionClick?: (notif: NotificationRecord) => void;
}

export const NotificationFeed: React.FC<NotificationFeedProps> = ({
  role,
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
  onActionClick,
}) => {
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const filteredNotifs = notifications.filter((n) => {
    if (filter === 'unread') return !n.read;
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  const formatRelativeTime = (isoDate: string) => {
    try {
      const diffMs = Date.now() - new Date(isoDate).getTime();
      const mins = Math.floor(diffMs / 60000);
      if (mins < 1) return 'Just now';
      if (mins < 60) return `${mins} min ago`;
      const hours = Math.floor(mins / 60);
      if (hours < 24) return `${hours} hr ago`;
      const days = Math.floor(hours / 24);
      return `${days} days ago`;
    } catch {
      return 'Recently';
    }
  };

  return (
    <div className="space-y-6" id="notification-feed-root">
      {/* Feed Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-bold text-slate-800">
              {role === 'student' ? 'Internship Match & System Notifications' : 'Recruitment & Applicant Alerts'}
            </h2>
            <span className="flex items-center gap-1.5 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
              <Radio className="w-2.5 h-2.5 text-blue-600 animate-pulse" />
              Live
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {role === 'student'
              ? 'Real-time alerts triggered whenever new internships match your verified skill set.'
              : 'Real-time candidate alerts triggered whenever students apply for your posted openings.'}
          </p>
        </div>

        {/* Filter and Mark All */}
        <div className="flex items-center gap-3 self-start sm:self-center">
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setFilter('all')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition ${
                filter === 'all'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              type="button"
              onClick={() => setFilter('unread')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition ${
                filter === 'unread'
                  ? 'bg-white text-slate-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              Unread ({unreadCount})
            </button>
          </div>

          {unreadCount > 0 && (
            <button
              type="button"
              onClick={onMarkAllAsRead}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              Mark all read
            </button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {filteredNotifs.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto mb-3">
              <Bell className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-800">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications yet'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-md mx-auto">
              {role === 'student'
                ? 'When employers post roles that align with your technical skills, automated compatibility alerts will appear here in real time.'
                : 'When students submit applications to your openings, real-time alerts with their match score will stream here.'}
            </p>
          </div>
        ) : (
          filteredNotifs.map((notif) => {
            const isMatch = notif.type === 'internship_match';
            const isApplicant = notif.type === 'application_received';

            return (
              <div
                key={notif.id}
                id={`feed-notification-${notif.id}`}
                className={`bg-white rounded-2xl border transition p-4 sm:p-5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  !notif.read
                    ? 'border-blue-300 bg-blue-50/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Left content */}
                <div className="flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isMatch
                        ? 'bg-blue-100 text-blue-600'
                        : isApplicant
                        ? 'bg-emerald-100 text-emerald-600'
                        : 'bg-indigo-100 text-indigo-600'
                    }`}
                  >
                    {isMatch ? (
                      <Sparkles className="w-5 h-5" />
                    ) : isApplicant ? (
                      <UserCheck className="w-5 h-5" />
                    ) : (
                      <Briefcase className="w-5 h-5" />
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm sm:text-base font-bold text-slate-800">
                        {notif.title}
                      </h4>
                      {!notif.read && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-600 text-white">
                          NEW
                        </span>
                      )}
                      {notif.metadata?.matchScore !== undefined && (
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                          {notif.metadata.matchScore}% Match Score
                        </span>
                      )}
                    </div>

                    <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                      {notif.message}
                    </p>

                    {/* Matched skills tags */}
                    {notif.metadata?.matchedSkills && notif.metadata.matchedSkills.length > 0 && (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <span className="text-[11px] font-medium text-slate-500">Matching competencies:</span>
                        {notif.metadata.matchedSkills.map((s) => (
                          <span
                            key={s}
                            className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-green-50 text-green-700 border border-green-200"
                          >
                            ✓ {s}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-3 pt-1 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatRelativeTime(notif.createdAt)}
                      </span>
                      {notif.metadata?.companyName && (
                        <span>• {notif.metadata.companyName}</span>
                      )}
                      {notif.metadata?.studentCollege && (
                        <span>• {notif.metadata.studentCollege}</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right actions */}
                <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                  {onActionClick && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!notif.read) onMarkAsRead(notif.id);
                        onActionClick(notif);
                      }}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm shadow-blue-200 transition cursor-pointer"
                    >
                      <span>{role === 'student' ? 'View Role & Apply' : 'Review Applicant'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {!notif.read && (
                    <button
                      type="button"
                      onClick={() => onMarkAsRead(notif.id)}
                      title="Mark as read"
                      className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
