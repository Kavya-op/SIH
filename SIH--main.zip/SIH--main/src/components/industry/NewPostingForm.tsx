import React, { useState } from 'react';
import { InternshipPosting, CompanyProfile } from '../../types';
import {
  Briefcase,
  Plus,
  X,
  IndianRupee,
  Calendar,
  Clock,
  Send,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

interface NewPostingFormProps {
  companies: CompanyProfile[];
  activeCompanyId: string;
  onPostInternship: (internship: InternshipPosting) => Promise<void>;
  onSuccess: () => void;
}

const COMMON_REQUIREMENT_PRESETS = [
  'React',
  'TypeScript',
  'JavaScript',
  'Python',
  'Node.js',
  'Tailwind CSS',
  'PostgreSQL',
  'Machine Learning',
  'Docker',
  'Kubernetes',
  'AWS',
  'C++',
  'Figma',
  'SQL',
  'NLP',
  'Git',
];

export const NewPostingForm: React.FC<NewPostingFormProps> = ({
  companies,
  activeCompanyId,
  onPostInternship,
  onSuccess,
}) => {
  const activeCompany =
    companies.find((c) => c.id === activeCompanyId) || companies[0];

  const [title, setTitle] = useState('');
  const [companyId, setCompanyId] = useState(activeCompany?.id || '');
  const [roleType, setRoleType] = useState<'Remote' | 'Hybrid' | 'In-office'>('Remote');
  const [duration, setDuration] = useState('3 Months');
  const [stipend, setStipend] = useState('₹30,000 / month');
  const [openPositions, setOpenPositions] = useState(2);
  const [deadline, setDeadline] = useState('Nov 30, 2026');
  const [description, setDescription] = useState('');
  const [responsibilitiesText, setResponsibilitiesText] = useState(
    'Collaborate with lead engineers\nBuild modular features and test coverage\nParticipate in daily standups and design reviews'
  );

  // Skill tags
  const [requiredSkills, setRequiredSkills] = useState<string[]>([
    'React',
    'TypeScript',
  ]);
  const [optionalSkills, setOptionalSkills] = useState<string[]>([
    'Docker',
  ]);
  const [newReqSkillInput, setNewReqSkillInput] = useState('');
  const [newOptSkillInput, setNewOptSkillInput] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDone, setIsDone] = useState(false);

  const handleAddReqSkill = (skill?: string) => {
    const s = (skill || newReqSkillInput).trim();
    if (!s) return;
    if (!requiredSkills.some((item) => item.toLowerCase() === s.toLowerCase())) {
      setRequiredSkills([...requiredSkills, s]);
    }
    setNewReqSkillInput('');
  };

  const handleRemoveReqSkill = (skill: string) => {
    setRequiredSkills(requiredSkills.filter((s) => s !== skill));
  };

  const handleAddOptSkill = (skill?: string) => {
    const s = (skill || newOptSkillInput).trim();
    if (!s) return;
    if (!optionalSkills.some((item) => item.toLowerCase() === s.toLowerCase())) {
      setOptionalSkills([...optionalSkills, s]);
    }
    setNewOptSkillInput('');
  };

  const handleRemoveOptSkill = (skill: string) => {
    setOptionalSkills(optionalSkills.filter((s) => s !== skill));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || requiredSkills.length === 0) return;

    setIsSubmitting(true);
    const selectedComp =
      companies.find((c) => c.id === companyId) || activeCompany;

    const responsibilities = responsibilitiesText
      .split('\n')
      .map((r) => r.trim())
      .filter(Boolean);

    const newPosting: InternshipPosting = {
      id: `intern-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      companyId: selectedComp ? selectedComp.id : 'company-custom',
      companyName: selectedComp ? selectedComp.name : 'Industry Partner',
      companyLocation: selectedComp ? selectedComp.location : 'Bangalore',
      title: title.trim(),
      roleType,
      duration,
      stipend,
      requiredSkills,
      optionalSkills,
      description: description.trim() || `Join ${selectedComp?.name} for hands-on industry experience building real-world software products.`,
      responsibilities,
      openPositions: Number(openPositions) || 1,
      deadline,
      status: 'active',
      createdAt: new Date().toISOString(),
      applicantsCount: 0,
    };

    try {
      await onPostInternship(newPosting);
      setIsDone(true);
      setTimeout(() => {
        setIsDone(false);
        onSuccess();
      }, 1400);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6" id="new-internship-posting-form">
      <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-slate-800 flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-blue-600" />
            Post New Internship Requirement
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Specify the required and bonus skills. The automated match engine will calculate candidate compatibility scores in real-time.
          </p>
        </div>

        {/* Company & Title Row */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
          <div className="sm:col-span-5">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Hiring Organization / Company *
            </label>
            <select
              value={companyId}
              onChange={(e) => setCompanyId(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            >
              {companies.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.industry})
                </option>
              ))}
            </select>
          </div>

          <div className="sm:col-span-7">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Internship Title *
            </label>
            <input
              id="internship-title-field"
              type="text"
              required
              placeholder="e.g. AI Research & Machine Learning Intern"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>
        </div>

        {/* Terms Row: Mode, Duration, Stipend, Seats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Work Mode
            </label>
            <select
              value={roleType}
              onChange={(e) =>
                setRoleType(e.target.value as 'Remote' | 'Hybrid' | 'In-office')
              }
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-800"
            >
              <option value="Remote">Remote</option>
              <option value="Hybrid">Hybrid</option>
              <option value="In-office">In-office</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Duration
            </label>
            <input
              type="text"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              placeholder="e.g. 3 Months"
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-800"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Monthly Stipend
            </label>
            <input
              type="text"
              value={stipend}
              onChange={(e) => setStipend(e.target.value)}
              placeholder="e.g. ₹35,000 / month"
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-800"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Open Seats
            </label>
            <input
              type="number"
              min={1}
              max={20}
              value={openPositions}
              onChange={(e) => setOpenPositions(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 text-slate-800"
            />
          </div>
        </div>

        {/* Required Skills Section */}
        <div className="p-5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-800">
              Required Core Skills (75% Match Weight) *
            </label>
            <p className="text-[11px] text-slate-500">
              Students missing these skills will receive lowered match scores and skill upgrade recommendations.
            </p>
          </div>

          <div className="flex gap-2">
            <input
              id="new-req-skill-input"
              type="text"
              placeholder="Add required skill (e.g. Python, React, SQL)..."
              value={newReqSkillInput}
              onChange={(e) => setNewReqSkillInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddReqSkill();
                }
              }}
              className="flex-1 px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
            <button
              type="button"
              onClick={() => handleAddReqSkill()}
              className="px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition shadow-sm cursor-pointer"
            >
              Add
            </button>
          </div>

          {/* Active Required Skills */}
          <div className="flex flex-wrap gap-1.5 min-h-[32px]">
            {requiredSkills.map((skill) => (
              <span
                key={skill}
                className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 border border-blue-200"
              >
                <span>{skill}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveReqSkill(skill)}
                  className="hover:text-rose-600 transition"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>

          {/* Quick presets */}
          <div className="pt-2 border-t border-slate-200/60 flex flex-wrap gap-1 items-center">
            <span className="text-[11px] text-slate-500 font-medium mr-1">Suggested:</span>
            {COMMON_REQUIREMENT_PRESETS.slice(0, 8).map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => handleAddReqReqIfAbsent(preset)}
                className="text-[10px] px-2 py-0.5 rounded bg-white hover:bg-slate-200 text-slate-700 border border-slate-200 transition"
              >
                + {preset}
              </button>
            ))}
          </div>
        </div>

        {/* Optional Skills Section */}
        <div className="p-5 bg-slate-50/80 rounded-xl border border-slate-200 space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-800">
              Optional / Bonus Skills (25% Match Weight)
            </label>
            <p className="text-[11px] text-slate-500">
              Gives students bonus points if present in their profile.
            </p>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add bonus skill (e.g. Docker, AWS, UI/UX)..."
              value={newOptSkillInput}
              onChange={(e) => setNewOptSkillInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddOptSkill();
                }
              }}
              className="flex-1 px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
            <button
              type="button"
              onClick={() => handleAddOptSkill()}
              className="px-4 py-2 text-xs font-semibold bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition"
            >
              Add Bonus
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {optionalSkills.map((skill) => (
              <span
                key={skill}
                className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200"
              >
                <span>★ {skill}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveOptSkill(skill)}
                  className="hover:text-rose-600 transition"
                >
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Description & Responsibilities */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Job Description & Project Context
            </label>
            <textarea
              rows={4}
              required
              placeholder="Describe the real-world project, team culture, and learning opportunities..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Key Responsibilities (One per line)
            </label>
            <textarea
              rows={4}
              placeholder="e.g.&#10;Develop features with React and Node.js&#10;Optimize database queries&#10;Write unit tests"
              value={responsibilitiesText}
              onChange={(e) => setResponsibilitiesText(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:bg-white text-slate-800 transition"
            />
          </div>
        </div>

        {/* Footer actions */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <p className="text-xs text-slate-500">
            Posting will immediately synchronize with Firestore database.
          </p>

          <button
            id="submit-internship-posting-btn"
            type="submit"
            disabled={isSubmitting || requiredSkills.length === 0 || !title.trim()}
            className="inline-flex items-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-700 text-white shadow-lg shadow-blue-200 transition disabled:opacity-50 cursor-pointer"
          >
            {isDone ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-white" />
                <span>Internship Published!</span>
              </>
            ) : isSubmitting ? (
              <span>Publishing...</span>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Publish to Portal</span>
              </>
            )}
          </button>
        </div>
      </div>
    </form>
  );

  function handleAddReqReqIfAbsent(s: string) {
    if (!requiredSkills.some((item) => item.toLowerCase() === s.toLowerCase())) {
      setRequiredSkills([...requiredSkills, s]);
    }
  }
};
