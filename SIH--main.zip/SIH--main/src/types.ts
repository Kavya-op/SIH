export type RoleView = 'student' | 'industry' | 'institution';

export type AccountType = 'Student' | 'Institution' | 'Industry';

export interface UserAccount {
  uid: string;
  email: string;
  username: string;
  accountType: AccountType;
  role: RoleView;
  institutionId?: string;
  institutionName?: string;
  companyId?: string;
  companyName?: string;
  createdAt: string;
}

export type StudentTab = 'matching' | 'profile' | 'applications' | 'notifications';
export type IndustryTab = 'postings' | 'new-posting' | 'applicants' | 'company-profile' | 'notifications';
export type InstitutionTab = 'students' | 'analytics' | 'trending-skills' | 'profile';

export type ProficiencyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export interface StudentSkill {
  name: string;
  level: ProficiencyLevel;
  verified?: boolean;
}

export interface StudentProfile {
  id: string;
  name: string;
  email: string;
  college: string;
  institutionId?: string;
  department?: string;
  degree: string;
  yearOfStudy: string;
  cgpa: string;
  bio: string;
  skills: StudentSkill[];
  githubUrl?: string;
  linkedinUrl?: string;
  portfolioUrl?: string;
  resumeFileName?: string;
  availability: string;
  preferredType: 'Remote' | 'Hybrid' | 'In-office' | 'Any';
  verifiedByInstitution?: boolean;
  verifiedAt?: string;
  verifiedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InstitutionProfile {
  id: string;
  name: string;
  code: string;
  type: 'University' | 'Engineering Institute' | 'Technology College';
  location: string;
  contactEmail: string;
  website: string;
  accreditation: string;
  departments: string[];
  totalStudentsEnrolled: number;
  logoUrl?: string;
  createdAt: string;
}

export interface CompanyProfile {
  id: string;
  name: string;
  industry: string;
  website: string;
  location: string;
  description: string;
  contactEmail: string;
  logoUrl?: string;
  verified: boolean;
  createdAt: string;
}

export interface InternshipPosting {
  id: string;
  companyId: string;
  companyName: string;
  companyLocation: string;
  title: string;
  roleType: 'Remote' | 'Hybrid' | 'In-office';
  duration: string;
  stipend: string;
  requiredSkills: string[];
  optionalSkills: string[];
  description: string;
  responsibilities: string[];
  openPositions: number;
  deadline: string;
  status: 'active' | 'closed';
  createdAt: string;
  applicantsCount?: number;
}

export interface ApplicationRecord {
  id: string;
  internshipId: string;
  internshipTitle: string;
  companyId: string;
  companyName: string;
  studentId: string;
  studentName: string;
  studentEmail: string;
  studentCollege: string;
  studentDegree: string;
  matchScore: number;
  matchedSkills: string[];
  missingSkills: string[];
  coverNote?: string;
  status: 'applied' | 'reviewing' | 'shortlisted' | 'accepted' | 'rejected';
  appliedAt: string;
}

export interface MatchScoreDetails {
  score: number; // 0 to 100
  matchedRequired: string[];
  missingRequired: string[];
  matchedOptional: string[];
  missingOptional: string[];
  totalRequired: number;
  totalOptional: number;
  matchLevel: 'High' | 'Moderate' | 'Low';
  scoreColor: string;
  recommendation: string;
}

export interface NotificationRecord {
  id: string;
  recipientId: string; // studentId or companyId
  recipientType: 'student' | 'company';
  type: 'internship_match' | 'application_received' | 'application_status';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  linkId?: string; // internshipId or applicationId
  metadata?: {
    matchScore?: number;
    internshipId?: string;
    applicationId?: string;
    companyId?: string;
    internshipTitle?: string;
    companyName?: string;
    studentName?: string;
    studentCollege?: string;
    matchedSkills?: string[];
    newStatus?: string;
  };
}
